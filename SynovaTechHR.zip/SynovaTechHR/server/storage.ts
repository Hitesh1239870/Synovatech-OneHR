import { 
  type User, type InsertUser, users,
  type Employee, type InsertEmployee, employees,
  type Department, type InsertDepartment, departments,
  type LeaveRequest, type InsertLeaveRequest, leaveRequests,
  type Attendance, type InsertAttendance, attendance,
  type PerformanceReview, type InsertPerformanceReview, performanceReviews,
  type JobListing, type InsertJobListing, jobListings,
  type Candidate, type InsertCandidate, candidates,
  type Document, type InsertDocument, documents,
  type Task, type InsertTask, tasks,
  type Event, type InsertEvent, events,
  type ActivityLog, type InsertActivityLog, activityLogs
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  
  // Employee methods
  getEmployee(id: number): Promise<Employee | undefined>;
  getEmployeeByUserId(userId: number): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  getAllEmployees(): Promise<Employee[]>;
  updateEmployee(id: number, employeeData: Partial<InsertEmployee>): Promise<Employee | undefined>;
  
  // Department methods
  getDepartment(id: number): Promise<Department | undefined>;
  createDepartment(department: InsertDepartment): Promise<Department>;
  getAllDepartments(): Promise<Department[]>;
  
  // Leave request methods
  getLeaveRequest(id: number): Promise<LeaveRequest | undefined>;
  createLeaveRequest(leaveRequest: InsertLeaveRequest): Promise<LeaveRequest>;
  getLeaveRequestsByEmployee(employeeId: number): Promise<LeaveRequest[]>;
  updateLeaveRequest(id: number, status: string, approvedBy?: number): Promise<LeaveRequest | undefined>;
  getAllLeaveRequests(): Promise<LeaveRequest[]>;
  
  // Attendance methods
  getAttendance(id: number): Promise<Attendance | undefined>;
  createAttendance(attendanceRecord: InsertAttendance): Promise<Attendance>;
  getAttendanceByEmployee(employeeId: number): Promise<Attendance[]>;
  getAttendanceByDate(date: Date): Promise<Attendance[]>;
  updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance | undefined>;
  
  // Performance review methods
  getPerformanceReview(id: number): Promise<PerformanceReview | undefined>;
  createPerformanceReview(review: InsertPerformanceReview): Promise<PerformanceReview>;
  getPerformanceReviewsByEmployee(employeeId: number): Promise<PerformanceReview[]>;
  updatePerformanceReview(id: number, reviewData: Partial<InsertPerformanceReview>): Promise<PerformanceReview | undefined>;
  
  // Job listing methods
  getJobListing(id: number): Promise<JobListing | undefined>;
  createJobListing(jobListing: InsertJobListing): Promise<JobListing>;
  getAllJobListings(): Promise<JobListing[]>;
  updateJobListing(id: number, jobData: Partial<InsertJobListing>): Promise<JobListing | undefined>;
  
  // Candidate methods
  getCandidate(id: number): Promise<Candidate | undefined>;
  createCandidate(candidate: InsertCandidate): Promise<Candidate>;
  getCandidatesByJob(jobId: number): Promise<Candidate[]>;
  updateCandidate(id: number, candidateData: Partial<InsertCandidate>): Promise<Candidate | undefined>;
  
  // Document methods
  getDocument(id: number): Promise<Document | undefined>;
  createDocument(document: InsertDocument): Promise<Document>;
  getAllDocuments(): Promise<Document[]>;
  getDocumentsByOwner(ownerId: number): Promise<Document[]>;
  updateDocument(id: number, documentData: Partial<InsertDocument>): Promise<Document | undefined>;
  
  // Task methods
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  getTasksByAssignee(assignedTo: number): Promise<Task[]>;
  getAllTasks(): Promise<Task[]>;
  updateTask(id: number, taskData: Partial<InsertTask>): Promise<Task | undefined>;
  
  // Event methods
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  getAllEvents(): Promise<Event[]>;
  getEventsByDate(date: Date): Promise<Event[]>;
  updateEvent(id: number, eventData: Partial<InsertEvent>): Promise<Event | undefined>;
  
  // Activity log methods
  getActivityLog(id: number): Promise<ActivityLog | undefined>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getActivityLogsByUser(userId: number): Promise<ActivityLog[]>;
  getRecentActivityLogs(limit: number): Promise<ActivityLog[]>;
}

export class MemStorage implements IStorage {
  private usersData: Map<number, User>;
  private employeesData: Map<number, Employee>;
  private departmentsData: Map<number, Department>;
  private leaveRequestsData: Map<number, LeaveRequest>;
  private attendanceData: Map<number, Attendance>;
  private performanceReviewsData: Map<number, PerformanceReview>;
  private jobListingsData: Map<number, JobListing>;
  private candidatesData: Map<number, Candidate>;
  private documentsData: Map<number, Document>;
  private tasksData: Map<number, Task>;
  private eventsData: Map<number, Event>;
  private activityLogsData: Map<number, ActivityLog>;
  
  private userIdCounter: number = 1;
  private employeeIdCounter: number = 1;
  private departmentIdCounter: number = 1;
  private leaveRequestIdCounter: number = 1;
  private attendanceIdCounter: number = 1;
  private performanceReviewIdCounter: number = 1;
  private jobListingIdCounter: number = 1;
  private candidateIdCounter: number = 1;
  private documentIdCounter: number = 1;
  private taskIdCounter: number = 1;
  private eventIdCounter: number = 1;
  private activityLogIdCounter: number = 1;

  constructor() {
    this.usersData = new Map();
    this.employeesData = new Map();
    this.departmentsData = new Map();
    this.leaveRequestsData = new Map();
    this.attendanceData = new Map();
    this.performanceReviewsData = new Map();
    this.jobListingsData = new Map();
    this.candidatesData = new Map();
    this.documentsData = new Map();
    this.tasksData = new Map();
    this.eventsData = new Map();
    this.activityLogsData = new Map();

    // Initialize with default data
    this.seedData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.usersData.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersData.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const newUser: User = { ...user, id, createdAt: new Date(), isActive: true };
    this.usersData.set(id, newUser);
    return newUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.usersData.values());
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.usersData.set(id, updatedUser);
    return updatedUser;
  }

  // Employee methods
  async getEmployee(id: number): Promise<Employee | undefined> {
    return this.employeesData.get(id);
  }

  async getEmployeeByUserId(userId: number): Promise<Employee | undefined> {
    return Array.from(this.employeesData.values()).find(
      (employee) => employee.userId === userId
    );
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const id = this.employeeIdCounter++;
    const newEmployee: Employee = { ...employee, id };
    this.employeesData.set(id, newEmployee);
    return newEmployee;
  }

  async getAllEmployees(): Promise<Employee[]> {
    return Array.from(this.employeesData.values());
  }

  async updateEmployee(id: number, employeeData: Partial<InsertEmployee>): Promise<Employee | undefined> {
    const employee = await this.getEmployee(id);
    if (!employee) return undefined;
    
    const updatedEmployee = { ...employee, ...employeeData };
    this.employeesData.set(id, updatedEmployee);
    return updatedEmployee;
  }

  // Department methods
  async getDepartment(id: number): Promise<Department | undefined> {
    return this.departmentsData.get(id);
  }

  async createDepartment(department: InsertDepartment): Promise<Department> {
    const id = this.departmentIdCounter++;
    const newDepartment: Department = { ...department, id };
    this.departmentsData.set(id, newDepartment);
    return newDepartment;
  }

  async getAllDepartments(): Promise<Department[]> {
    return Array.from(this.departmentsData.values());
  }

  // Leave request methods
  async getLeaveRequest(id: number): Promise<LeaveRequest | undefined> {
    return this.leaveRequestsData.get(id);
  }

  async createLeaveRequest(leaveRequest: InsertLeaveRequest): Promise<LeaveRequest> {
    const id = this.leaveRequestIdCounter++;
    const newLeaveRequest: LeaveRequest = { 
      ...leaveRequest, 
      id, 
      createdAt: new Date()
    };
    this.leaveRequestsData.set(id, newLeaveRequest);
    return newLeaveRequest;
  }

  async getLeaveRequestsByEmployee(employeeId: number): Promise<LeaveRequest[]> {
    return Array.from(this.leaveRequestsData.values()).filter(
      (request) => request.employeeId === employeeId
    );
  }

  async updateLeaveRequest(id: number, status: string, approvedBy?: number): Promise<LeaveRequest | undefined> {
    const leaveRequest = await this.getLeaveRequest(id);
    if (!leaveRequest) return undefined;
    
    const updatedLeaveRequest = { 
      ...leaveRequest, 
      status, 
      approvedBy: approvedBy || leaveRequest.approvedBy 
    };
    this.leaveRequestsData.set(id, updatedLeaveRequest);
    return updatedLeaveRequest;
  }

  async getAllLeaveRequests(): Promise<LeaveRequest[]> {
    return Array.from(this.leaveRequestsData.values());
  }

  // Attendance methods
  async getAttendance(id: number): Promise<Attendance | undefined> {
    return this.attendanceData.get(id);
  }

  async createAttendance(attendanceRecord: InsertAttendance): Promise<Attendance> {
    const id = this.attendanceIdCounter++;
    const newAttendance: Attendance = { ...attendanceRecord, id };
    this.attendanceData.set(id, newAttendance);
    return newAttendance;
  }

  async getAttendanceByEmployee(employeeId: number): Promise<Attendance[]> {
    return Array.from(this.attendanceData.values()).filter(
      (record) => record.employeeId === employeeId
    );
  }

  async getAttendanceByDate(date: Date): Promise<Attendance[]> {
    const dateString = date.toISOString().split('T')[0];
    return Array.from(this.attendanceData.values()).filter(
      (record) => record.date.toISOString().split('T')[0] === dateString
    );
  }

  async updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const attendance = await this.getAttendance(id);
    if (!attendance) return undefined;
    
    const updatedAttendance = { ...attendance, ...attendanceData };
    this.attendanceData.set(id, updatedAttendance);
    return updatedAttendance;
  }

  // Performance review methods
  async getPerformanceReview(id: number): Promise<PerformanceReview | undefined> {
    return this.performanceReviewsData.get(id);
  }

  async createPerformanceReview(review: InsertPerformanceReview): Promise<PerformanceReview> {
    const id = this.performanceReviewIdCounter++;
    const newReview: PerformanceReview = { ...review, id };
    this.performanceReviewsData.set(id, newReview);
    return newReview;
  }

  async getPerformanceReviewsByEmployee(employeeId: number): Promise<PerformanceReview[]> {
    return Array.from(this.performanceReviewsData.values()).filter(
      (review) => review.employeeId === employeeId
    );
  }

  async updatePerformanceReview(id: number, reviewData: Partial<InsertPerformanceReview>): Promise<PerformanceReview | undefined> {
    const review = await this.getPerformanceReview(id);
    if (!review) return undefined;
    
    const updatedReview = { ...review, ...reviewData };
    this.performanceReviewsData.set(id, updatedReview);
    return updatedReview;
  }

  // Job listing methods
  async getJobListing(id: number): Promise<JobListing | undefined> {
    return this.jobListingsData.get(id);
  }

  async createJobListing(jobListing: InsertJobListing): Promise<JobListing> {
    const id = this.jobListingIdCounter++;
    const newJobListing: JobListing = { ...jobListing, id };
    this.jobListingsData.set(id, newJobListing);
    return newJobListing;
  }

  async getAllJobListings(): Promise<JobListing[]> {
    return Array.from(this.jobListingsData.values());
  }

  async updateJobListing(id: number, jobData: Partial<InsertJobListing>): Promise<JobListing | undefined> {
    const jobListing = await this.getJobListing(id);
    if (!jobListing) return undefined;
    
    const updatedJobListing = { ...jobListing, ...jobData };
    this.jobListingsData.set(id, updatedJobListing);
    return updatedJobListing;
  }

  // Candidate methods
  async getCandidate(id: number): Promise<Candidate | undefined> {
    return this.candidatesData.get(id);
  }

  async createCandidate(candidate: InsertCandidate): Promise<Candidate> {
    const id = this.candidateIdCounter++;
    const newCandidate: Candidate = { ...candidate, id };
    this.candidatesData.set(id, newCandidate);
    return newCandidate;
  }

  async getCandidatesByJob(jobId: number): Promise<Candidate[]> {
    return Array.from(this.candidatesData.values()).filter(
      (candidate) => candidate.jobId === jobId
    );
  }

  async updateCandidate(id: number, candidateData: Partial<InsertCandidate>): Promise<Candidate | undefined> {
    const candidate = await this.getCandidate(id);
    if (!candidate) return undefined;
    
    const updatedCandidate = { ...candidate, ...candidateData };
    this.candidatesData.set(id, updatedCandidate);
    return updatedCandidate;
  }

  // Document methods
  async getDocument(id: number): Promise<Document | undefined> {
    return this.documentsData.get(id);
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const id = this.documentIdCounter++;
    const now = new Date();
    const newDocument: Document = { 
      ...document, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.documentsData.set(id, newDocument);
    return newDocument;
  }

  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.documentsData.values());
  }

  async getDocumentsByOwner(ownerId: number): Promise<Document[]> {
    return Array.from(this.documentsData.values()).filter(
      (document) => document.ownerId === ownerId
    );
  }

  async updateDocument(id: number, documentData: Partial<InsertDocument>): Promise<Document | undefined> {
    const document = await this.getDocument(id);
    if (!document) return undefined;
    
    const updatedDocument = { 
      ...document, 
      ...documentData, 
      updatedAt: new Date() 
    };
    this.documentsData.set(id, updatedDocument);
    return updatedDocument;
  }

  // Task methods
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasksData.get(id);
  }

  async createTask(task: InsertTask): Promise<Task> {
    const id = this.taskIdCounter++;
    const newTask: Task = { 
      ...task, 
      id, 
      createdAt: new Date()
    };
    this.tasksData.set(id, newTask);
    return newTask;
  }

  async getTasksByAssignee(assignedTo: number): Promise<Task[]> {
    return Array.from(this.tasksData.values()).filter(
      (task) => task.assignedTo === assignedTo
    );
  }

  async getAllTasks(): Promise<Task[]> {
    return Array.from(this.tasksData.values());
  }

  async updateTask(id: number, taskData: Partial<InsertTask>): Promise<Task | undefined> {
    const task = await this.getTask(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...taskData };
    this.tasksData.set(id, updatedTask);
    return updatedTask;
  }

  // Event methods
  async getEvent(id: number): Promise<Event | undefined> {
    return this.eventsData.get(id);
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const id = this.eventIdCounter++;
    const newEvent: Event = { 
      ...event, 
      id, 
      createdAt: new Date()
    };
    this.eventsData.set(id, newEvent);
    return newEvent;
  }

  async getAllEvents(): Promise<Event[]> {
    return Array.from(this.eventsData.values());
  }

  async getEventsByDate(date: Date): Promise<Event[]> {
    const dateString = date.toISOString().split('T')[0];
    return Array.from(this.eventsData.values()).filter(
      (event) => event.date.toISOString().split('T')[0] === dateString
    );
  }

  async updateEvent(id: number, eventData: Partial<InsertEvent>): Promise<Event | undefined> {
    const event = await this.getEvent(id);
    if (!event) return undefined;
    
    const updatedEvent = { ...event, ...eventData };
    this.eventsData.set(id, updatedEvent);
    return updatedEvent;
  }

  // Activity log methods
  async getActivityLog(id: number): Promise<ActivityLog | undefined> {
    return this.activityLogsData.get(id);
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const id = this.activityLogIdCounter++;
    const newLog: ActivityLog = { 
      ...log, 
      id, 
      timestamp: new Date()
    };
    this.activityLogsData.set(id, newLog);
    return newLog;
  }

  async getActivityLogsByUser(userId: number): Promise<ActivityLog[]> {
    return Array.from(this.activityLogsData.values()).filter(
      (log) => log.userId === userId
    );
  }

  async getRecentActivityLogs(limit: number): Promise<ActivityLog[]> {
    return Array.from(this.activityLogsData.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  // Helper method to seed initial data
  private seedData() {
    // Seed departments
    const departments = [
      { name: "Engineering", description: "Software development team" },
      { name: "Marketing", description: "Brand and marketing team" },
      { name: "Finance", description: "Financial operations" },
      { name: "Human Resources", description: "HR operations" },
      { name: "Sales", description: "Sales and business development" }
    ];

    departments.forEach(dept => {
      this.createDepartment(dept);
    });

    // Seed admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      fullName: "Admin User",
      email: "admin@synovatech.com",
      role: "admin",
      department: "Human Resources",
      position: "HR Manager",
      profileImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
    });

    // Seed HR Manager user
    const hrManager = this.createUser({
      username: "sarahjohnson",
      password: "password123",
      fullName: "Sarah Johnson",
      email: "sarah.johnson@synovatech.com",
      role: "manager",
      department: "Human Resources",
      position: "HR Manager",
      profileImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
    });

    // Additional users
    this.createUser({
      username: "davidkim",
      password: "password123",
      fullName: "David Kim",
      email: "david.kim@synovatech.com",
      role: "manager",
      department: "Engineering",
      position: "Engineering Director",
      profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e",
    });

    this.createUser({
      username: "michellelopez",
      password: "password123",
      fullName: "Michelle Lopez",
      email: "michelle.lopez@synovatech.com",
      role: "manager",
      department: "Marketing",
      position: "Marketing Director",
      profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
    });

    // Seed employees (will be created in routes by initializing with sample data)
  }
}

export const storage = new MemStorage();
