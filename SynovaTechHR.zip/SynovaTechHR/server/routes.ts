import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import express from "express";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertEmployeeSchema, 
  insertLeaveRequestSchema, 
  insertAttendanceSchema,
  insertPerformanceReviewSchema,
  insertTaskSchema,
  insertEventSchema,
  insertJobListingSchema,
  insertCandidateSchema,
  insertDocumentSchema,
  insertActivityLogSchema
} from "@shared/schema";
import { WebSocketServer } from "ws";
import OpenAI from "openai";

// Initialize OpenAI client conditionally
let openai: OpenAI | null = null;
try {
  if (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.startsWith('sk-')) {
    openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    console.log("OpenAI client initialized successfully");
  } else {
    console.log("Invalid or missing OpenAI API key format - falling back to mock responses");
  }
} catch (error) {
  console.error("Error initializing OpenAI client:", error);
}

// Helper to validate request body
function validateRequestBody<T extends z.ZodType>(schema: T, data: unknown): z.infer<T> {
  return schema.parse(data);
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Create WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
  
  wss.on("connection", (ws) => {
    console.log("WebSocket client connected");
    
    ws.on("message", (message) => {
      console.log("Received message:", message);
    });
    
    ws.on("close", () => {
      console.log("WebSocket client disconnected");
    });
    
    ws.on("error", (error) => {
      console.error("WebSocket error:", error);
    });
  });
  
  wss.on("error", (error) => {
    console.error("WebSocket server error:", error);
  });
  
  // Broadcast to all connected clients
  function broadcast(data: any) {
    wss.clients.forEach((client) => {
      if (client.readyState === 1) { // OPEN
        client.send(JSON.stringify(data));
      }
    });
  }

  // API Routes
  const router = express.Router();

  // Auth endpoints
  router.post("/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Create activity log for login
      await storage.createActivityLog({
        userId: user.id,
        action: "login",
        details: "User logged in"
      });

      return res.status(200).json({
        id: user.id,
        username: user.username,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
        department: user.department,
        position: user.position,
        profileImage: user.profileImage
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // User endpoints
  router.get("/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      return res.status(200).json(users.map(user => ({
        id: user.id,
        username: user.username,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
        department: user.department,
        position: user.position,
        profileImage: user.profileImage,
        isActive: user.isActive
      })));
    } catch (error) {
      console.error("Get users error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.get("/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      return res.status(200).json({
        id: user.id,
        username: user.username,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
        department: user.department,
        position: user.position,
        profileImage: user.profileImage,
        isActive: user.isActive
      });
    } catch (error) {
      console.error("Get user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/users", async (req, res) => {
    try {
      const userData = validateRequestBody(insertUserSchema, req.body);
      const user = await storage.createUser(userData);
      
      return res.status(201).json({
        id: user.id,
        username: user.username,
        fullName: user.fullName,
        email: user.email,
        role: user.role,
        department: user.department,
        position: user.position,
        profileImage: user.profileImage
      });
    } catch (error) {
      console.error("Create user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Employee endpoints
  router.get("/employees", async (req, res) => {
    try {
      const employees = await storage.getAllEmployees();
      return res.status(200).json(employees);
    } catch (error) {
      console.error("Get employees error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.get("/employees/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }

      return res.status(200).json(employee);
    } catch (error) {
      console.error("Get employee error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/employees", async (req, res) => {
    try {
      const employeeData = validateRequestBody(insertEmployeeSchema, req.body);
      const employee = await storage.createEmployee(employeeData);
      
      // Create activity log
      await storage.createActivityLog({
        userId: employeeData.userId,
        action: "create",
        details: `Employee created: ${employeeData.firstName} ${employeeData.lastName}`
      });

      return res.status(201).json(employee);
    } catch (error) {
      console.error("Create employee error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Department endpoints
  router.get("/departments", async (req, res) => {
    try {
      const departments = await storage.getAllDepartments();
      return res.status(200).json(departments);
    } catch (error) {
      console.error("Get departments error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Leave request endpoints
  router.get("/leave-requests", async (req, res) => {
    try {
      const leaveRequests = await storage.getAllLeaveRequests();
      return res.status(200).json(leaveRequests);
    } catch (error) {
      console.error("Get leave requests error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.get("/leave-requests/employee/:id", async (req, res) => {
    try {
      const employeeId = parseInt(req.params.id);
      const leaveRequests = await storage.getLeaveRequestsByEmployee(employeeId);
      return res.status(200).json(leaveRequests);
    } catch (error) {
      console.error("Get employee leave requests error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/leave-requests", async (req, res) => {
    try {
      const leaveRequestData = validateRequestBody(insertLeaveRequestSchema, req.body);
      const leaveRequest = await storage.createLeaveRequest(leaveRequestData);
      
      // Create activity log
      await storage.createActivityLog({
        userId: leaveRequestData.employeeId,
        action: "create",
        details: `Leave request created from ${leaveRequestData.startDate} to ${leaveRequestData.endDate}`
      });

      return res.status(201).json(leaveRequest);
    } catch (error) {
      console.error("Create leave request error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.patch("/leave-requests/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, approvedBy } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const updatedLeaveRequest = await storage.updateLeaveRequest(id, status, approvedBy);
      
      if (!updatedLeaveRequest) {
        return res.status(404).json({ message: "Leave request not found" });
      }
      
      // Create activity log
      await storage.createActivityLog({
        userId: approvedBy || 1,
        action: "update",
        details: `Leave request ${id} updated to ${status}`
      });

      return res.status(200).json(updatedLeaveRequest);
    } catch (error) {
      console.error("Update leave request error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Attendance endpoints
  router.get("/attendance", async (req, res) => {
    try {
      if (req.query.date) {
        const date = new Date(req.query.date as string);
        const attendance = await storage.getAttendanceByDate(date);
        return res.status(200).json(attendance);
      }
      
      if (req.query.employeeId) {
        const employeeId = parseInt(req.query.employeeId as string);
        const attendance = await storage.getAttendanceByEmployee(employeeId);
        return res.status(200).json(attendance);
      }
      
      return res.status(400).json({ message: "Date or employeeId query parameter is required" });
    } catch (error) {
      console.error("Get attendance error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/attendance", async (req, res) => {
    try {
      const attendanceData = validateRequestBody(insertAttendanceSchema, req.body);
      const attendance = await storage.createAttendance(attendanceData);
      
      return res.status(201).json(attendance);
    } catch (error) {
      console.error("Create attendance error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Performance review endpoints
  router.get("/performance-reviews", async (req, res) => {
    try {
      if (req.query.employeeId) {
        const employeeId = parseInt(req.query.employeeId as string);
        const reviews = await storage.getPerformanceReviewsByEmployee(employeeId);
        return res.status(200).json(reviews);
      }
      
      return res.status(400).json({ message: "EmployeeId query parameter is required" });
    } catch (error) {
      console.error("Get performance reviews error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/performance-reviews", async (req, res) => {
    try {
      const reviewData = validateRequestBody(insertPerformanceReviewSchema, req.body);
      const review = await storage.createPerformanceReview(reviewData);
      
      // Create activity log
      await storage.createActivityLog({
        userId: reviewData.reviewerId,
        action: "create",
        details: `Performance review created for employee ${reviewData.employeeId}`
      });

      return res.status(201).json(review);
    } catch (error) {
      console.error("Create performance review error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Job listing endpoints
  router.get("/job-listings", async (req, res) => {
    try {
      const jobListings = await storage.getAllJobListings();
      return res.status(200).json(jobListings);
    } catch (error) {
      console.error("Get job listings error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/job-listings", async (req, res) => {
    try {
      const jobListingData = validateRequestBody(insertJobListingSchema, req.body);
      const jobListing = await storage.createJobListing(jobListingData);
      
      return res.status(201).json(jobListing);
    } catch (error) {
      console.error("Create job listing error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Candidate endpoints
  router.get("/candidates", async (req, res) => {
    try {
      if (req.query.jobId) {
        const jobId = parseInt(req.query.jobId as string);
        const candidates = await storage.getCandidatesByJob(jobId);
        return res.status(200).json(candidates);
      }
      
      return res.status(400).json({ message: "JobId query parameter is required" });
    } catch (error) {
      console.error("Get candidates error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/candidates", async (req, res) => {
    try {
      const candidateData = validateRequestBody(insertCandidateSchema, req.body);
      const candidate = await storage.createCandidate(candidateData);
      
      return res.status(201).json(candidate);
    } catch (error) {
      console.error("Create candidate error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // AI candidate screening endpoint
  router.post("/ai/screen-candidate", async (req, res) => {
    try {
      const { candidateId, resume } = req.body;
      
      if (!candidateId || !resume) {
        return res.status(400).json({ message: "CandidateId and resume are required" });
      }
      
      const candidate = await storage.getCandidate(parseInt(candidateId));
      
      if (!candidate) {
        return res.status(404).json({ message: "Candidate not found" });
      }
      
      const jobListing = await storage.getJobListing(candidate.jobId);
      
      if (!jobListing) {
        return res.status(404).json({ message: "Job listing not found" });
      }
      
      // Check if OpenAI client is available
      if (!openai) {
        // Return enhanced mock data if OpenAI is not initialized
        console.log("OpenAI client not initialized, returning advanced mock analysis");
        
        // Generate a realistic score based on candidate's name (for consistency)
        const nameSum = (candidate.firstName + candidate.lastName).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
        const score = Math.max(60, Math.min(95, (nameSum % 36) + 60)); // Score between 60-95
        
        let feedback, recommendation;
        
        if (score > 85) {
          feedback = `${candidate.firstName} demonstrates strong qualifications and experience relevant to the ${jobListing.title} position.`;
          recommendation = "highly recommend";
        } else if (score > 75) {
          feedback = `${candidate.firstName} has adequate qualifications for the ${jobListing.title} role with some relevant experience.`;
          recommendation = "interview";
        } else {
          feedback = `${candidate.firstName}'s qualifications partially match the requirements for the ${jobListing.title} position.`;
          recommendation = "consider";
        }
        
        const mockAnalysis = {
          score,
          feedback,
          recommendation,
          skills_match: {
            matched: ["Communication", "Problem Solving", "Team Collaboration"],
            missing: ["Leadership", "Advanced Technical Skills"]
          },
          experience_alignment: score > 80 ? "High" : score > 70 ? "Medium" : "Low",
          interview_readiness: score > 75
        };
        
        // Update candidate with mock analysis
        await storage.updateCandidate(candidate.id, {
          aiScore: mockAnalysis.score,
          aiNotes: JSON.stringify(mockAnalysis)
        });
        
        return res.status(200).json(mockAnalysis);
      }
      
      // Analyze candidate using OpenAI
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: `You are an advanced AI talent acquisition assistant for Synovatech. 
              Analyze this candidate's resume against the job requirements and provide a comprehensive evaluation.
              
              Job Title: ${jobListing.title}
              Department: ${jobListing.department}
              Description: ${jobListing.description}
              Requirements: ${jobListing.requirements}`
            },
            {
              role: "user",
              content: `Candidate: ${candidate.firstName} ${candidate.lastName}
              Resume: ${resume}
              
              Provide a detailed analysis with the following:
              1. Extract key skills from the resume
              2. Compare them against the job requirements
              3. Identify skills gaps or mismatches
              4. Calculate a match score from 0-100
              5. Provide specific feedback on strengths and weaknesses
              
              Return your analysis as JSON with these fields:
              - score: A number from 0-100 indicating overall match
              - skills_match: Object with "matched" and "missing" arrays of skills
              - feedback: Detailed evaluation of candidate's qualifications
              - recommendation: Your recommendation (reject, consider, interview, highly recommend)
              - experience_alignment: String indicating "Low", "Medium", or "High" alignment with required experience
              - interview_readiness: Boolean indicating if candidate is ready for interview`
            }
          ],
          response_format: { type: "json_object" }
        });
        
        const analysis = JSON.parse(response.choices[0].message.content);
        
        // Update candidate with AI analysis
        await storage.updateCandidate(candidate.id, {
          aiScore: analysis.score,
          aiNotes: JSON.stringify(analysis)
        });
        
        return res.status(200).json(analysis);
      } catch (error) {
        console.error("OpenAI API error:", error);
        
        // Provide a fallback analysis if API call fails
        const fallbackAnalysis = {
          score: 75,
          feedback: `The system encountered issues while analyzing ${candidate.firstName}'s qualifications for the ${jobListing.title} position.`,
          recommendation: "manual review recommended",
          skills_match: {
            matched: [],
            missing: []
          },
          experience_alignment: "Unknown",
          interview_readiness: false
        };
        
        await storage.updateCandidate(candidate.id, {
          aiScore: fallbackAnalysis.score,
          aiNotes: JSON.stringify(fallbackAnalysis)
        });
        
        return res.status(200).json(fallbackAnalysis);
      }
    } catch (error) {
      console.error("Screen candidate error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // AI-powered interview question generation endpoint
  router.post("/ai/generate-interview-questions", async (req, res) => {
    try {
      const { jobId, candidateId, resumeText } = req.body;
      
      if (!jobId) {
        return res.status(400).json({ message: "JobId is required" });
      }
      
      const jobListing = await storage.getJobListing(parseInt(jobId));
      
      if (!jobListing) {
        return res.status(404).json({ message: "Job listing not found" });
      }
      
      let candidateName = "the candidate";
      let candidateResume = resumeText || "";
      
      // If candidateId is provided, get candidate information
      if (candidateId) {
        const candidate = await storage.getCandidate(parseInt(candidateId));
        if (candidate) {
          candidateName = `${candidate.firstName} ${candidate.lastName}`;
          // If resume text wasn't provided but candidateId was, we'll generate general questions
        }
      }
      
      // Check if OpenAI client is available
      if (!openai) {
        console.log("OpenAI client not initialized, returning predefined interview questions");
        
        const generalQuestions = [
          "Tell me about your experience related to this role.",
          "What interests you most about this position?",
          "Describe a challenging situation you faced at work and how you resolved it.",
          "How do you prioritize tasks when working under pressure?",
          "What are your key strengths that make you suitable for this position?"
        ];
        
        const technicalQuestions = [
          `What experience do you have working with technologies mentioned in the ${jobListing.title} role?`,
          "Describe a project where you used your technical skills effectively.",
          `How would you approach solving ${jobListing.department}-related problems?`
        ];
        
        const behavioralQuestions = [
          "Tell me about a time when you had to adapt quickly to a significant change at work.",
          "Describe a situation where you had to collaborate with a difficult team member.",
          "How do you handle feedback and criticism?"
        ];
        
        return res.status(200).json({
          general: generalQuestions,
          technical: technicalQuestions,
          behavioral: behavioralQuestions,
          custom: []
        });
      }
      
      // Generate tailored interview questions using OpenAI
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: `You are an expert HR interviewer for Synovatech, specializing in technical and behavioral interviews. 
              Your task is to generate thoughtful, relevant interview questions for a ${jobListing.title} position.
              
              Job Details:
              - Title: ${jobListing.title}
              - Department: ${jobListing.department}
              - Description: ${jobListing.description || ""}
              - Requirements: ${jobListing.requirements || ""}`
            },
            {
              role: "user",
              content: `Generate a comprehensive set of interview questions for ${candidateName} applying for the ${jobListing.title} position.
              ${candidateResume ? `Based on their resume: ${candidateResume}` : ""}
              
              Create four categories of questions:
              1. General questions about experience and interest in the role
              2. Technical questions specific to the required skills
              3. Behavioral questions to assess cultural fit and soft skills
              4. Custom questions tailored specifically to this candidate's background
              
              Format the response as a JSON object with these fields:
              - general: Array of general interview questions
              - technical: Array of technical questions
              - behavioral: Array of behavioral questions
              - custom: Array of questions tailored to the candidate (if resume provided)`
            }
          ],
          response_format: { type: "json_object" }
        });
        
        const questions = JSON.parse(response.choices[0].message.content);
        return res.status(200).json(questions);
      } catch (error) {
        console.error("OpenAI API error:", error);
        
        // Provide fallback questions if API call fails
        return res.status(200).json({
          general: [
            "What interested you in applying for this position?",
            "Tell me about your relevant experience for this role.",
            "What are your career goals?"
          ],
          technical: [
            "What technical skills do you possess that are relevant to this role?",
            "Describe your experience with industry-specific tools and technologies."
          ],
          behavioral: [
            "Describe a situation where you had to work under pressure.",
            "How do you handle conflicts in the workplace?"
          ],
          custom: []
        });
      }
    } catch (error) {
      console.error("Generate interview questions error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // AI-powered job description optimization endpoint
  // AI-powered resume parser endpoint
  router.post("/ai/parse-resume", async (req, res) => {
    try {
      const { resumeText } = req.body;
      
      if (!resumeText) {
        return res.status(400).json({ message: "Resume text is required" });
      }

      // Check if OpenAI client is available
      if (!openai) {
        console.log("OpenAI client not initialized, returning basic resume parsing");
        
        // Extract basic information based on resume content
        const resumeLines = resumeText.split('\n');
        const skills = [];
        const education = [];
        const experience = [];
        
        // Simple parsing based on keywords
        resumeLines.forEach(line => {
          const normalizedLine = line.toLowerCase().trim();
          if (normalizedLine.includes('skill') || normalizedLine.includes('technical') || normalizedLine.includes('proficient') || normalizedLine.includes('experience with')) {
            // Add any line containing potential skills
            skills.push(line.trim());
          } else if (normalizedLine.includes('university') || normalizedLine.includes('education') || normalizedLine.includes('degree') || normalizedLine.includes('college') || normalizedLine.includes('school')) {
            // Add any line containing education information
            education.push(line.trim());
          } else if (normalizedLine.includes('work experience') || normalizedLine.includes('employment') || normalizedLine.includes('job') || normalizedLine.includes('position')) {
            // Add any line containing work experience
            experience.push(line.trim());
          }
        });
        
        return res.status(200).json({
          skills: skills.length > 0 ? skills : ["Communication", "Teamwork", "Problem Solving"],
          education: education.length > 0 ? education : ["Education information not clearly identified"],
          experience: experience.length > 0 ? experience : ["Experience information not clearly identified"],
          years_of_experience: "Unknown",
          highlights: ["Resume parsed without AI assistance - limited extraction capabilities"]
        });
      }
      
      // Parse resume using OpenAI
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: `You are an expert resume parser for Synovatech's HR department.
              Analyze the provided resume to extract key information.
              Be comprehensive, detailed, and organize the information clearly.`
            },
            {
              role: "user",
              content: `Parse the following resume and extract key information:
              
              ${resumeText}
              
              Extract and organize the following information in JSON format:
              - contact_info: Object containing name, email, phone, location if available
              - skills: Array of all technical and soft skills mentioned
              - education: Array of education details (degree, institution, dates)
              - experience: Array of work experiences (company, position, dates, descriptions)
              - years_of_experience: Estimated total years of relevant experience
              - certifications: Array of professional certifications if any
              - highlights: Array of key qualifications or achievements
              - keywords: Array of industry-specific keywords found in the resume`
            }
          ],
          response_format: { type: "json_object" }
        });
        
        const parsedResume = JSON.parse(response.choices[0].message.content);
        return res.status(200).json(parsedResume);
      } catch (error) {
        console.error("OpenAI API error:", error);
        
        // Provide a basic parsed response if API call fails
        return res.status(200).json({
          skills: ["Communication", "Problem Solving", "Team Collaboration"],
          education: ["Education details could not be extracted"],
          experience: ["Experience details could not be extracted"],
          years_of_experience: "Unknown",
          highlights: ["Resume parsing encountered an issue"]
        });
      }
    } catch (error) {
      console.error("Parse resume error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/ai/optimize-job-description", async (req, res) => {
    try {
      const { jobId, originalDescription, targetAudience, inclusivityFocus } = req.body;
      
      if (!jobId && !originalDescription) {
        return res.status(400).json({ message: "Either jobId or originalDescription is required" });
      }
      
      let description = originalDescription;
      let title = "Job Position";
      let requirements = "";
      
      // If jobId is provided, get existing job listing data
      if (jobId) {
        const jobListing = await storage.getJobListing(parseInt(jobId));
        if (!jobListing) {
          return res.status(404).json({ message: "Job listing not found" });
        }
        
        title = jobListing.title;
        description = jobListing.description;
        requirements = jobListing.requirements;
      }
      
      // Check if OpenAI client is available
      if (!openai) {
        console.log("OpenAI client not initialized, returning enhanced job description");
        
        const enhancedDescription = description + "\n\nAt Synovatech, we value diversity and inclusion. We encourage applications from candidates of all backgrounds and provide equal opportunities for growth and advancement.";
        
        return res.status(200).json({
          original: description,
          optimized: enhancedDescription,
          suggestions: [
            "Add specific qualifications required for the role",
            "Include information about company culture",
            "Mention growth opportunities"
          ],
          inclusivity_score: 8,
          clarity_score: 7
        });
      }
      
      // Generate optimized job description using OpenAI
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: `You are an expert in talent acquisition and inclusive job description writing for Synovatech.
              Your task is to optimize job descriptions to attract diverse, qualified candidates.
              
              Focus on:
              1. Clear, concise language
              2. Inclusive terminology
              3. Highlighting key requirements
              4. Removing biased language
              5. Making the role appealing to the target audience
              ${inclusivityFocus ? `6. Special focus on inclusivity for: ${inclusivityFocus}` : ""}`
            },
            {
              role: "user",
              content: `Optimize this job description for the ${title} position${targetAudience ? ` targeting ${targetAudience}` : ""}.
              
              Original Description:
              ${description}
              
              Requirements:
              ${requirements}
              
              Return a JSON response with these fields:
              - original: The original job description
              - optimized: The optimized job description
              - suggestions: Array of suggestions for further improvement
              - inclusivity_score: Number from 1-10 rating the original description's inclusivity
              - clarity_score: Number from 1-10 rating the original description's clarity`
            }
          ],
          response_format: { type: "json_object" }
        });
        
        const optimization = JSON.parse(response.choices[0].message.content);
        return res.status(200).json(optimization);
      } catch (error) {
        console.error("OpenAI API error:", error);
        
        // Provide a basic response if API call fails
        return res.status(200).json({
          original: description,
          optimized: description,
          suggestions: ["Could not generate suggestions at this time."],
          inclusivity_score: 5,
          clarity_score: 5
        });
      }
    } catch (error) {
      console.error("Optimize job description error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // AI performance analysis endpoint
  router.post("/ai/analyze-performance", async (req, res) => {
    try {
      const { employeeId } = req.body;
      
      if (!employeeId) {
        return res.status(400).json({ message: "EmployeeId is required" });
      }
      
      const employee = await storage.getEmployee(parseInt(employeeId));
      
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      
      const performanceReviews = await storage.getPerformanceReviewsByEmployee(employee.id);
      
      if (performanceReviews.length === 0) {
        return res.status(404).json({ message: "No performance reviews found for this employee" });
      }
      
      // Check if OpenAI API key is available
      if (!process.env.OPENAI_API_KEY) {
        // Return mock data in development environment
        console.log("OpenAI API key not available, returning mock performance analysis");
        const mockAnalysis = {
          strengths: ["Communication skills", "Time management", "Technical expertise"],
          areas_for_improvement: ["Leadership development", "Strategic planning"],
          trend: "improving",
          recommendations: ["Consider leadership training", "Take on more project management responsibilities"],
          summary: "This is a mock performance analysis as OpenAI API key is not configured."
        };
        
        return res.status(200).json(mockAnalysis);
      }
      
      // Analyze performance using OpenAI (if client is available)
      try {
        if (!openai) {
          throw new Error("OpenAI client not initialized");
        }
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: "You are an AI HR analyst for Synovatech. Analyze this employee's performance reviews and provide insights and recommendations."
            },
            {
              role: "user",
              content: `Employee: ${employee.firstName} ${employee.lastName}
              Department: ${employee.department || "Not specified"}
              Position: ${employee.position || "Not specified"}
              Performance Reviews: ${JSON.stringify(performanceReviews)}
              
              Provide your analysis as JSON with the following fields:
              - strengths: Array of the employee's key strengths
              - areas_for_improvement: Array of areas where the employee can improve
              - trend: Performance trend (improving, declining, stable)
              - recommendations: Array of specific recommendations for the employee's development
              - summary: A brief summary of the analysis`
            }
          ],
          response_format: { type: "json_object" }
        });
        
        const analysis = JSON.parse(response.choices[0].message.content);
        return res.status(200).json(analysis);
      } catch (error) {
        console.error("OpenAI API error:", error);
        return res.status(500).json({ message: "Error during AI analysis" });
      }
    } catch (error) {
      console.error("Analyze performance error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Employee comparison endpoint
  router.post("/ai/compare-employees", async (req, res) => {
    try {
      const { employee1Id, employee2Id } = req.body;
      
      if (!employee1Id || !employee2Id) {
        return res.status(400).json({ message: "Both employee IDs are required" });
      }
      
      const employee1 = await storage.getEmployee(parseInt(employee1Id));
      const employee2 = await storage.getEmployee(parseInt(employee2Id));
      
      if (!employee1 || !employee2) {
        return res.status(404).json({ message: "One or both employees not found" });
      }
      
      // Get performance reviews for both employees
      const employee1Reviews = await storage.getPerformanceReviewsByEmployee(employee1.id);
      const employee2Reviews = await storage.getPerformanceReviewsByEmployee(employee2.id);
      
      // Check if OpenAI API key is available
      if (!process.env.OPENAI_API_KEY || !openai) {
        // Return mock data in development environment
        console.log("OpenAI API key not available, returning mock employee comparison");
        const mockComparison = {
          employee1: {
            id: employee1.id,
            name: `${employee1.firstName} ${employee1.lastName}`,
            strengths: ["Communication", "Project management", "Technical expertise"],
            weaknesses: ["Strategic planning", "Delegation"]
          },
          employee2: {
            id: employee2.id,
            name: `${employee2.firstName} ${employee2.lastName}`,
            strengths: ["Innovation", "Problem solving", "Customer relations"],
            weaknesses: ["Time management", "Documentation"]
          },
          comparison: {
            similarities: ["Both are strong communicators", "Both show leadership potential"],
            differences: ["Different technical expertise areas", "Different working styles"],
            complementary_skills: ["Project management + innovation", "Technical expertise + customer focus"]
          },
          recommendations: {
            collaboration: ["Joint leadership of the upcoming marketing campaign", "Co-mentoring in respective strength areas"],
            mentoring: [`${employee1.firstName} can mentor ${employee2.firstName} in project management`, `${employee2.firstName} can mentor ${employee1.firstName} in innovation`],
            team_formation: "These employees would make an effective team for creative projects requiring technical implementation"
          },
          potential_projects: ["New product development", "Department workflow optimization", "Customer experience enhancement initiative"]
        };
        
        return res.status(200).json(mockComparison);
      }
      
      // If OpenAI is available, use it for analysis
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: "You are an AI HR analyst for Synovatech. Compare these two employees based on their profiles and performance reviews. Identify similarities, differences, complementary skills, and provide recommendations for collaboration and team formation."
            },
            {
              role: "user",
              content: `
              Employee 1: ${employee1.firstName} ${employee1.lastName}
              Department: ${employee1.department || "Not specified"}
              Position: ${employee1.position || "Not specified"}
              Performance Reviews: ${JSON.stringify(employee1Reviews)}
              
              Employee 2: ${employee2.firstName} ${employee2.lastName}
              Department: ${employee2.department || "Not specified"}
              Position: ${employee2.position || "Not specified"}
              Performance Reviews: ${JSON.stringify(employee2Reviews)}
              
              Provide your comparison as JSON with the following structure:
              {
                "employee1": {
                  "id": number,
                  "name": string,
                  "strengths": string[],
                  "weaknesses": string[]
                },
                "employee2": {
                  "id": number,
                  "name": string,
                  "strengths": string[],
                  "weaknesses": string[]
                },
                "comparison": {
                  "similarities": string[],
                  "differences": string[],
                  "complementary_skills": string[]
                },
                "recommendations": {
                  "collaboration": string[],
                  "mentoring": string[],
                  "team_formation": string
                },
                "potential_projects": string[]
              }`
            }
          ],
          response_format: { type: "json_object" }
        });
        
        const analysis = JSON.parse(response.choices[0].message.content);
        return res.status(200).json(analysis);
      } catch (error) {
        console.error("OpenAI API error:", error);
        return res.status(500).json({ message: "Error during AI analysis" });
      }
    } catch (error) {
      console.error("Compare employees error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Team composition analysis endpoint
  router.post("/ai/analyze-team", async (req, res) => {
    try {
      const { teamId } = req.body;
      
      if (!teamId || !Array.isArray(teamId) || teamId.length === 0) {
        return res.status(400).json({ message: "Team IDs array is required" });
      }
      
      // Get all employees in the team
      const employees = [];
      for (const id of teamId) {
        const employee = await storage.getEmployee(parseInt(id));
        if (employee) {
          employees.push(employee);
        }
      }
      
      if (employees.length === 0) {
        return res.status(404).json({ message: "No valid employees found in the team" });
      }
      
      // Get performance reviews for each employee
      const employeeReviews = {};
      for (const employee of employees) {
        employeeReviews[employee.id] = await storage.getPerformanceReviewsByEmployee(employee.id);
      }
      
      // Check if OpenAI API key is available
      if (!process.env.OPENAI_API_KEY || !openai) {
        // Return mock data in development environment
        console.log("OpenAI API key not available, returning mock team analysis");
        const mockTeamAnalysis = {
          team_strengths: ["Technical expertise", "Project management", "Communication", "Problem solving"],
          team_gaps: ["Design thinking", "Market analysis", "Strategic planning"],
          skill_distribution: {
            "Technical": 65,
            "Leadership": 30,
            "Communication": 50,
            "Problem solving": 45
          },
          role_distribution: {
            "Developer": 40,
            "Manager": 20,
            "Analyst": 30,
            "Support": 10
          },
          team_recommendations: ["Focus on strategic planning", "Develop market analysis skills", "Cross-train in design thinking"],
          team_development_areas: ["Strategic vision", "Customer experience design", "Innovative thinking"],
          optimal_additions: [
            {
              role: "UX Designer",
              skills: ["User research", "Interface design", "Prototyping"],
              justification: "Would complement the technical expertise with design thinking"
            },
            {
              role: "Strategic Analyst",
              skills: ["Market analysis", "Competitive intelligence", "Strategic planning"],
              justification: "Would address the team's gap in strategic planning"
            }
          ]
        };
        
        return res.status(200).json(mockTeamAnalysis);
      }
      
      // If OpenAI is available, use it for analysis
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: "You are an AI HR analyst for Synovatech. Analyze this team's composition based on employee profiles and performance reviews. Identify team strengths, gaps, skill distribution, and provide recommendations for team development."
            },
            {
              role: "user",
              content: `
              Team Members: ${JSON.stringify(employees)}
              Performance Reviews: ${JSON.stringify(employeeReviews)}
              
              Provide your analysis as JSON with the following structure:
              {
                "team_strengths": string[],
                "team_gaps": string[],
                "skill_distribution": { [skill: string]: number },
                "role_distribution": { [role: string]: number },
                "team_recommendations": string[],
                "team_development_areas": string[],
                "optimal_additions": [
                  {
                    "role": string,
                    "skills": string[],
                    "justification": string
                  }
                ]
              }`
            }
          ],
          response_format: { type: "json_object" }
        });
        
        const analysis = JSON.parse(response.choices[0].message.content);
        return res.status(200).json(analysis);
      } catch (error) {
        console.error("OpenAI API error:", error);
        return res.status(500).json({ message: "Error during AI analysis" });
      }
    } catch (error) {
      console.error("Analyze team error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Document endpoints
  router.get("/documents", async (req, res) => {
    try {
      if (req.query.ownerId) {
        const ownerId = parseInt(req.query.ownerId as string);
        const documents = await storage.getDocumentsByOwner(ownerId);
        return res.status(200).json(documents);
      }
      
      const documents = await storage.getAllDocuments();
      return res.status(200).json(documents);
    } catch (error) {
      console.error("Get documents error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/documents", async (req, res) => {
    try {
      const documentData = validateRequestBody(insertDocumentSchema, req.body);
      const document = await storage.createDocument(documentData);
      
      // Create activity log
      await storage.createActivityLog({
        userId: documentData.ownerId,
        action: "create",
        details: `Document created: ${documentData.title}`
      });

      return res.status(201).json(document);
    } catch (error) {
      console.error("Create document error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Task endpoints
  router.get("/tasks", async (req, res) => {
    try {
      if (req.query.assignedTo) {
        const assignedTo = parseInt(req.query.assignedTo as string);
        const tasks = await storage.getTasksByAssignee(assignedTo);
        return res.status(200).json(tasks);
      }
      
      const tasks = await storage.getAllTasks();
      return res.status(200).json(tasks);
    } catch (error) {
      console.error("Get tasks error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/tasks", async (req, res) => {
    try {
      const taskData = validateRequestBody(insertTaskSchema, req.body);
      const task = await storage.createTask(taskData);
      
      // Broadcast task creation to connected clients
      broadcast({
        type: "TASK_CREATED",
        payload: task
      });
      
      return res.status(201).json(task);
    } catch (error) {
      console.error("Create task error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.patch("/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const taskData = req.body;
      
      const updatedTask = await storage.updateTask(id, taskData);
      
      if (!updatedTask) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Broadcast task update to connected clients
      broadcast({
        type: "TASK_UPDATED",
        payload: updatedTask
      });
      
      return res.status(200).json(updatedTask);
    } catch (error) {
      console.error("Update task error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Event endpoints
  router.get("/events", async (req, res) => {
    try {
      if (req.query.date) {
        const date = new Date(req.query.date as string);
        const events = await storage.getEventsByDate(date);
        return res.status(200).json(events);
      }
      
      const events = await storage.getAllEvents();
      return res.status(200).json(events);
    } catch (error) {
      console.error("Get events error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.post("/events", async (req, res) => {
    try {
      const eventData = validateRequestBody(insertEventSchema, req.body);
      const event = await storage.createEvent(eventData);
      
      // Create activity log
      await storage.createActivityLog({
        userId: eventData.organizer,
        action: "create",
        details: `Event created: ${eventData.title} on ${eventData.date}`
      });
      
      // Broadcast event creation to connected clients
      broadcast({
        type: "EVENT_CREATED",
        payload: event
      });
      
      return res.status(201).json(event);
    } catch (error) {
      console.error("Create event error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Activity log endpoints
  router.get("/activity-logs", async (req, res) => {
    try {
      if (req.query.userId) {
        const userId = parseInt(req.query.userId as string);
        const logs = await storage.getActivityLogsByUser(userId);
        return res.status(200).json(logs);
      }
      
      if (req.query.limit) {
        const limit = parseInt(req.query.limit as string);
        const logs = await storage.getRecentActivityLogs(limit);
        return res.status(200).json(logs);
      }
      
      return res.status(400).json({ message: "UserId or limit query parameter is required" });
    } catch (error) {
      console.error("Get activity logs error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // AI Assistant endpoint
  router.post("/ai/assistant", async (req, res) => {
    try {
      const { query } = req.body;
      
      if (!query) {
        return res.status(400).json({ message: "Query is required" });
      }
      
      // Check if OpenAI client was successfully initialized
      if (!openai) {
        // Return mock response when OpenAI client isn't available
        console.log("OpenAI client not initialized, returning mock assistant response");
        
        // Generate mock response based on the query
        let mockResponse = "I'm ZenaI Assistant. I can help with HR questions and tasks.";
        
        if (query.toLowerCase().includes("onboarding")) {
          mockResponse = "Best practices for employee onboarding include: 1) Prepare workspace and tools before day one, 2) Create a structured first-week schedule, 3) Assign a mentor or buddy, 4) Schedule regular check-ins, and 5) Gather feedback to improve the process.";
        } else if (query.toLowerCase().includes("performance") || query.toLowerCase().includes("review")) {
          mockResponse = "Effective performance reviews should be objective, focused on both achievements and areas for growth, and include specific examples. Schedule them regularly and ensure two-way communication.";
        } else if (query.toLowerCase().includes("retention")) {
          mockResponse = "To improve employee retention: 1) Offer competitive compensation, 2) Provide development opportunities, 3) Recognize achievements, 4) Foster work-life balance, and 5) Create a positive culture.";
        }
        
        return res.status(200).json({
          response: mockResponse + " Note: This is a mock response as the OpenAI API key is not properly configured."
        });
      }
      
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
          messages: [
            {
              role: "system",
              content: `You are ZenaI Assistant, an AI-powered HR assistant for Synovatech One HR system. 
              You help HR professionals with their tasks and provide relevant information about HR processes, policies, and best practices.
              Keep responses concise, professional, and focused on HR-related topics.`
            },
            {
              role: "user",
              content: query
            }
          ]
        });
        
        return res.status(200).json({
          response: response.choices[0].message.content
        });
      } catch (error) {
        console.error("OpenAI API error:", error);
        
        // Fallback to mock response if API call fails
        return res.status(200).json({
          response: "I'm sorry, I couldn't process your request through the OpenAI API. As a fallback, I can tell you that best practices in HR include regular communication, clear documentation, and fair treatment of all employees. Please try again later for more specific assistance."
        });
      }
    } catch (error) {
      console.error("AI Assistant error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // HR Analytics endpoints
  router.get("/analytics/department-distribution", async (req, res) => {
    try {
      const employees = await storage.getAllEmployees();
      
      // Count employees by department
      const departments: Record<string, number> = {};
      employees.forEach(employee => {
        if (employee.department) {
          departments[employee.department] = (departments[employee.department] || 0) + 1;
        }
      });
      
      // Calculate percentages
      const total = employees.length;
      const distribution = Object.entries(departments).map(([department, count]) => ({
        department,
        count,
        percentage: Math.round((count / total) * 100)
      }));
      
      return res.status(200).json(distribution);
    } catch (error) {
      console.error("Get department distribution error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.get("/analytics/attendance-rate", async (req, res) => {
    try {
      const today = new Date();
      const oneMonthAgo = new Date();
      oneMonthAgo.setMonth(today.getMonth() - 1);
      
      // For a real implementation, we would query attendance records for the past month
      // For now, return a mock value
      return res.status(200).json({
        rate: 98.2,
        period: {
          start: oneMonthAgo,
          end: today
        }
      });
    } catch (error) {
      console.error("Get attendance rate error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  router.get("/analytics/summary", async (req, res) => {
    try {
      const employees = await storage.getAllEmployees();
      const jobListings = await storage.getAllJobListings();
      const openPositions = jobListings.filter(job => job.status === "open").length;
      
      // In a real implementation, we would calculate these values from actual data
      return res.status(200).json({
        totalEmployees: employees.length,
        openPositions,
        attendanceRate: 98.2,
        pendingReviews: 8
      });
    } catch (error) {
      console.error("Get analytics summary error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Setup seed data for employees if there are none
  async function seedEmployeeData() {
    const existingEmployees = await storage.getAllEmployees();
    if (existingEmployees.length === 0) {
      // Create some employees
      await storage.createEmployee({
        userId: 1,
        employeeId: "EMP001",
        firstName: "Admin",
        lastName: "User",
        email: "admin@synovatech.com",
        phone: "123-456-7890",
        department: "Human Resources",
        position: "HR Manager",
        hireDate: new Date("2020-01-01"),
        status: "active"
      });
      
      await storage.createEmployee({
        userId: 2,
        employeeId: "EMP002",
        firstName: "Sarah",
        lastName: "Johnson",
        email: "sarah.johnson@synovatech.com",
        phone: "123-456-7891",
        department: "Human Resources",
        position: "HR Manager",
        hireDate: new Date("2020-02-01"),
        status: "active"
      });
      
      await storage.createEmployee({
        userId: 3,
        employeeId: "EMP003",
        firstName: "David",
        lastName: "Kim",
        email: "david.kim@synovatech.com",
        phone: "123-456-7892",
        department: "Engineering",
        position: "Engineering Director",
        hireDate: new Date("2020-03-01"),
        status: "active"
      });
      
      await storage.createEmployee({
        userId: 4,
        employeeId: "EMP004",
        firstName: "Michelle",
        lastName: "Lopez",
        email: "michelle.lopez@synovatech.com",
        phone: "123-456-7893",
        department: "Marketing",
        position: "Marketing Director",
        hireDate: new Date("2020-04-01"),
        status: "active"
      });
      
      // Add more sample employees from various departments
      for (let i = 5; i < 41; i++) {
        const depts = ["Engineering", "Marketing", "Finance", "Human Resources", "Sales"];
        const dept = depts[Math.floor(Math.random() * depts.length)];
        
        const positions = {
          Engineering: ["Software Engineer", "QA Engineer", "DevOps Engineer", "UI/UX Designer"],
          Marketing: ["Marketing Specialist", "Content Writer", "Social Media Manager", "SEO Specialist"],
          Finance: ["Financial Analyst", "Accountant", "Payroll Specialist", "Tax Advisor"],
          "Human Resources": ["HR Specialist", "Recruiter", "Training Coordinator", "Benefits Administrator"],
          Sales: ["Sales Representative", "Account Manager", "Sales Manager", "Business Development"]
        };
        
        const position = positions[dept as keyof typeof positions][Math.floor(Math.random() * positions[dept as keyof typeof positions].length)];
        
        const hireYear = 2018 + Math.floor(Math.random() * 5);
        const hireMonth = Math.floor(Math.random() * 12);
        const hireDay = Math.floor(Math.random() * 28) + 1;
        
        await storage.createEmployee({
          userId: i,
          employeeId: `EMP${i.toString().padStart(3, '0')}`,
          firstName: `First${i}`,
          lastName: `Last${i}`,
          email: `employee${i}@synovatech.com`,
          phone: `123-456-${i.toString().padStart(4, '0')}`,
          department: dept,
          position: position,
          hireDate: new Date(`${hireYear}-${hireMonth + 1}-${hireDay}`),
          status: "active"
        });
      }
      
      // Create some job listings
      const jobTitles = [
        "Senior Software Engineer",
        "Marketing Manager",
        "Financial Analyst",
        "HR Specialist",
        "Sales Representative"
      ];
      
      const departments = [
        "Engineering",
        "Marketing",
        "Finance",
        "Human Resources",
        "Sales"
      ];
      
      for (let i = 0; i < 5; i++) {
        await storage.createJobListing({
          title: jobTitles[i],
          department: departments[i],
          description: `We are looking for a ${jobTitles[i]} to join our ${departments[i]} team.`,
          requirements: "Bachelor's degree, 3+ years of experience",
          salary: "$80,000 - $120,000",
          location: "Remote",
          jobType: "full-time",
          status: "open",
          postedDate: new Date(),
          closingDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
        });
      }
      
      // Create some documents
      const documentTitles = [
        "Employee Handbook",
        "Q2 Performance Review Template",
        "Hiring Plan 2023-2024",
        "Team Building Event Agenda",
        "New Employee Onboarding Checklist"
      ];
      
      for (let i = 0; i < 5; i++) {
        await storage.createDocument({
          title: documentTitles[i],
          type: "policy",
          content: `Content of ${documentTitles[i]}`,
          ownerId: i + 1
        });
      }
      
      // Create some tasks
      const taskTitles = [
        "Complete quarterly performance reviews",
        "Review open applications",
        "Update employee handbook",
        "Send benefits enrollment reminders",
        "Prepare for new employee onboarding"
      ];
      
      for (let i = 0; i < 5; i++) {
        await storage.createTask({
          title: taskTitles[i],
          description: `Task description for ${taskTitles[i]}`,
          assignedTo: i + 1,
          dueDate: new Date(Date.now() + (i + 1) * 24 * 60 * 60 * 1000), // i+1 days from now
          priority: i % 2 === 0 ? "high" : "medium",
          status: "pending"
        });
      }
      
      // Create some events
      const eventTitles = [
        "New Employee Onboarding",
        "Quarterly Team Meeting",
        "Candidate Screening Session",
        "Benefits Enrollment Webinar",
        "Leadership Training Workshop"
      ];
      
      for (let i = 0; i < 5; i++) {
        const eventDate = new Date();
        eventDate.setDate(eventDate.getDate() + i + 1);
        
        await storage.createEvent({
          title: eventTitles[i],
          description: `Event description for ${eventTitles[i]}`,
          date: eventDate,
          startTime: "09:00",
          endTime: "12:00",
          location: i % 2 === 0 ? "Conference Room A" : "Virtual",
          organizer: i + 1,
          status: "planned",
          isAiFeature: i === 2 // Only the candidate screening is AI-powered
        });
      }
      
      // Create some activity logs
      const actions = [
        "login",
        "create",
        "update",
        "view"
      ];
      
      const details = [
        "User logged in",
        "Document created: Employee Handbook",
        "Updated team availability calendar",
        "Viewed employee profiles"
      ];
      
      for (let i = 0; i < 10; i++) {
        const userIdx = Math.floor(Math.random() * 4) + 1;
        const actionIdx = Math.floor(Math.random() * actions.length);
        
        await storage.createActivityLog({
          userId: userIdx,
          action: actions[actionIdx],
          details: details[actionIdx]
        });
      }
    }
  }
  
  // Seed data when server starts
  seedEmployeeData().catch(console.error);

  // Register the router
  app.use("/api", router);

  return httpServer;
}
