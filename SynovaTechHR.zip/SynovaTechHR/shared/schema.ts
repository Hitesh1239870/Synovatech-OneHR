import { pgTable, text, serial, integer, boolean, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("employee"),
  department: text("department"),
  position: text("position"),
  profileImage: text("profile_image"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  role: true,
  department: true,
  position: true,
  profileImage: true,
});

// Employee schema
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  employeeId: text("employee_id").notNull().unique(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  department: text("department"),
  position: text("position"),
  hireDate: date("hire_date").notNull(),
  manager: integer("manager_id"),
  salary: integer("salary"),
  status: text("status").notNull().default("active"),
  profileImage: text("profile_image"),
});

export const insertEmployeeSchema = createInsertSchema(employees).pick({
  userId: true,
  employeeId: true,
  firstName: true,
  lastName: true,
  email: true,
  phone: true,
  department: true,
  position: true,
  hireDate: true,
  manager: true,
  salary: true,
  status: true,
  profileImage: true,
});

// Department schema
export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  managerId: integer("manager_id"),
  description: text("description"),
});

export const insertDepartmentSchema = createInsertSchema(departments).pick({
  name: true,
  managerId: true,
  description: true,
});

// Leave requests schema
export const leaveRequests = pgTable("leave_requests", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  leaveType: text("leave_type").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  reason: text("reason"),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  approvedBy: integer("approved_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertLeaveRequestSchema = createInsertSchema(leaveRequests).pick({
  employeeId: true,
  leaveType: true,
  startDate: true,
  endDate: true,
  reason: true,
  status: true,
  approvedBy: true,
});

// Attendance schema
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  date: date("date").notNull(),
  timeIn: text("time_in"),
  timeOut: text("time_out"),
  status: text("status").notNull(), // present, absent, late, half-day
});

export const insertAttendanceSchema = createInsertSchema(attendance).pick({
  employeeId: true,
  date: true,
  timeIn: true,
  timeOut: true,
  status: true,
});

// Performance reviews schema
export const performanceReviews = pgTable("performance_reviews", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  reviewerId: integer("reviewer_id").notNull(),
  reviewDate: date("review_date").notNull(),
  rating: integer("rating").notNull(), // 1-5
  strengths: text("strengths"),
  weaknesses: text("weaknesses"),
  comments: text("comments"),
  goals: text("goals"),
  status: text("status").notNull().default("pending"), // pending, completed
});

export const insertPerformanceReviewSchema = createInsertSchema(performanceReviews).pick({
  employeeId: true,
  reviewerId: true,
  reviewDate: true,
  rating: true,
  strengths: true,
  weaknesses: true,
  comments: true,
  goals: true,
  status: true,
});

// Job listings schema
export const jobListings = pgTable("job_listings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  department: text("department").notNull(),
  description: text("description").notNull(),
  requirements: text("requirements").notNull(),
  salary: text("salary"),
  location: text("location"),
  jobType: text("job_type").notNull(), // full-time, part-time, contract
  status: text("status").notNull().default("open"), // open, closed, filled
  postedDate: date("posted_date").notNull(),
  closingDate: date("closing_date"),
});

export const insertJobListingSchema = createInsertSchema(jobListings).pick({
  title: true,
  department: true,
  description: true,
  requirements: true,
  salary: true,
  location: true,
  jobType: true,
  status: true,
  postedDate: true,
  closingDate: true,
});

// Candidates schema
export const candidates = pgTable("candidates", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  resumeUrl: text("resume_url"),
  status: text("status").notNull().default("applied"), // applied, screened, interviewing, offered, hired, rejected
  notes: text("notes"),
  aiScore: integer("ai_score"), // AI-generated candidate score
  aiNotes: text("ai_notes"), // AI-generated notes about candidate
  appliedDate: date("applied_date").notNull(),
});

export const insertCandidateSchema = createInsertSchema(candidates).pick({
  jobId: true,
  firstName: true,
  lastName: true,
  email: true,
  phone: true,
  resumeUrl: true,
  status: true,
  notes: true,
  aiScore: true,
  aiNotes: true,
  appliedDate: true,
});

// Documents schema
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  type: text("type").notNull(), // policy, form, contract, etc.
  content: text("content").notNull(),
  ownerId: integer("owner_id").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertDocumentSchema = createInsertSchema(documents).pick({
  title: true,
  type: true,
  content: true,
  ownerId: true,
});

// Tasks schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  assignedTo: integer("assigned_to").notNull(),
  dueDate: date("due_date"),
  priority: text("priority").default("medium"), // low, medium, high
  status: text("status").notNull().default("pending"), // pending, in-progress, completed
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  title: true,
  description: true,
  assignedTo: true,
  dueDate: true,
  priority: true,
  status: true,
});

// Events schema
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  date: date("date").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  location: text("location"),
  organizer: integer("organizer").notNull(),
  status: text("status").notNull().default("planned"), // planned, cancelled, completed
  isAiFeature: boolean("is_ai_feature").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertEventSchema = createInsertSchema(events).pick({
  title: true,
  description: true,
  date: true,
  startTime: true,
  endTime: true,
  location: true,
  organizer: true,
  status: true,
  isAiFeature: true,
});

// Activity logs schema
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  action: text("action").notNull(),
  details: text("details"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).pick({
  userId: true,
  action: true,
  details: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;

export type InsertDepartment = z.infer<typeof insertDepartmentSchema>;
export type Department = typeof departments.$inferSelect;

export type InsertLeaveRequest = z.infer<typeof insertLeaveRequestSchema>;
export type LeaveRequest = typeof leaveRequests.$inferSelect;

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;

export type InsertPerformanceReview = z.infer<typeof insertPerformanceReviewSchema>;
export type PerformanceReview = typeof performanceReviews.$inferSelect;

export type InsertJobListing = z.infer<typeof insertJobListingSchema>;
export type JobListing = typeof jobListings.$inferSelect;

export type InsertCandidate = z.infer<typeof insertCandidateSchema>;
export type Candidate = typeof candidates.$inferSelect;

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
