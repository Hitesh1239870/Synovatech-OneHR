import { create } from 'zustand';

interface AIAssistantState {
  isOpen: boolean;
  toggleAIAssistant: () => void;
  openAIAssistant: () => void;
  closeAIAssistant: () => void;
}

export const useAIAssistant = create<AIAssistantState>((set) => ({
  isOpen: false,
  toggleAIAssistant: () => set((state) => ({ isOpen: !state.isOpen })),
  openAIAssistant: () => set({ isOpen: true }),
  closeAIAssistant: () => set({ isOpen: false }),
}));
