import { apiRequest } from "./queryClient";

interface AIAssistantResponse {
  response: string;
}

export async function queryAIAssistant(query: string): Promise<AIAssistantResponse> {
  try {
    const response = await apiRequest("POST", "/api/ai/assistant", { query });
    return response.json();
  } catch (error) {
    console.error('Error querying AI assistant:', error);
    return {
      response: "I'm unable to process your request at the moment. Please try again later."
    };
  }
}

// Enhanced candidate screening with skill matching
interface CandidateScreeningResult {
  score: number;
  feedback: string;
  recommendation: string;
  skills_match?: {
    matched: string[];
    missing: string[];
  };
  experience_alignment?: string;
  interview_readiness?: boolean;
}

export async function screenCandidate(candidateId: number, resume: string): Promise<CandidateScreeningResult> {
  try {
    const response = await apiRequest("POST", "/api/ai/screen-candidate", { 
      candidateId, 
      resume 
    });
    return response.json();
  } catch (error) {
    console.error('Error screening candidate:', error);
    return {
      score: 0,
      feedback: "There was an error processing this candidate's resume.",
      recommendation: "N/A",
      skills_match: {
        matched: [],
        missing: []
      }
    };
  }
}

// Resume parsing and analysis
interface ParsedResume {
  contact_info?: {
    name?: string;
    email?: string;
    phone?: string;
    location?: string;
  };
  skills: string[];
  education: string[];
  experience: string[];
  years_of_experience: string | number;
  certifications?: string[];
  highlights: string[];
  keywords?: string[];
}

export async function parseResume(resumeText: string): Promise<ParsedResume> {
  try {
    const response = await apiRequest("POST", "/api/ai/parse-resume", { resumeText });
    return response.json();
  } catch (error) {
    console.error('Error parsing resume:', error);
    return {
      skills: [],
      education: [],
      experience: [],
      years_of_experience: "Unknown",
      highlights: ["Error parsing resume"]
    };
  }
}

// Interview question generation
interface InterviewQuestions {
  general: string[];
  technical: string[];
  behavioral: string[];
  custom: string[];
}

export async function generateInterviewQuestions(
  jobId: number, 
  candidateId?: number, 
  resumeText?: string
): Promise<InterviewQuestions> {
  try {
    const response = await apiRequest("POST", "/api/ai/generate-interview-questions", { 
      jobId, 
      candidateId,
      resumeText
    });
    return response.json();
  } catch (error) {
    console.error('Error generating interview questions:', error);
    return {
      general: ["What interested you in applying for this position?"],
      technical: ["What relevant technical skills do you possess?"],
      behavioral: ["How do you handle challenges in the workplace?"],
      custom: []
    };
  }
}

// Job description optimization
interface OptimizedJobDescription {
  original: string;
  optimized: string;
  suggestions: string[];
  inclusivity_score: number;
  clarity_score: number;
}

export async function optimizeJobDescription(
  jobId?: number,
  originalDescription?: string,
  targetAudience?: string,
  inclusivityFocus?: string
): Promise<OptimizedJobDescription> {
  try {
    const response = await apiRequest("POST", "/api/ai/optimize-job-description", { 
      jobId, 
      originalDescription,
      targetAudience,
      inclusivityFocus
    });
    return response.json();
  } catch (error) {
    console.error('Error optimizing job description:', error);
    return {
      original: originalDescription || "",
      optimized: originalDescription || "",
      suggestions: ["Error optimizing job description"],
      inclusivity_score: 0,
      clarity_score: 0
    };
  }
}

interface PerformanceAnalysisResult {
  strengths: string[];
  areas_for_improvement: string[];
  trend: "improving" | "declining" | "stable";
  recommendations: string[];
  summary: string;
}

export async function analyzePerformance(employeeId: number): Promise<PerformanceAnalysisResult> {
  try {
    const response = await apiRequest("POST", "/api/ai/analyze-performance", { 
      employeeId 
    });
    return response.json();
  } catch (error) {
    console.error('Error analyzing performance:', error);
    return {
      strengths: ["Unable to analyze"],
      areas_for_improvement: ["Unable to analyze"],
      trend: "stable",
      recommendations: ["Unable to provide recommendations at this time"],
      summary: "There was an error analyzing this employee's performance data."
    };
  }
}

// Employee comparison and team optimization
interface EmployeeComparisonResult {
  employee1: {
    id: number;
    name: string;
    strengths: string[];
    weaknesses: string[];
  };
  employee2: {
    id: number;
    name: string;
    strengths: string[];
    weaknesses: string[];
  };
  comparison: {
    similarities: string[];
    differences: string[];
    complementary_skills: string[];
  };
  recommendations: {
    collaboration: string[];
    mentoring: string[];
    team_formation: string;
  };
  potential_projects: string[];
}

export async function compareEmployees(employee1Id: number, employee2Id: number): Promise<EmployeeComparisonResult> {
  try {
    const response = await apiRequest("POST", "/api/ai/compare-employees", { 
      employee1Id,
      employee2Id
    });
    return response.json();
  } catch (error) {
    console.error('Error comparing employees:', error);
    return {
      employee1: {
        id: employee1Id,
        name: "Employee",
        strengths: ["Unable to analyze"],
        weaknesses: ["Unable to analyze"]
      },
      employee2: {
        id: employee2Id,
        name: "Employee",
        strengths: ["Unable to analyze"],
        weaknesses: ["Unable to analyze"]
      },
      comparison: {
        similarities: ["Unable to determine similarities"],
        differences: ["Unable to determine differences"],
        complementary_skills: ["Unable to determine complementary skills"]
      },
      recommendations: {
        collaboration: ["Unable to provide collaboration recommendations"],
        mentoring: ["Unable to provide mentoring recommendations"],
        team_formation: "Unable to provide team formation insights"
      },
      potential_projects: ["Unable to suggest potential projects"]
    };
  }
}

// Team composition analysis
interface TeamCompositionResult {
  team_strengths: string[];
  team_gaps: string[];
  skill_distribution: Record<string, number>;
  role_distribution: Record<string, number>;
  team_recommendations: string[];
  team_development_areas: string[];
  optimal_additions: {
    role: string;
    skills: string[];
    justification: string;
  }[];
}

export async function analyzeTeamComposition(teamId: number | number[]): Promise<TeamCompositionResult> {
  try {
    const response = await apiRequest("POST", "/api/ai/analyze-team", { 
      teamId: Array.isArray(teamId) ? teamId : [teamId]
    });
    return response.json();
  } catch (error) {
    console.error('Error analyzing team composition:', error);
    return {
      team_strengths: ["Unable to analyze team strengths"],
      team_gaps: ["Unable to analyze team gaps"],
      skill_distribution: {},
      role_distribution: {},
      team_recommendations: ["Unable to provide team recommendations"],
      team_development_areas: ["Unable to identify team development areas"],
      optimal_additions: [{
        role: "Unknown",
        skills: ["Unable to determine optimal skills"],
        justification: "Analysis failed"
      }]
    };
  }
}
