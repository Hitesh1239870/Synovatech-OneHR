import { Switch, Route, useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

// Layout
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileSidebar from "@/components/layout/mobile-sidebar";
import AIAssistant from "@/components/layout/ai-assistant";

// Pages
import Dashboard from "@/pages/dashboard";
import Employees from "@/pages/employees";
import Recruitment from "@/pages/recruitment";
import Performance from "@/pages/performance";
import LeaveManagement from "@/pages/leave-management";
import Attendance from "@/pages/attendance";
import Reports from "@/pages/reports";
import Documents from "@/pages/documents";
import Settings from "@/pages/settings";

import { useState } from "react";

function Router() {
  const [location] = useLocation();
  
  // Extract the page title from the current location
  const getPageTitle = () => {
    const path = location.substring(1) || "dashboard";
    return path.split("-").map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(" ");
  };
  
  return (
    <div className="h-screen flex overflow-hidden">
      {/* Sidebar for desktop */}
      <Sidebar />
      
      {/* Mobile navbar */}
      <MobileSidebar />
      
      {/* Main content area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title={getPageTitle()} />
        
        <main className="flex-1 overflow-y-auto bg-neutral-100 pt-16 md:pt-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <Switch>
              <Route path="/" component={Dashboard} />
              <Route path="/dashboard" component={Dashboard} />
              <Route path="/employees" component={Employees} />
              <Route path="/recruitment" component={Recruitment} />
              <Route path="/performance" component={Performance} />
              <Route path="/leave-management" component={LeaveManagement} />
              <Route path="/attendance" component={Attendance} />
              <Route path="/reports" component={Reports} />
              <Route path="/documents" component={Documents} />
              <Route path="/settings" component={Settings} />
              <Route component={NotFound} />
            </Switch>
          </div>
        </main>
      </div>
      
      {/* AI Assistant */}
      <AIAssistant />
    </div>
  );
}

function App() {
  return (
    <TooltipProvider>
      <Router />
    </TooltipProvider>
  );
}

export default App;
