import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  LineChart,
  Line,
  Legend
} from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  Filter, 
  ArrowUpDown, 
  BarChart2, 
  Users, 
  Star,
  ChevronUp,
  ChevronDown,
  MoreHorizontal,
  Cpu,
  GitCompare,
  UserPlus,
  ArrowRight,
  CheckCircle2,
  XCircle,
  AlertCircle,
  UserCog
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { analyzePerformance, compareEmployees, analyzeTeamComposition } from "@/lib/openai";
import { useToast } from "@/hooks/use-toast";
import { ChartContainer } from "@/components/ui/chart-container";

interface Employee {
  id: number;
  userId: number;
  employeeId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  department: string;
  position: string;
  hireDate: string;
  manager: number | null;
  salary: number | null;
  status: string;
  profileImage: string | null;
}

interface PerformanceReview {
  id: number;
  employeeId: number;
  reviewerId: number;
  reviewDate: string;
  rating: number;
  strengths: string;
  weaknesses: string;
  comments: string;
  goals: string;
  status: string;
}

export default function Performance() {
  const [activeTab, setActiveTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState<number | null>(null);
  const [selectedDepartment, setSelectedDepartment] = useState<string>("all");
  const [aiAnalysisLoading, setAiAnalysisLoading] = useState(false);
  const [aiAnalysisResults, setAiAnalysisResults] = useState<any>(null);
  
  // For employee comparison feature
  const [compareMode, setCompareMode] = useState(false);
  const [selectedEmployeeToCompare, setSelectedEmployeeToCompare] = useState<number | null>(null);
  const [isComparing, setIsComparing] = useState(false);
  const [comparisonResults, setComparisonResults] = useState<any>(null);
  
  const { toast } = useToast();
  
  const { data: employees, isLoading: isLoadingEmployees } = useQuery<Employee[]>({
    queryKey: ['/api/employees'],
  });
  
  const { data: performanceReviews, isLoading: isLoadingReviews } = useQuery<PerformanceReview[]>({
    queryKey: ['/api/performance-reviews', { employeeId: selectedEmployee }],
    enabled: !!selectedEmployee
  });
  
  // Filter employees based on search query and selected department
  const filteredEmployees = employees?.filter(employee => {
    const matchesSearch = 
      employee.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.position.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDepartment = selectedDepartment === "all" || employee.department === selectedDepartment;
    
    return matchesSearch && matchesDepartment;
  });
  
  // Get unique departments for filter
  const departments = employees 
    ? Array.from(new Set(employees.map(e => e.department)))
    : [];
  
  // Performance data for charts (in a real app, this would come from an API)
  const departmentPerformanceData = [
    { name: 'Engineering', averageRating: 4.3 },
    { name: 'Marketing', averageRating: 4.1 },
    { name: 'Finance', averageRating: 3.9 },
    { name: 'HR', averageRating: 4.5 },
    { name: 'Sales', averageRating: 4.0 },
  ];
  
  const performanceTrendData = [
    { name: 'Q1', rating: 3.8 },
    { name: 'Q2', rating: 4.0 },
    { name: 'Q3', rating: 4.2 },
    { name: 'Q4', rating: 4.5 },
  ];
  
  const skillsRadarData = [
    { subject: 'Technical', A: 120, fullMark: 150 },
    { subject: 'Communication', A: 98, fullMark: 150 },
    { subject: 'Teamwork', A: 86, fullMark: 150 },
    { subject: 'Leadership', A: 99, fullMark: 150 },
    { subject: 'Innovation', A: 85, fullMark: 150 },
    { subject: 'Productivity', A: 65, fullMark: 150 },
  ];
  
  const handleAIAnalysis = async (employeeId: number) => {
    setAiAnalysisLoading(true);
    setAiAnalysisResults(null);
    
    try {
      const results = await analyzePerformance(employeeId);
      setAiAnalysisResults(results);
      toast({
        title: "AI Analysis Complete",
        description: "Performance analysis has been generated successfully.",
      });
    } catch (error) {
      console.error("Error during AI analysis:", error);
      toast({
        title: "Analysis Failed",
        description: "There was an error analyzing the performance data.",
        variant: "destructive"
      });
    } finally {
      setAiAnalysisLoading(false);
    }
  };
  
  const handleCompareEmployee = async () => {
    if (!selectedEmployee || !selectedEmployeeToCompare) {
      toast({
        title: "Selection Required",
        description: "Please select two employees to compare.",
        variant: "destructive"
      });
      return;
    }
    
    if (selectedEmployee === selectedEmployeeToCompare) {
      toast({
        title: "Invalid Selection",
        description: "Please select two different employees to compare.",
        variant: "destructive"
      });
      return;
    }
    
    setIsComparing(true);
    setComparisonResults(null);
    
    try {
      const results = await compareEmployees(selectedEmployee, selectedEmployeeToCompare);
      setComparisonResults(results);
      toast({
        title: "Comparison Complete",
        description: "Employee comparison has been generated successfully.",
      });
    } catch (error) {
      console.error("Error comparing employees:", error);
      toast({
        title: "Comparison Failed",
        description: "There was an error comparing the employees.",
        variant: "destructive"
      });
    } finally {
      setIsComparing(false);
    }
  };
  
  const toggleCompareMode = () => {
    setCompareMode(!compareMode);
    // Reset comparison if turning off compare mode
    if (compareMode) {
      setSelectedEmployeeToCompare(null);
      setComparisonResults(null);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Performance Management</h2>
          <p className="text-muted-foreground">
            Track, evaluate, and analyze employee performance with AI assistance.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button>
            <Star className="mr-2 h-4 w-4" />
            New Performance Review
          </Button>
          <Button variant="outline">
            <BarChart2 className="mr-2 h-4 w-4" />
            Generate Reports
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:w-auto md:inline-flex">
          <TabsTrigger value="overview">
            <BarChart2 className="mr-2 h-4 w-4" />
            Organization Overview
          </TabsTrigger>
          <TabsTrigger value="individual">
            <Users className="mr-2 h-4 w-4" />
            Individual Performance
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Average Performance Rating</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">4.2</div>
                <p className="text-xs text-muted-foreground">out of 5.0</p>
                <div className="mt-4 flex items-center text-sm">
                  <ChevronUp className="mr-1 h-4 w-4 text-green-500" />
                  <span className="text-green-500 font-medium">3.8%</span>
                  <span className="text-muted-foreground ml-1">from last quarter</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Pending Reviews</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">8</div>
                <p className="text-xs text-muted-foreground">reviews to be completed</p>
                <div className="mt-4 flex items-center text-sm">
                  <ChevronDown className="mr-1 h-4 w-4 text-amber-500" />
                  <span className="text-amber-500 font-medium">2</span>
                  <span className="text-muted-foreground ml-1">overdue</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Top Performers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">15%</div>
                <p className="text-xs text-muted-foreground">of workforce rated 4.5+</p>
                <div className="mt-4 flex items-center text-sm">
                  <ChevronUp className="mr-1 h-4 w-4 text-green-500" />
                  <span className="text-green-500 font-medium">2.5%</span>
                  <span className="text-muted-foreground ml-1">from last quarter</span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Department Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ChartContainer>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={departmentPerformanceData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis domain={[0, 5]} />
                        <Tooltip />
                        <Bar dataKey="averageRating" fill="hsl(var(--primary))" />
                      </BarChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="ai-badge">Performance Trend Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ChartContainer>
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={performanceTrendData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis domain={[0, 5]} />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="rating" stroke="hsl(var(--primary))" activeDot={{ r: 8 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </div>
                <div className="mt-4 bg-secondary-50 p-3 rounded-md border border-secondary-100">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <Cpu className="h-5 w-5 text-secondary-500" />
                    </div>
                    <div className="ml-3">
                      <h5 className="text-sm font-medium text-secondary-800">AI Insight</h5>
                      <p className="text-xs text-secondary-700 mt-1">
                        Performance is trending upward across most departments. Consider implementing the successful 
                        management approaches from HR across other teams to maintain positive momentum.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="individual" className="space-y-6 mt-6">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search employees..."
                className="w-full pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2 w-full md:w-auto">
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" className="h-9">
                <Filter className="mr-2 h-4 w-4" />
                More Filters
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-base">Employees</CardTitle>
                <Button 
                  variant={compareMode ? "default" : "outline"} 
                  size="sm" 
                  onClick={toggleCompareMode}
                  className={compareMode ? "bg-secondary text-secondary-foreground hover:bg-secondary/80" : ""}
                >
                  <GitCompare className="h-4 w-4 mr-2" />
                  {compareMode ? "Exit Compare" : "Compare"}
                </Button>
              </CardHeader>
              <CardContent className="p-0 max-h-[600px] overflow-y-auto">
                <div className="space-y-2 p-4">
                  {isLoadingEmployees ? (
                    Array(5).fill(0).map((_, index) => (
                      <div 
                        key={index} 
                        className="p-3 rounded-md border border-neutral-200 flex items-center gap-3"
                      >
                        <Skeleton className="h-10 w-10 rounded-full" />
                        <div className="flex-1 space-y-1">
                          <Skeleton className="h-4 w-36" />
                          <Skeleton className="h-3 w-24" />
                        </div>
                      </div>
                    ))
                  ) : filteredEmployees && filteredEmployees.length > 0 ? (
                    filteredEmployees.map((employee) => (
                      <div 
                        key={employee.id} 
                        className={`p-3 rounded-md border 
                          ${compareMode && selectedEmployeeToCompare === employee.id ? 'bg-secondary-50 border-secondary-200' : 
                          selectedEmployee === employee.id ? 'bg-primary-50 border-primary-200' : 
                          'border-neutral-200 hover:bg-neutral-50'} 
                          cursor-pointer`}
                        onClick={() => {
                          if (compareMode) {
                            if (selectedEmployee === employee.id) {
                              // Can't select same employee for comparison
                              return;
                            }
                            setSelectedEmployeeToCompare(employee.id);
                          } else {
                            setSelectedEmployee(employee.id);
                          }
                        }}
                      >
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              {employee.profileImage ? (
                                <AvatarImage src={employee.profileImage} alt={`${employee.firstName} ${employee.lastName}`} />
                              ) : null}
                              <AvatarFallback>
                                {employee.firstName[0] + employee.lastName[0]}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{employee.firstName} {employee.lastName}</div>
                              <div className="text-sm text-muted-foreground">{employee.position}</div>
                            </div>
                          </div>
                          {compareMode && selectedEmployeeToCompare === employee.id && (
                            <Badge variant="secondary" className="ml-auto">Compare</Badge>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-4 text-center text-muted-foreground">
                      No employees found. Try adjusting your search or filters.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {selectedEmployee ? (
              <Card className="lg:col-span-2">
                <CardHeader className="pb-2 flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>
                      {filteredEmployees?.find(e => e.id === selectedEmployee)?.firstName} {filteredEmployees?.find(e => e.id === selectedEmployee)?.lastName}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      {filteredEmployees?.find(e => e.id === selectedEmployee)?.position} - {filteredEmployees?.find(e => e.id === selectedEmployee)?.department}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    className="ai-badge"
                    disabled={aiAnalysisLoading}
                    onClick={() => handleAIAnalysis(selectedEmployee)}
                  >
                    {aiAnalysisLoading ? (
                      <span className="flex items-center">
                        <Skeleton className="h-4 w-4 mr-2 rounded-full animate-pulse" />
                        Analyzing...
                      </span>
                    ) : (
                      <span className="flex items-center">
                        <Cpu className="mr-2 h-4 w-4" />
                        AI Analysis
                      </span>
                    )}
                  </Button>
                </CardHeader>
                <CardContent className="pt-4 space-y-6">
                  {isLoadingReviews ? (
                    <div className="space-y-4">
                      <Skeleton className="h-6 w-48" />
                      <Skeleton className="h-32 w-full rounded-md" />
                      <Skeleton className="h-6 w-36" />
                      <Skeleton className="h-32 w-full rounded-md" />
                    </div>
                  ) : performanceReviews && performanceReviews.length > 0 ? (
                    <div className="space-y-6">
                      <div className="flex flex-col md:flex-row md:items-center gap-6">
                        <div className="flex-1 space-y-2">
                          <h4 className="text-sm font-medium">Average Rating</h4>
                          <div className="flex items-center gap-2">
                            <div className="text-3xl font-bold">
                              {(performanceReviews.reduce((sum, review) => sum + review.rating, 0) / performanceReviews.length).toFixed(1)}
                            </div>
                            <div className="text-sm text-muted-foreground">out of 5.0</div>
                          </div>
                        </div>
                        <div className="flex-1 space-y-2">
                          <h4 className="text-sm font-medium">Latest Review</h4>
                          <div className="text-sm">
                            {new Date(Math.max(...performanceReviews.map(r => new Date(r.reviewDate).getTime()))).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex-1 space-y-2">
                          <h4 className="text-sm font-medium">Reviews Completed</h4>
                          <div className="text-sm">
                            {performanceReviews.filter(r => r.status === "completed").length} of {performanceReviews.length}
                          </div>
                        </div>
                      </div>
                      
                      {/* Skills Radar Chart */}
                      <div className="border rounded-md p-4">
                        <h4 className="text-sm font-medium mb-2">Skills Assessment</h4>
                        <div className="h-72">
                          <ChartContainer>
                            <ResponsiveContainer width="100%" height="100%">
                              <RadarChart outerRadius={90} data={skillsRadarData}>
                                <PolarGrid />
                                <PolarAngleAxis dataKey="subject" />
                                <PolarRadiusAxis />
                                <Radar
                                  name="Skills"
                                  dataKey="A"
                                  stroke="hsl(var(--primary))"
                                  fill="hsl(var(--primary))"
                                  fillOpacity={0.6}
                                />
                              </RadarChart>
                            </ResponsiveContainer>
                          </ChartContainer>
                        </div>
                      </div>
                      
                      {/* AI Analysis Results */}
                      {aiAnalysisResults && (
                        <div className="border rounded-md p-4 bg-secondary-50 border-secondary-100">
                          <h4 className="text-sm font-medium mb-4 ai-badge">AI Performance Analysis</h4>
                          <div className="space-y-4">
                            <div>
                              <h5 className="text-sm font-medium mb-2">Key Strengths</h5>
                              <ul className="list-disc pl-5 text-sm space-y-1">
                                {aiAnalysisResults.strengths.map((strength: string, idx: number) => (
                                  <li key={idx}>{strength}</li>
                                ))}
                              </ul>
                            </div>
                            
                            <div>
                              <h5 className="text-sm font-medium mb-2">Areas for Improvement</h5>
                              <ul className="list-disc pl-5 text-sm space-y-1">
                                {aiAnalysisResults.areas_for_improvement.map((area: string, idx: number) => (
                                  <li key={idx}>{area}</li>
                                ))}
                              </ul>
                            </div>
                            
                            <div>
                              <h5 className="text-sm font-medium mb-2">Performance Trend</h5>
                              <Badge 
                                className={
                                  aiAnalysisResults.trend === "improving" ? "bg-green-100 text-green-800 border-green-200" :
                                  aiAnalysisResults.trend === "declining" ? "bg-red-100 text-red-800 border-red-200" :
                                  "bg-amber-100 text-amber-800 border-amber-200"
                                }
                              >
                                {aiAnalysisResults.trend.charAt(0).toUpperCase() + aiAnalysisResults.trend.slice(1)}
                              </Badge>
                            </div>
                            
                            <div>
                              <h5 className="text-sm font-medium mb-2">Recommendations</h5>
                              <ul className="list-disc pl-5 text-sm space-y-1">
                                {aiAnalysisResults.recommendations.map((rec: string, idx: number) => (
                                  <li key={idx}>{rec}</li>
                                ))}
                              </ul>
                            </div>
                            
                            <div className="border-t pt-4 mt-4">
                              <h5 className="text-sm font-medium mb-2">Summary</h5>
                              <p className="text-sm">{aiAnalysisResults.summary}</p>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Recent Performance Reviews */}
                      <div>
                        <h4 className="text-sm font-medium mb-4">Recent Performance Reviews</h4>
                        <div className="space-y-4">
                          {performanceReviews.sort((a, b) => new Date(b.reviewDate).getTime() - new Date(a.reviewDate).getTime())
                            .slice(0, 2)
                            .map((review) => (
                              <div key={review.id} className="border rounded-md p-4">
                                <div className="flex justify-between items-start mb-3">
                                  <div>
                                    <div className="font-medium">
                                      {new Date(review.reviewDate).toLocaleDateString()} Review
                                    </div>
                                    <div className="text-sm text-muted-foreground">
                                      By Reviewer #{review.reviewerId}
                                    </div>
                                  </div>
                                  <Badge className={
                                    review.status === "completed" ? "bg-green-100 text-green-800 border-green-200" :
                                    "bg-amber-100 text-amber-800 border-amber-200"
                                  }>
                                    {review.status.charAt(0).toUpperCase() + review.status.slice(1)}
                                  </Badge>
                                </div>
                                
                                <div className="space-y-3">
                                  <div className="flex items-center gap-2">
                                    <div className="text-sm font-medium w-20">Rating:</div>
                                    <div className="flex items-center gap-1">
                                      <Progress
                                        value={review.rating * 20}
                                        className={`h-2 w-24 ${
                                          review.rating >= 4 ? "bg-green-100" :
                                          review.rating >= 3 ? "bg-amber-100" :
                                          "bg-red-100"
                                        }`}
                                      />
                                      <span className="text-sm font-medium">{review.rating}/5</span>
                                    </div>
                                  </div>
                                  
                                  <div>
                                    <div className="text-sm font-medium">Strengths:</div>
                                    <p className="text-sm mt-1">{review.strengths}</p>
                                  </div>
                                  
                                  <div>
                                    <div className="text-sm font-medium">Areas for Improvement:</div>
                                    <p className="text-sm mt-1">{review.weaknesses}</p>
                                  </div>
                                  
                                  {review.comments && (
                                    <div>
                                      <div className="text-sm font-medium">Comments:</div>
                                      <p className="text-sm mt-1">{review.comments}</p>
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      No performance reviews found for this employee.
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card className="lg:col-span-2">
                <CardContent className="flex items-center justify-center h-full py-20">
                  <div className="text-center space-y-2">
                    <Users className="mx-auto h-12 w-12 text-muted-foreground" />
                    <h3 className="text-lg font-medium">Select an employee</h3>
                    <p className="text-sm text-muted-foreground">
                      Choose an employee from the list to view their performance details
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Employee Comparison Feature */}
            {compareMode && selectedEmployee && (
              <Card className="col-span-1 lg:col-span-3 mt-6">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="ai-badge">Employee Comparison</CardTitle>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCompareEmployee}
                      disabled={isComparing || !selectedEmployee || !selectedEmployeeToCompare}
                    >
                      {isComparing ? (
                        <span className="flex items-center">
                          <Skeleton className="h-4 w-4 mr-2 rounded-full animate-pulse" />
                          Comparing...
                        </span>
                      ) : (
                        <span className="flex items-center">
                          <GitCompare className="mr-2 h-4 w-4" />
                          Generate Comparison
                        </span>
                      )}
                    </Button>
                  </div>
                  <CardDescription>
                    Compare skills, strengths, and areas for development between employees to identify collaboration opportunities.
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="pt-0">
                  {!comparisonResults ? (
                    selectedEmployee && selectedEmployeeToCompare ? (
                      <div className="border rounded-md p-4 text-center">
                        <div className="flex items-center justify-center gap-6 mb-4">
                          <div className="text-center">
                            <Avatar className="h-16 w-16 mx-auto mb-2">
                              <AvatarFallback>
                                {filteredEmployees?.find(e => e.id === selectedEmployee)?.firstName?.[0]}
                                {filteredEmployees?.find(e => e.id === selectedEmployee)?.lastName?.[0]}
                              </AvatarFallback>
                            </Avatar>
                            <div className="font-medium">
                              {filteredEmployees?.find(e => e.id === selectedEmployee)?.firstName}{" "}
                              {filteredEmployees?.find(e => e.id === selectedEmployee)?.lastName}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {filteredEmployees?.find(e => e.id === selectedEmployee)?.position}
                            </div>
                          </div>
                          
                          <ArrowRight className="h-6 w-6 text-muted-foreground" />
                          
                          <div className="text-center">
                            <Avatar className="h-16 w-16 mx-auto mb-2">
                              <AvatarFallback>
                                {filteredEmployees?.find(e => e.id === selectedEmployeeToCompare)?.firstName?.[0]}
                                {filteredEmployees?.find(e => e.id === selectedEmployeeToCompare)?.lastName?.[0]}
                              </AvatarFallback>
                            </Avatar>
                            <div className="font-medium">
                              {filteredEmployees?.find(e => e.id === selectedEmployeeToCompare)?.firstName}{" "}
                              {filteredEmployees?.find(e => e.id === selectedEmployeeToCompare)?.lastName}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {filteredEmployees?.find(e => e.id === selectedEmployeeToCompare)?.position}
                            </div>
                          </div>
                        </div>
                        
                        <p className="text-muted-foreground">
                          Click "Generate Comparison" to analyze the potential synergies, complementary skills, and collaboration opportunities.
                        </p>
                      </div>
                    ) : (
                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Selection needed</AlertTitle>
                        <AlertDescription>
                          Please select two employees to compare their performance and skills.
                        </AlertDescription>
                      </Alert>
                    )
                  ) : (
                    <div className="border rounded-md p-5 bg-secondary-50 border-secondary-100">
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-6">
                        <div>
                          <h3 className="text-lg font-medium mb-4">
                            {comparisonResults.employee1.name}
                          </h3>
                          
                          <div className="space-y-4">
                            <div>
                              <h4 className="text-sm font-medium mb-2">Strengths</h4>
                              <ul className="list-disc pl-5 text-sm space-y-1">
                                {comparisonResults.employee1.strengths.map((s: string, i: number) => (
                                  <li key={i}>{s}</li>
                                ))}
                              </ul>
                            </div>
                            
                            <div>
                              <h4 className="text-sm font-medium mb-2">Areas for Development</h4>
                              <ul className="list-disc pl-5 text-sm space-y-1">
                                {comparisonResults.employee1.weaknesses.map((w: string, i: number) => (
                                  <li key={i}>{w}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="text-lg font-medium mb-4">
                            {comparisonResults.employee2.name}
                          </h3>
                          
                          <div className="space-y-4">
                            <div>
                              <h4 className="text-sm font-medium mb-2">Strengths</h4>
                              <ul className="list-disc pl-5 text-sm space-y-1">
                                {comparisonResults.employee2.strengths.map((s: string, i: number) => (
                                  <li key={i}>{s}</li>
                                ))}
                              </ul>
                            </div>
                            
                            <div>
                              <h4 className="text-sm font-medium mb-2">Areas for Development</h4>
                              <ul className="list-disc pl-5 text-sm space-y-1">
                                {comparisonResults.employee2.weaknesses.map((w: string, i: number) => (
                                  <li key={i}>{w}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <Separator className="my-6" />
                      
                      <div className="space-y-6">
                        <div>
                          <h3 className="text-lg font-medium mb-4">Comparison Analysis</h3>
                          
                          <Accordion type="single" collapsible className="w-full">
                            <AccordionItem value="similarities">
                              <AccordionTrigger>Similarities</AccordionTrigger>
                              <AccordionContent>
                                <ul className="list-disc pl-5 text-sm space-y-1">
                                  {comparisonResults.comparison.similarities.map((s: string, i: number) => (
                                    <li key={i}>{s}</li>
                                  ))}
                                </ul>
                              </AccordionContent>
                            </AccordionItem>
                            
                            <AccordionItem value="differences">
                              <AccordionTrigger>Differences</AccordionTrigger>
                              <AccordionContent>
                                <ul className="list-disc pl-5 text-sm space-y-1">
                                  {comparisonResults.comparison.differences.map((d: string, i: number) => (
                                    <li key={i}>{d}</li>
                                  ))}
                                </ul>
                              </AccordionContent>
                            </AccordionItem>
                            
                            <AccordionItem value="complementary">
                              <AccordionTrigger>Complementary Skills</AccordionTrigger>
                              <AccordionContent>
                                <ul className="list-disc pl-5 text-sm space-y-1">
                                  {comparisonResults.comparison.complementary_skills.map((s: string, i: number) => (
                                    <li key={i}>{s}</li>
                                  ))}
                                </ul>
                              </AccordionContent>
                            </AccordionItem>
                          </Accordion>
                        </div>
                        
                        <div>
                          <h3 className="text-lg font-medium mb-4">Recommendations</h3>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Card>
                              <CardHeader className="py-3">
                                <CardTitle className="text-sm">Collaboration Opportunities</CardTitle>
                              </CardHeader>
                              <CardContent className="py-2">
                                <ul className="list-disc pl-5 text-sm space-y-1">
                                  {comparisonResults.recommendations.collaboration.map((r: string, i: number) => (
                                    <li key={i}>{r}</li>
                                  ))}
                                </ul>
                              </CardContent>
                            </Card>
                            
                            <Card>
                              <CardHeader className="py-3">
                                <CardTitle className="text-sm">Mentoring Opportunities</CardTitle>
                              </CardHeader>
                              <CardContent className="py-2">
                                <ul className="list-disc pl-5 text-sm space-y-1">
                                  {comparisonResults.recommendations.mentoring.map((r: string, i: number) => (
                                    <li key={i}>{r}</li>
                                  ))}
                                </ul>
                              </CardContent>
                            </Card>
                          </div>
                          
                          <div className="mt-4">
                            <h4 className="text-sm font-medium mb-2">Potential Projects</h4>
                            <div className="flex flex-wrap gap-2">
                              {comparisonResults.potential_projects.map((project: string, i: number) => (
                                <Badge key={i} variant="outline" className="bg-background">
                                  {project}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          
                          <div className="mt-6 p-4 border rounded-md">
                            <div className="flex items-start">
                              <div className="flex-shrink-0">
                                <UserCog className="h-5 w-5 text-secondary-500" />
                              </div>
                              <div className="ml-3">
                                <h5 className="text-sm font-medium text-secondary-800">Team Formation Insight</h5>
                                <p className="text-sm text-secondary-700 mt-1">
                                  {comparisonResults.recommendations.team_formation}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
