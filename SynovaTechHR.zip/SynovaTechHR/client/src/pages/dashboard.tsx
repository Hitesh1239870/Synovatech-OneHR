import AIAssistantBanner from "@/components/dashboard/ai-assistant-banner";
import HRSummary from "@/components/dashboard/hr-summary";
import QuickActions from "@/components/dashboard/quick-actions";
import RecentActivity from "@/components/dashboard/recent-activity";
import EmployeeInsights from "@/components/dashboard/employee-insights";
import RecentDocuments from "@/components/dashboard/recent-documents";
import UpcomingTasks from "@/components/dashboard/upcoming-tasks";
import UpcomingEvents from "@/components/dashboard/upcoming-events";

export default function Dashboard() {
  return (
    <div>
      {/* AI Assistant Banner */}
      <AIAssistantBanner />
      
      {/* Dashboard Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* HR Summary Card */}
        <HRSummary />
        
        {/* Quick Actions Card */}
        <QuickActions />
        
        {/* Recent Activity Card */}
        <RecentActivity />
        
        {/* Employee Insights Card */}
        <EmployeeInsights />
        
        {/* Recent Documents Card */}
        <RecentDocuments />
      </div>
      
      {/* Upcoming Tasks and Calendar Section */}
      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Upcoming Tasks */}
        <UpcomingTasks />
        
        {/* Upcoming Events */}
        <UpcomingEvents />
      </div>
    </div>
  );
}
