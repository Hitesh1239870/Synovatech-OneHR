import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Clock, 
  UserCheck, 
  Search, 
  Filter, 
  ArrowUpDown, 
  MoreHorizontal,
  Calendar as CalendarIcon,
  Clock4,
  UserX,
  ClipboardCheck
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  department: string;
  employeeId: string;
}

interface Attendance {
  id: number;
  employeeId: number;
  date: string;
  timeIn: string | null;
  timeOut: string | null;
  status: string;
  employee?: {
    firstName: string;
    lastName: string;
    department: string;
  };
}

export default function Attendance() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [isMarkAttendanceOpen, setIsMarkAttendanceOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<number | null>(null);
  const [attendanceStatus, setAttendanceStatus] = useState("present");
  const [timeIn, setTimeIn] = useState("");
  const [timeOut, setTimeOut] = useState("");
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch attendance records for the selected date
  const { data: attendanceRecords, isLoading } = useQuery<Attendance[]>({
    queryKey: ['/api/attendance', { date: format(selectedDate, 'yyyy-MM-dd') }],
  });
  
  // Fetch all employees
  const { data: employees } = useQuery<Employee[]>({
    queryKey: ['/api/employees'],
  });
  
  // Mutation for creating/updating attendance record
  const attendanceMutation = useMutation({
    mutationFn: async (attendanceData: any) => {
      const response = await apiRequest("POST", "/api/attendance", attendanceData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/attendance'] });
      toast({
        title: "Success",
        description: "Attendance record saved successfully",
      });
      handleCloseDialog();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save attendance record",
        variant: "destructive",
      });
      console.error("Attendance error:", error);
    },
  });
  
  const handleMarkAttendance = () => {
    if (!selectedEmployee || !attendanceStatus) {
      toast({
        title: "Error",
        description: "Please select an employee and attendance status",
        variant: "destructive",
      });
      return;
    }
    
    // For present and late status, time in and out are required
    if ((attendanceStatus === "present" || attendanceStatus === "late") && (!timeIn || !timeOut)) {
      toast({
        title: "Error",
        description: "Please provide check-in and check-out times",
        variant: "destructive",
      });
      return;
    }
    
    attendanceMutation.mutate({
      employeeId: selectedEmployee,
      date: format(selectedDate, 'yyyy-MM-dd'),
      timeIn: attendanceStatus === "absent" ? null : timeIn,
      timeOut: attendanceStatus === "absent" ? null : timeOut,
      status: attendanceStatus
    });
  };
  
  const handleCloseDialog = () => {
    setIsMarkAttendanceOpen(false);
    setSelectedEmployee(null);
    setAttendanceStatus("present");
    setTimeIn("");
    setTimeOut("");
  };
  
  // Filter attendance records based on search query
  const filteredAttendance = attendanceRecords?.filter((record) => {
    const employeeName = `${record.employee?.firstName} ${record.employee?.lastName}`.toLowerCase();
    const departmentName = record.employee?.department.toLowerCase() || "";
    
    return (
      employeeName.includes(searchQuery.toLowerCase()) || 
      departmentName.includes(searchQuery.toLowerCase())
    );
  });
  
  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "present":
        return (
          <Badge className="bg-green-100 text-green-800 border-green-200">
            Present
          </Badge>
        );
      case "absent":
        return (
          <Badge className="bg-red-100 text-red-800 border-red-200">
            Absent
          </Badge>
        );
      case "late":
        return (
          <Badge className="bg-amber-100 text-amber-800 border-amber-200">
            Late
          </Badge>
        );
      case "half-day":
        return (
          <Badge className="bg-blue-100 text-blue-800 border-blue-200">
            Half Day
          </Badge>
        );
      default:
        return (
          <Badge className="bg-neutral-100 text-neutral-800 border-neutral-200">
            {status}
          </Badge>
        );
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Attendance Tracking</h2>
          <p className="text-muted-foreground">
            Track and manage employee attendance records.
          </p>
        </div>
        <Dialog open={isMarkAttendanceOpen} onOpenChange={setIsMarkAttendanceOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserCheck className="mr-2 h-4 w-4" />
              Mark Attendance
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Record Attendance</DialogTitle>
              <DialogDescription>
                Enter attendance details for the selected employee.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="employee">Employee</Label>
                <Select value={selectedEmployee?.toString()} onValueChange={(value) => setSelectedEmployee(parseInt(value))}>
                  <SelectTrigger id="employee">
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees?.map((employee) => (
                      <SelectItem key={employee.id} value={employee.id.toString()}>
                        {employee.firstName} {employee.lastName} ({employee.employeeId})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <div className="flex items-center border rounded-md pl-3 pr-1">
                  <CalendarIcon className="h-4 w-4 text-muted-foreground mr-2" />
                  <span>{format(selectedDate, 'PPP')}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="status">Attendance Status</Label>
                <Select value={attendanceStatus} onValueChange={setAttendanceStatus}>
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="present">Present</SelectItem>
                    <SelectItem value="absent">Absent</SelectItem>
                    <SelectItem value="late">Late</SelectItem>
                    <SelectItem value="half-day">Half Day</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {attendanceStatus !== "absent" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="time-in">Check-in Time</Label>
                    <Input
                      id="time-in"
                      type="time"
                      value={timeIn}
                      onChange={(e) => setTimeIn(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="time-out">Check-out Time</Label>
                    <Input
                      id="time-out"
                      type="time"
                      value={timeOut}
                      onChange={(e) => setTimeOut(e.target.value)}
                    />
                  </div>
                </>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleCloseDialog}>Cancel</Button>
              <Button 
                onClick={handleMarkAttendance}
                disabled={!selectedEmployee || !attendanceStatus || attendanceMutation.isPending}
              >
                {attendanceMutation.isPending ? "Saving..." : "Save Attendance"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-72">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Select Date</CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => date && setSelectedDate(date)}
                className="mx-auto"
              />
            </CardContent>
          </Card>
          
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-base">Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                  <span className="text-sm">Present</span>
                </div>
                <span className="font-medium">
                  {attendanceRecords?.filter(a => a.status === "present").length || 0}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                  <span className="text-sm">Absent</span>
                </div>
                <span className="font-medium">
                  {attendanceRecords?.filter(a => a.status === "absent").length || 0}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-amber-500 mr-2"></div>
                  <span className="text-sm">Late</span>
                </div>
                <span className="font-medium">
                  {attendanceRecords?.filter(a => a.status === "late").length || 0}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                  <span className="text-sm">Half Day</span>
                </div>
                <span className="font-medium">
                  {attendanceRecords?.filter(a => a.status === "half-day").length || 0}
                </span>
              </div>
              
              <div className="pt-2 mt-2 border-t">
                <div className="flex justify-between items-center font-medium">
                  <span>Total Employees</span>
                  <span>{employees?.length || 0}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="flex-1">
          <Card>
            <CardHeader className="p-4 flex flex-row items-center justify-between border-b">
              <CardTitle>Attendance - {format(selectedDate, 'PPPP')}</CardTitle>
              <div className="flex items-center gap-2">
                <div className="relative w-64">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search employee..."
                    className="w-full pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[250px]">
                      <Button variant="ghost" size="sm" className="font-medium flex gap-1">
                        Employee <ArrowUpDown className="h-4 w-4" />
                      </Button>
                    </TableHead>
                    <TableHead>
                      <Button variant="ghost" size="sm" className="font-medium flex gap-1">
                        Department <ArrowUpDown className="h-4 w-4" />
                      </Button>
                    </TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>
                      <Button variant="ghost" size="sm" className="font-medium flex gap-1">
                        Check In <ArrowUpDown className="h-4 w-4" />
                      </Button>
                    </TableHead>
                    <TableHead>Check Out</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    Array(5).fill(0).map((_, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          <div className="space-y-1">
                            <Skeleton className="h-5 w-32" />
                            <Skeleton className="h-4 w-24" />
                          </div>
                        </TableCell>
                        <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                        <TableCell><Skeleton className="h-6 w-16 rounded-full" /></TableCell>
                        <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                        <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                        <TableCell><Skeleton className="h-8 w-16 rounded ml-auto" /></TableCell>
                      </TableRow>
                    ))
                  ) : filteredAttendance && filteredAttendance.length > 0 ? (
                    filteredAttendance.map((record) => (
                      <TableRow key={record.id}>
                        <TableCell>
                          <div className="font-medium">
                            {record.employee?.firstName} {record.employee?.lastName}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            ID: #{record.employeeId}
                          </div>
                        </TableCell>
                        <TableCell>{record.employee?.department}</TableCell>
                        <TableCell>{getStatusBadge(record.status)}</TableCell>
                        <TableCell>
                          {record.timeIn || (
                            <span className="text-neutral-400">--:--</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {record.timeOut || (
                            <span className="text-neutral-400">--:--</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Open menu</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <ClipboardCheck className="mr-2 h-4 w-4" />
                                Edit Attendance
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Clock4 className="mr-2 h-4 w-4" />
                                Log Time
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <UserX className="mr-2 h-4 w-4" />
                                Mark as Absent
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-10 text-muted-foreground">
                        No attendance records found for this date.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
