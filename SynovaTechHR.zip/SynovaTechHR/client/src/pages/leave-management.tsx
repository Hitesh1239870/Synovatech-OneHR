import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  CalendarPlus, 
  CalendarClock, 
  Search, 
  Filter, 
  ArrowUpDown, 
  MoreHorizontal,
  CheckCircle2,
  XCircle
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, addDays } from "date-fns";

interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  department: string;
}

interface LeaveRequest {
  id: number;
  employeeId: number;
  leaveType: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: string;
  approvedBy: number | null;
  createdAt: string;
  employee?: {
    firstName: string;
    lastName: string;
    department: string;
  };
}

export default function LeaveManagement() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedDates, setSelectedDates] = useState<{
    from: Date;
    to: Date | undefined;
  }>({
    from: new Date(),
    to: addDays(new Date(), 1),
  });
  const [leaveType, setLeaveType] = useState("annual");
  const [reason, setReason] = useState("");
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch all leave requests
  const { data: leaveRequests, isLoading } = useQuery<LeaveRequest[]>({
    queryKey: ['/api/leave-requests'],
  });
  
  // Fetch employees for the dropdown
  const { data: employees } = useQuery<Employee[]>({
    queryKey: ['/api/employees'],
  });
  
  // Mutation for submitting a new leave request
  const submitLeaveMutation = useMutation({
    mutationFn: async (newLeave: any) => {
      const response = await apiRequest("POST", "/api/leave-requests", newLeave);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/leave-requests'] });
      toast({
        title: "Success",
        description: "Leave request submitted successfully",
      });
      handleCloseDialog();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit leave request",
        variant: "destructive",
      });
      console.error("Leave request error:", error);
    },
  });
  
  // Mutation for updating a leave request status
  const updateLeaveStatusMutation = useMutation({
    mutationFn: async ({ id, status, approvedBy }: { id: number; status: string; approvedBy: number }) => {
      const response = await apiRequest("PATCH", `/api/leave-requests/${id}`, { status, approvedBy });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/leave-requests'] });
      toast({
        title: "Success",
        description: "Leave request status updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update leave request status",
        variant: "destructive",
      });
      console.error("Update status error:", error);
    },
  });
  
  const handleSubmitLeave = () => {
    if (!selectedDates.from || !selectedDates.to || !leaveType || !reason) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    submitLeaveMutation.mutate({
      employeeId: 1, // This would come from the user context in a real app
      leaveType,
      startDate: format(selectedDates.from, 'yyyy-MM-dd'),
      endDate: format(selectedDates.to, 'yyyy-MM-dd'),
      reason,
      status: "pending"
    });
  };
  
  const handleApproveLeave = (id: number) => {
    updateLeaveStatusMutation.mutate({
      id,
      status: "approved",
      approvedBy: 1 // This would come from the user context in a real app
    });
  };
  
  const handleRejectLeave = (id: number) => {
    updateLeaveStatusMutation.mutate({
      id,
      status: "rejected",
      approvedBy: 1 // This would come from the user context in a real app
    });
  };
  
  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setSelectedDates({ from: new Date(), to: addDays(new Date(), 1) });
    setLeaveType("annual");
    setReason("");
  };
  
  // Filter leave requests based on search query and active tab
  const filteredLeaveRequests = leaveRequests?.filter((request) => {
    const employeeName = `${request.employee?.firstName} ${request.employee?.lastName}`.toLowerCase();
    const searchMatches = 
      employeeName.includes(searchQuery.toLowerCase()) || 
      request.leaveType.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.employee?.department.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === "all") return searchMatches;
    return searchMatches && request.status === activeTab;
  });
  
  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return (
          <Badge className="bg-green-100 text-green-800 border-green-200">
            Approved
          </Badge>
        );
      case "rejected":
        return (
          <Badge className="bg-red-100 text-red-800 border-red-200">
            Rejected
          </Badge>
        );
      case "pending":
        return (
          <Badge className="bg-amber-100 text-amber-800 border-amber-200">
            Pending
          </Badge>
        );
      default:
        return (
          <Badge className="bg-neutral-100 text-neutral-800 border-neutral-200">
            {status}
          </Badge>
        );
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Leave Management</h2>
          <p className="text-muted-foreground">
            Manage and track employee leave requests and approvals.
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <CalendarPlus className="mr-2 h-4 w-4" />
              Request Leave
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>New Leave Request</DialogTitle>
              <DialogDescription>
                Fill in the details below to submit your leave request.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="leave-type">Leave Type</Label>
                <Select value={leaveType} onValueChange={setLeaveType}>
                  <SelectTrigger id="leave-type">
                    <SelectValue placeholder="Select type of leave" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="annual">Annual Leave</SelectItem>
                    <SelectItem value="sick">Sick Leave</SelectItem>
                    <SelectItem value="personal">Personal Leave</SelectItem>
                    <SelectItem value="maternity">Maternity Leave</SelectItem>
                    <SelectItem value="paternity">Paternity Leave</SelectItem>
                    <SelectItem value="unpaid">Unpaid Leave</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Date Range</Label>
                <div className="border rounded-md p-2">
                  <Calendar
                    mode="range"
                    selected={selectedDates}
                    onSelect={(range) => {
                      if (range?.from && range?.to) {
                        setSelectedDates(range);
                      }
                    }}
                    disabled={{ before: new Date() }}
                    className="mx-auto"
                    numberOfMonths={1}
                  />
                </div>
                {selectedDates.from && selectedDates.to && (
                  <div className="text-sm text-muted-foreground mt-2">
                    {format(selectedDates.from, 'PPP')} - {format(selectedDates.to, 'PPP')}
                  </div>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="reason">Reason for Leave</Label>
                <Textarea
                  id="reason"
                  placeholder="Please provide a brief reason for your leave request"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleCloseDialog}>Cancel</Button>
              <Button 
                onClick={handleSubmitLeave}
                disabled={!selectedDates.from || !selectedDates.to || !leaveType || !reason || submitLeaveMutation.isPending}
              >
                {submitLeaveMutation.isPending ? "Submitting..." : "Submit Request"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search leave requests..."
            className="w-full pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <Button variant="outline" className="h-9">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button variant="outline" className="h-9">
            <CalendarClock className="mr-2 h-4 w-4" />
            Calendar View
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader className="p-4 border-b">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-4 w-full md:w-auto">
              <TabsTrigger value="all">All Requests</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="approved">Approved</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[200px]">
                  <Button variant="ghost" size="sm" className="font-medium flex gap-1">
                    Employee <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead>
                  <Button variant="ghost" size="sm" className="font-medium flex gap-1">
                    Leave Type <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead>
                  <Button variant="ghost" size="sm" className="font-medium flex gap-1">
                    Start Date <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead>End Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array(5).fill(0).map((_, index) => (
                  <TableRow key={index}>
                    <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-16 rounded-full" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-16 rounded ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : filteredLeaveRequests && filteredLeaveRequests.length > 0 ? (
                filteredLeaveRequests.map((request) => (
                  <TableRow key={request.id}>
                    <TableCell>
                      <div className="font-medium">
                        {request.employee?.firstName} {request.employee?.lastName}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {request.employee?.department}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {request.leaveType}
                      </Badge>
                    </TableCell>
                    <TableCell>{new Date(request.startDate).toLocaleDateString()}</TableCell>
                    <TableCell>{new Date(request.endDate).toLocaleDateString()}</TableCell>
                    <TableCell>{getStatusBadge(request.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end">
                        {request.status === "pending" ? (
                          <div className="flex items-center gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="h-8 text-green-600 hover:text-green-700 hover:bg-green-50"
                              onClick={() => handleApproveLeave(request.id)}
                              disabled={updateLeaveStatusMutation.isPending}
                            >
                              <CheckCircle2 className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                              onClick={() => handleRejectLeave(request.id)}
                              disabled={updateLeaveStatusMutation.isPending}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        ) : (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Open menu</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>View Details</DropdownMenuItem>
                              <DropdownMenuItem>Send Email</DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>Change Status</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-10 text-muted-foreground">
                    No leave requests found. Try adjusting your search or filters.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
