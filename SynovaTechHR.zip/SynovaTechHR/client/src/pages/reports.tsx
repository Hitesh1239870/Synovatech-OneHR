import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  PieChart, 
  Pie, 
  Cell, 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer 
} from "recharts";
import { 
  FileText, 
  BarChart as BarChartIcon, 
  Download, 
  Printer,
  Filter,
  FileDown,
  Calendar,
  Users,
  Briefcase,
  Clock,
  PercentIcon,
  TrendingUp,
  Cpu
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ChartContainer } from "@/components/ui/chart-container";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

interface DepartmentDistribution {
  department: string;
  count: number;
  percentage: number;
}

interface ActivityLog {
  id: number;
  userId: number;
  action: string;
  details: string;
  timestamp: string;
}

export default function Reports() {
  const [reportType, setReportType] = useState("overview");
  const [timeframe, setTimeframe] = useState("month");
  
  // Fetch department distribution data
  const { data: departmentData, isLoading: isLoadingDepartments } = useQuery<DepartmentDistribution[]>({
    queryKey: ['/api/analytics/department-distribution'],
  });
  
  // Fetch attendance rate
  const { data: attendanceRate, isLoading: isLoadingAttendance } = useQuery<{ rate: number, period: any }>({
    queryKey: ['/api/analytics/attendance-rate'],
  });
  
  // Fetch recent activity logs
  const { data: activityLogs, isLoading: isLoadingLogs } = useQuery<ActivityLog[]>({
    queryKey: ['/api/activity-logs', { limit: 10 }],
  });
  
  // Set up color scheme for the pie chart
  const COLORS = ['#0EA5E9', '#8B5CF6', '#F59E0B', '#10B981', '#EF4444'];
  
  // Recruitment data for charts (in a real app, this would come from an API)
  const recruitmentData = [
    { month: 'Jan', applications: 45, interviews: 20, hires: 5 },
    { month: 'Feb', applications: 52, interviews: 25, hires: 8 },
    { month: 'Mar', applications: 38, interviews: 18, hires: 6 },
    { month: 'Apr', applications: 65, interviews: 30, hires: 10 },
    { month: 'May', applications: 48, interviews: 22, hires: 7 },
    { month: 'Jun', applications: 70, interviews: 35, hires: 12 },
  ];
  
  // Attrition rate data
  const attritionData = [
    { month: 'Jan', rate: 2.1 },
    { month: 'Feb', rate: 1.9 },
    { month: 'Mar', rate: 2.3 },
    { month: 'Apr', rate: 1.8 },
    { month: 'May', rate: 1.5 },
    { month: 'Jun', rate: 1.7 },
  ];
  
  // Performance trend data
  const performanceTrendData = [
    { department: 'Engineering', q1: 3.8, q2: 4.0, q3: 4.2, q4: 4.3 },
    { department: 'Marketing', q1: 3.9, q2: 3.7, q3: 4.1, q4: 4.0 },
    { department: 'Finance', q1: 4.1, q2: 4.2, q3: 4.0, q4: 4.3 },
    { department: 'HR', q1: 4.3, q2: 4.4, q3: 4.5, q4: 4.6 },
    { department: 'Sales', q1: 3.7, q2: 3.9, q3: 4.0, q4: 4.2 },
  ];
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Reports & Analytics</h2>
          <p className="text-muted-foreground">
            Gain insights into your HR data with AI-powered analytics.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button variant="outline">
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <Tabs value={reportType} onValueChange={setReportType} className="w-full md:w-auto">
          <TabsList className="grid grid-cols-4 w-full">
            <TabsTrigger value="overview">
              <BarChartIcon className="mr-2 h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="workforce">
              <Users className="mr-2 h-4 w-4" />
              Workforce
            </TabsTrigger>
            <TabsTrigger value="recruitment">
              <Briefcase className="mr-2 h-4 w-4" />
              Recruitment
            </TabsTrigger>
            <TabsTrigger value="performance">
              <TrendingUp className="mr-2 h-4 w-4" />
              Performance
            </TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <Select value={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="h-10">
            <Filter className="mr-2 h-4 w-4" />
            More Filters
          </Button>
        </div>
      </div>
      
      <TabsContent value="overview" className="mt-0 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Employees</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">156</div>
              <p className="text-xs text-muted-foreground">Total employees</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  +12 this year
                </Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Attendance</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isLoadingAttendance ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold">{attendanceRate?.rate}%</div>
              )}
              <p className="text-xs text-muted-foreground">Average attendance</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  +0.8% from last month
                </Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Attrition</CardTitle>
              <PercentIcon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1.7%</div>
              <p className="text-xs text-muted-foreground">Monthly rate</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  -0.2% from last month
                </Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Open Positions</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">Active job openings</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-amber-100 text-amber-800 border-amber-200">
                  4 urgent to fill
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Department Distribution</CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              {isLoadingDepartments ? (
                <div className="flex items-center justify-center h-full">
                  <Skeleton className="h-64 w-64 rounded-full" />
                </div>
              ) : (
                <ChartContainer>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={departmentData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="count"
                        nameKey="department"
                        label={({ department, percentage }) => `${department}: ${percentage}%`}
                      >
                        {departmentData?.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value, name) => [`${value} employees`, name]} />
                    </PieChart>
                  </ResponsiveContainer>
                </ChartContainer>
              )}
            </CardContent>
          </Card>
          
          <Card className="col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="ai-badge">AI Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border rounded-md p-4 bg-secondary-50 border-secondary-100">
                <div className="flex items-start">
                  <Cpu className="h-5 w-5 text-secondary-500 mt-0.5 flex-shrink-0" />
                  <div className="ml-3">
                    <h5 className="text-sm font-medium text-secondary-800">Attrition Risk Alert</h5>
                    <p className="text-sm text-secondary-700 mt-1">
                      Engineering department shows 15% higher turnover risk compared to company average. Consider conducting stay interviews with team leads.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-md p-4 bg-secondary-50 border-secondary-100">
                <div className="flex items-start">
                  <Cpu className="h-5 w-5 text-secondary-500 mt-0.5 flex-shrink-0" />
                  <div className="ml-3">
                    <h5 className="text-sm font-medium text-secondary-800">Leave Pattern Detection</h5>
                    <p className="text-sm text-secondary-700 mt-1">
                      Detected higher than average leave requests for next month. Consider reviewing team workload and project deadlines.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-md p-4 bg-secondary-50 border-secondary-100">
                <div className="flex items-start">
                  <Cpu className="h-5 w-5 text-secondary-500 mt-0.5 flex-shrink-0" />
                  <div className="ml-3">
                    <h5 className="text-sm font-medium text-secondary-800">Hiring Optimization</h5>
                    <p className="text-sm text-secondary-700 mt-1">
                      Based on recent hiring data, technical interviews conducted in the morning show 22% higher success rates than those in the afternoon.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {isLoadingLogs ? (
                Array(5).fill(0).map((_, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-1">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-4 w-48" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </div>
                ))
              ) : activityLogs && activityLogs.length > 0 ? (
                activityLogs.map((log) => (
                  <div key={log.id} className="border-b pb-4 last:border-0 last:pb-0">
                    <div className="flex items-start">
                      <div className="font-medium">{log.action}</div>
                      <div className="ml-auto text-sm text-muted-foreground">
                        {new Date(log.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </div>
                    </div>
                    <p className="text-sm mt-1">{log.details}</p>
                    <div className="text-xs text-muted-foreground mt-1">
                      By User #{log.userId}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No recent activity to display.
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </TabsContent>
      
      <TabsContent value="workforce" className="mt-0 space-y-6">
        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Employee Demographics</CardTitle>
            </CardHeader>
            <CardContent className="h-96">
              <ChartContainer>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { age: '18-25', count: 15 },
                      { age: '26-35', count: 58 },
                      { age: '36-45', count: 42 },
                      { age: '46-55', count: 30 },
                      { age: '56+', count: 11 },
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="age" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar name="Number of Employees" dataKey="count" fill="hsl(var(--primary))" />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="ai-badge">Attrition Rate Trend</CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              <ChartContainer>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={attritionData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis domain={[0, 3]} />
                    <Tooltip formatter={(value) => [`${value}%`, 'Attrition Rate']} />
                    <Legend />
                    <Line type="monotone" dataKey="rate" stroke="#8B5CF6" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Departments by Growth</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="p-6 space-y-6">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Engineering</div>
                      <div className="text-green-600">+18%</div>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '80%' }}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Sales</div>
                      <div className="text-green-600">+15%</div>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '70%' }}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Marketing</div>
                      <div className="text-green-600">+12%</div>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Product</div>
                      <div className="text-green-600">+8%</div>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '40%' }}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">Finance</div>
                      <div className="text-green-600">+5%</div>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '30%' }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Tenure Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: '< 1 year', value: 28 },
                          { name: '1-3 years', value: 45 },
                          { name: '3-5 years', value: 32 },
                          { name: '5-10 years', value: 35 },
                          { name: '10+ years', value: 16 },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {COLORS.map((color, index) => (
                          <Cell key={`cell-${index}`} fill={color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} employees`]} />
                    </PieChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        </div>
      </TabsContent>
      
      <TabsContent value="recruitment" className="mt-0 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Applications</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">318</div>
              <p className="text-xs text-muted-foreground">Total this quarter</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  +22% from last quarter
                </Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Interviews</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">150</div>
              <p className="text-xs text-muted-foreground">Total this quarter</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  +15% from last quarter
                </Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Hires</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">48</div>
              <p className="text-xs text-muted-foreground">Total this quarter</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  +8% from last quarter
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Recruitment Funnel</CardTitle>
          </CardHeader>
          <CardContent className="h-96">
            <ChartContainer>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={recruitmentData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar name="Applications" dataKey="applications" fill="#0EA5E9" />
                  <Bar name="Interviews" dataKey="interviews" fill="#8B5CF6" />
                  <Bar name="Hires" dataKey="hires" fill="#10B981" />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Top Hiring Sources</CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Employee Referrals', value: 35 },
                        { name: 'LinkedIn', value: 25 },
                        { name: 'Company Website', value: 18 },
                        { name: 'Job Boards', value: 15 },
                        { name: 'Recruitment Agencies', value: 7 },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {COLORS.map((color, index) => (
                        <Cell key={`cell-${index}`} fill={color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value, name) => [`${value}%`, name]} />
                  </PieChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="ai-badge">AI Screening Performance</CardTitle>
            </CardHeader>
            <CardContent className="h-64">
              <div className="h-full flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="text-sm">Screening Accuracy</div>
                      <div className="font-medium">92%</div>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2">
                      <div className="bg-primary-600 h-2 rounded-full" style={{ width: '92%' }}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="text-sm">Interview Pass Rate - AI Selected</div>
                      <div className="font-medium">78%</div>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2">
                      <div className="bg-primary-600 h-2 rounded-full" style={{ width: '78%' }}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="text-sm">Interview Pass Rate - Traditional</div>
                      <div className="font-medium">52%</div>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2">
                      <div className="bg-neutral-500 h-2 rounded-full" style={{ width: '52%' }}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="text-sm">Time Saved per Candidate</div>
                      <div className="font-medium">3.5 hours</div>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-2">
                      <div className="bg-secondary-600 h-2 rounded-full" style={{ width: '85%' }}></div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-secondary-50 p-3 rounded-md border border-secondary-100 mt-4">
                  <div className="flex items-start">
                    <Cpu className="h-5 w-5 text-secondary-500 mt-0.5 flex-shrink-0" />
                    <div className="ml-3">
                      <p className="text-xs text-secondary-700">
                        AI screening has reduced time-to-hire by 40% and improved quality of candidates by correctly identifying 92% of successful hires.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>
      
      <TabsContent value="performance" className="mt-0 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
              <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">4.2</div>
              <p className="text-xs text-muted-foreground">Out of 5.0</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  +0.3 from last year
                </Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Completed Reviews</CardTitle>
              <ClipboardCheck className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">148</div>
              <p className="text-xs text-muted-foreground">Out of 156 employees</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  95% completion rate
                </Badge>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Top Performers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">23</div>
              <p className="text-xs text-muted-foreground">Rated 4.5+</p>
              <div className="mt-4 flex items-center text-xs">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  15% of workforce
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Performance Trends by Department</CardTitle>
          </CardHeader>
          <CardContent className="h-96">
            <ChartContainer>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={performanceTrendData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="department" />
                  <YAxis domain={[3, 5]} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" name="Q1" dataKey="q1" stroke="#0EA5E9" />
                  <Line type="monotone" name="Q2" dataKey="q2" stroke="#8B5CF6" />
                  <Line type="monotone" name="Q3" dataKey="q3" stroke="#F59E0B" />
                  <Line type="monotone" name="Q4" dataKey="q4" stroke="#10B981" />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance Distribution</CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              <ChartContainer>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { rating: '1.0-1.9', count: 2 },
                      { rating: '2.0-2.9', count: 8 },
                      { rating: '3.0-3.9', count: 45 },
                      { rating: '4.0-4.4', count: 78 },
                      { rating: '4.5-5.0', count: 23 },
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="rating" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar name="Number of Employees" dataKey="count" fill="hsl(var(--primary))" />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="ai-badge">AI Performance Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border rounded-md p-4 bg-secondary-50 border-secondary-100">
                <div className="flex items-start">
                  <Cpu className="h-5 w-5 text-secondary-500 mt-0.5 flex-shrink-0" />
                  <div className="ml-3">
                    <h5 className="text-sm font-medium text-secondary-800">Skills Gap Analysis</h5>
                    <p className="text-sm text-secondary-700 mt-1">
                      Based on performance reviews, the most common skill gaps are in project management (23%), technical documentation (18%), and cross-team collaboration (15%).
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-md p-4 bg-secondary-50 border-secondary-100">
                <div className="flex items-start">
                  <Cpu className="h-5 w-5 text-secondary-500 mt-0.5 flex-shrink-0" />
                  <div className="ml-3">
                    <h5 className="text-sm font-medium text-secondary-800">Training Recommendation</h5>
                    <p className="text-sm text-secondary-700 mt-1">
                      Implementing team-based project management training could address 72% of the identified skill gaps across departments.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-md p-4 bg-secondary-50 border-secondary-100">
                <div className="flex items-start">
                  <Cpu className="h-5 w-5 text-secondary-500 mt-0.5 flex-shrink-0" />
                  <div className="ml-3">
                    <h5 className="text-sm font-medium text-secondary-800">Performance Correlation</h5>
                    <p className="text-sm text-secondary-700 mt-1">
                      Employees who participated in last quarter's leadership workshop showed an average performance increase of 12%, suggesting high ROI for this training program.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-md p-4 bg-secondary-50 border-secondary-100">
                <div className="flex items-start">
                  <Cpu className="h-5 w-5 text-secondary-500 mt-0.5 flex-shrink-0" />
                  <div className="ml-3">
                    <h5 className="text-sm font-medium text-secondary-800">Growth Potential</h5>
                    <p className="text-sm text-secondary-700 mt-1">
                      15 employees currently in mid-level positions show high leadership potential based on consistent performance ratings and peer feedback.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>
      
      <div className="flex justify-between items-center border-t pt-6">
        <div className="text-sm text-muted-foreground">
          Last updated: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <FileDown className="mr-2 h-4 w-4" />
            Download Report
          </Button>
          <Button variant="outline" size="sm">
            <Calendar className="mr-2 h-4 w-4" />
            Schedule
          </Button>
        </div>
      </div>
    </div>
  );
}
