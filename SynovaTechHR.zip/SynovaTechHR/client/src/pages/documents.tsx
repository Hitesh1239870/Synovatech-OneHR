import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  FilePlus,
  Search, 
  Filter, 
  MoreHorizontal,
  FileText,
  FileSpreadsheet,
  File,
  FolderOpen,
  Download,
  Trash2,
  Share2,
  Edit,
  Eye
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface Document {
  id: number;
  title: string;
  type: string;
  content: string;
  ownerId: number;
  createdAt: string;
  updatedAt: string;
  owner?: {
    fullName: string;
    email: string;
  };
}

export default function Documents() {
  const [searchQuery, setSearchQuery] = useState("");
  const [documentType, setDocumentType] = useState("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState("");
  const [newDocType, setNewDocType] = useState("policy");
  const [newDocContent, setNewDocContent] = useState("");
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch documents
  const { data: documents, isLoading } = useQuery<Document[]>({
    queryKey: ['/api/documents'],
  });
  
  // Mutation for creating a new document
  const createDocumentMutation = useMutation({
    mutationFn: async (documentData: any) => {
      const response = await apiRequest("POST", "/api/documents", documentData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      toast({
        title: "Success",
        description: "Document created successfully",
      });
      handleCloseDialog();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create document",
        variant: "destructive",
      });
      console.error("Document creation error:", error);
    },
  });
  
  const handleCreateDocument = () => {
    if (!newDocTitle || !newDocType || !newDocContent) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    createDocumentMutation.mutate({
      title: newDocTitle,
      type: newDocType,
      content: newDocContent,
      ownerId: 1 // This would come from the user context in a real app
    });
  };
  
  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setNewDocTitle("");
    setNewDocType("policy");
    setNewDocContent("");
  };
  
  // Filter documents based on search query and document type
  const filteredDocuments = documents?.filter((doc) => {
    const searchMatches = 
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      (doc.owner?.fullName?.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (documentType === "all") return searchMatches;
    return searchMatches && doc.type === documentType;
  });
  
  // Get document icon
  const getDocumentIcon = (type: string) => {
    switch (type) {
      case "policy":
        return <FileText className="h-6 w-6 text-neutral-500" />;
      case "spreadsheet":
        return <FileSpreadsheet className="h-6 w-6 text-neutral-500" />;
      case "form":
        return <File className="h-6 w-6 text-neutral-500" />;
      case "contract":
        return <FileText className="h-6 w-6 text-neutral-500" />;
      default:
        return <File className="h-6 w-6 text-neutral-500" />;
    }
  };
  
  // Format file size
  const formatSize = (size: number) => {
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Documents</h2>
          <p className="text-muted-foreground">
            Manage and organize HR documents, policies, and forms.
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <FilePlus className="mr-2 h-4 w-4" />
              Create Document
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Create New Document</DialogTitle>
              <DialogDescription>
                Fill in the details below to create a new HR document.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-4 gap-4">
                <div className="col-span-3">
                  <Label htmlFor="title">Document Title</Label>
                  <Input
                    id="title"
                    placeholder="Enter document title"
                    value={newDocTitle}
                    onChange={(e) => setNewDocTitle(e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div className="col-span-1">
                  <Label htmlFor="type">Type</Label>
                  <Select value={newDocType} onValueChange={setNewDocType}>
                    <SelectTrigger id="type" className="mt-1">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="policy">Policy</SelectItem>
                      <SelectItem value="form">Form</SelectItem>
                      <SelectItem value="contract">Contract</SelectItem>
                      <SelectItem value="spreadsheet">Spreadsheet</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="content">Document Content</Label>
                <Textarea
                  id="content"
                  placeholder="Enter document content..."
                  value={newDocContent}
                  onChange={(e) => setNewDocContent(e.target.value)}
                  className="min-h-[200px]"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleCloseDialog}>Cancel</Button>
              <Button 
                onClick={handleCreateDocument}
                disabled={!newDocTitle || !newDocType || !newDocContent || createDocumentMutation.isPending}
              >
                {createDocumentMutation.isPending ? "Creating..." : "Create Document"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search documents..."
            className="w-full pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <Select value={documentType} onValueChange={setDocumentType}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="policy">Policies</SelectItem>
              <SelectItem value="form">Forms</SelectItem>
              <SelectItem value="contract">Contracts</SelectItem>
              <SelectItem value="spreadsheet">Spreadsheets</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="h-10">
            <Filter className="mr-2 h-4 w-4" />
            More Filters
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-5 md:w-auto md:inline-flex">
          <TabsTrigger value="all">All Documents</TabsTrigger>
          <TabsTrigger value="recent">Recent</TabsTrigger>
          <TabsTrigger value="shared">Shared with Me</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="archived">Archived</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle>Document Library</CardTitle>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm">
                      <FolderOpen className="mr-2 h-4 w-4" />
                      New Folder
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Bulk Download
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[400px]">Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Last Modified</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      Array(5).fill(0).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <Skeleton className="h-10 w-10 rounded-md" />
                              <Skeleton className="h-5 w-48" />
                            </div>
                          </TableCell>
                          <TableCell><Skeleton className="h-5 w-20" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-8 w-8 rounded-full ml-auto" /></TableCell>
                        </TableRow>
                      ))
                    ) : filteredDocuments && filteredDocuments.length > 0 ? (
                      filteredDocuments.map((doc) => (
                        <TableRow key={doc.id}>
                          <TableCell>
                            <div className="flex items-center space-x-3">
                              <div className="flex-shrink-0 h-10 w-10 bg-neutral-100 rounded-md flex items-center justify-center">
                                {getDocumentIcon(doc.type)}
                              </div>
                              <div>
                                <div className="font-medium">{doc.title}</div>
                                <div className="text-xs text-muted-foreground">
                                  ID: #{doc.id}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className="capitalize">
                              {doc.type}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {doc.owner?.fullName || `User ${doc.ownerId}`}
                          </TableCell>
                          <TableCell>
                            {format(new Date(doc.updatedAt), 'MMM d, yyyy')}
                          </TableCell>
                          <TableCell>
                            {formatSize(doc.content.length * 2)}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                  <MoreHorizontal className="h-4 w-4" />
                                  <span className="sr-only">Open menu</span>
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Download className="mr-2 h-4 w-4" />
                                  Download
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Share2 className="mr-2 h-4 w-4" />
                                  Share
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem className="text-red-600">
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-10 text-muted-foreground">
                          No documents found. Try adjusting your search or filters.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="recent" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center justify-center text-center py-10">
                <FileText className="h-16 w-16 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium">Your Recent Documents</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Documents you've viewed or edited recently will appear here
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="shared" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center justify-center text-center py-10">
                <Share2 className="h-16 w-16 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium">Shared Documents</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Documents shared with you by other team members will appear here
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="templates" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center justify-center text-center py-10">
                <FileText className="h-16 w-16 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium">Document Templates</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Standardized templates for various HR documents will appear here
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="archived" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center justify-center text-center py-10">
                <Archive className="h-16 w-16 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium">Archived Documents</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Documents that have been archived will appear here
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// This is a placeholder component for Archive icon
function Archive(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <rect x="2" y="4" width="20" height="5" rx="2" />
      <path d="M4 9v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9" />
      <path d="M10 13h4" />
    </svg>
  );
}
