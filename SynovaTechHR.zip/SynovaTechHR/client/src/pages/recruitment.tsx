import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs as SecondaryTabs, TabsContent as SecondaryTabsContent, TabsList as SecondaryTabsList, TabsTrigger as SecondaryTabsTrigger } from "@/components/ui/tabs";
import { 
  FileSpreadsheet, 
  Search, 
  Filter, 
  ArrowUpDown, 
  Briefcase, 
  Users, 
  Star,
  UserPlus,
  FileText,
  MoreHorizontal,
  FileQuestion,
  FileSearch,
  Lightbulb,
  CheckCircle2,
  XCircle,
  AlertCircle
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { parseResume, screenCandidate, generateInterviewQuestions, optimizeJobDescription } from "@/lib/openai";

interface JobListing {
  id: number;
  title: string;
  department: string;
  description: string;
  requirements: string;
  salary: string;
  location: string;
  jobType: string;
  status: string;
  postedDate: string;
  closingDate: string;
}

interface Candidate {
  id: number;
  jobId: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  resumeUrl: string;
  status: string;
  notes: string;
  aiScore: number;
  aiNotes: string;
  appliedDate: string;
}

export default function Recruitment() {
  const [activeTab, setActiveTab] = useState("positions");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedJob, setSelectedJob] = useState<number | null>(null);
  
  const { data: jobListings, isLoading: isLoadingJobs } = useQuery<JobListing[]>({
    queryKey: ['/api/job-listings'],
  });
  
  const { data: candidates, isLoading: isLoadingCandidates } = useQuery<Candidate[]>({
    queryKey: ['/api/candidates', { jobId: selectedJob }],
    enabled: !!selectedJob
  });
  
  // Filter job listings based on search query
  const filteredJobs = jobListings?.filter(job => 
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.location.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleJobSelect = (jobId: number) => {
    setSelectedJob(jobId);
    setActiveTab("candidates");
  };
  
  // Helper function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'open':
        return <Badge className="bg-green-100 text-green-800 border-green-200">Open</Badge>;
      case 'closed':
        return <Badge className="bg-neutral-100 text-neutral-800 border-neutral-200">Closed</Badge>;
      case 'filled':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Filled</Badge>;
      case 'applied':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Applied</Badge>;
      case 'screened':
        return <Badge className="bg-purple-100 text-purple-800 border-purple-200">Screened</Badge>;
      case 'interviewing':
        return <Badge className="bg-amber-100 text-amber-800 border-amber-200">Interviewing</Badge>;
      case 'offered':
        return <Badge className="bg-green-100 text-green-800 border-green-200">Offered</Badge>;
      case 'hired':
        return <Badge className="bg-green-700 text-white">Hired</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800 border-red-200">Rejected</Badge>;
      default:
        return <Badge className="bg-neutral-100 text-neutral-800">{status}</Badge>;
    }
  };
  
  // States for AI tools
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [resumeText, setResumeText] = useState<string>("");
  const [isParsingResume, setIsParsingResume] = useState(false);
  const [parsedResume, setParsedResume] = useState<any>(null);
  const [isGeneratingQuestions, setIsGeneratingQuestions] = useState(false);
  const [interviewQuestions, setInterviewQuestions] = useState<any>(null);
  const [isOptimizingDescription, setIsOptimizingDescription] = useState(false);
  const [optimizedJobDescription, setOptimizedJobDescription] = useState<any>(null);
  
  // Ref for textarea
  const resumeTextareaRef = useRef<HTMLTextAreaElement>(null);
  
  // Query client for mutations
  const queryClient = useQueryClient();
  
  // Resume parsing function
  const handleParseResume = async () => {
    if (!resumeText) return;
    
    setIsParsingResume(true);
    try {
      const result = await parseResume(resumeText);
      setParsedResume(result);
    } catch (error) {
      console.error("Failed to parse resume:", error);
    } finally {
      setIsParsingResume(false);
    }
  };
  
  // Generate interview questions
  const handleGenerateInterviewQuestions = async () => {
    if (!selectedJob) return;
    
    setIsGeneratingQuestions(true);
    try {
      const result = await generateInterviewQuestions(
        selectedJob,
        selectedCandidate?.id,
        resumeText
      );
      setInterviewQuestions(result);
    } catch (error) {
      console.error("Failed to generate interview questions:", error);
    } finally {
      setIsGeneratingQuestions(false);
    }
  };
  
  // Optimize job description
  const handleOptimizeJobDescription = async () => {
    if (!selectedJob) return;
    
    setIsOptimizingDescription(true);
    try {
      const job = jobListings?.find(j => j.id === selectedJob);
      if (!job) return;
      
      const result = await optimizeJobDescription(selectedJob);
      setOptimizedJobDescription(result);
    } catch (error) {
      console.error("Failed to optimize job description:", error);
    } finally {
      setIsOptimizingDescription(false);
    }
  };
  
  // Screen candidate using AI
  const screenCandidateMutation = useMutation({
    mutationFn: async ({ candidateId, resume }: { candidateId: number, resume: string }) => {
      return screenCandidate(candidateId, resume);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/candidates', { jobId: selectedJob }] });
    }
  });
  
  const handleScreenCandidate = async (candidateId: number) => {
    if (!resumeText) return;
    
    screenCandidateMutation.mutate({ candidateId, resume: resumeText });
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Recruitment</h2>
          <p className="text-muted-foreground">
            Manage job positions and screen candidates with AI-powered talent acquisition.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button>
            <Briefcase className="mr-2 h-4 w-4" />
            Post New Position
          </Button>
          <Button variant="outline">
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            Import Candidates
          </Button>
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search positions or candidates..."
            className="w-full pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="h-9">
                <Lightbulb className="mr-2 h-4 w-4" />
                Optimize Job Description
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[700px]">
              <DialogHeader>
                <DialogTitle>AI-Powered Job Description Optimization</DialogTitle>
                <DialogDescription>
                  Improve your job descriptions to attract diverse, qualified candidates
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto">
                {optimizedJobDescription ? (
                  <div className="space-y-6">
                    <div className="grid gap-6 md:grid-cols-2">
                      <div>
                        <h3 className="text-sm font-medium mb-2">Original Description</h3>
                        <div className="border rounded-md p-4 bg-muted/20 text-sm h-60 overflow-y-auto">
                          {optimizedJobDescription.original}
                        </div>
                      </div>
                      <div>
                        <h3 className="text-sm font-medium mb-2">Optimized Description</h3>
                        <div className="border rounded-md p-4 bg-blue-50/50 text-sm h-60 overflow-y-auto">
                          {optimizedJobDescription.optimized}
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <h3 className="text-sm font-medium">Analysis & Suggestions</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex items-center">
                          <div className="mr-2 w-full">
                            <div className="text-xs mb-1">Inclusivity Score</div>
                            <Progress 
                              value={optimizedJobDescription.inclusivity_score * 10} 
                              className="h-2"
                            />
                          </div>
                          <div className="text-sm font-medium">{optimizedJobDescription.inclusivity_score}/10</div>
                        </div>
                        <div className="flex items-center">
                          <div className="mr-2 w-full">
                            <div className="text-xs mb-1">Clarity Score</div>
                            <Progress 
                              value={optimizedJobDescription.clarity_score * 10} 
                              className="h-2"
                            />
                          </div>
                          <div className="text-sm font-medium">{optimizedJobDescription.clarity_score}/10</div>
                        </div>
                      </div>
                      
                      <div className="border rounded-md p-3 bg-muted/20">
                        <h4 className="text-sm font-medium mb-2">Improvement Suggestions</h4>
                        <ul className="list-disc pl-5 space-y-1">
                          {optimizedJobDescription.suggestions.map((suggestion, idx) => (
                            <li key={idx} className="text-sm">{suggestion}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-2">
                      <Button 
                        variant="outline"
                        onClick={() => setOptimizedJobDescription(null)}
                      >
                        Reset
                      </Button>
                      <Button 
                        variant="default"
                        onClick={handleOptimizeJobDescription}
                        disabled={isOptimizingDescription}
                      >
                        {isOptimizingDescription ? "Optimizing..." : "Re-Optimize"}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">Job Selection</h3>
                      <div className="flex items-start gap-4">
                        <div className="flex-1">
                          <label className="text-sm text-muted-foreground">Select a job position to optimize</label>
                          <select
                            className="w-full mt-1 p-2 border rounded-md"
                            value={selectedJob || ""}
                            onChange={(e) => setSelectedJob(e.target.value ? parseInt(e.target.value) : null)}
                          >
                            <option value="">Choose a position</option>
                            {jobListings?.map(job => (
                              <option key={job.id} value={job.id}>{job.title}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                    
                    {selectedJob && (
                      <div className="border rounded-md p-4 bg-blue-50/20">
                        <h3 className="text-sm font-medium mb-2">Optimization Options</h3>
                        <div className="space-y-3">
                          <div>
                            <label className="text-sm text-muted-foreground">Target Audience (Optional)</label>
                            <Input 
                              placeholder="e.g., Senior professionals, career changers, diverse candidates"
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <label className="text-sm text-muted-foreground">Inclusivity Focus (Optional)</label>
                            <Input 
                              placeholder="e.g., Gender neutral language, accessibility, diversity"
                              className="mt-1"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div className="flex justify-end">
                      <Button 
                        onClick={handleOptimizeJobDescription}
                        disabled={!selectedJob || isOptimizingDescription}
                      >
                        {isOptimizingDescription ? (
                          <>Optimizing Job Description...</>
                        ) : (
                          <>
                            <Lightbulb className="mr-2 h-4 w-4" />
                            Optimize with AI
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      <Card>
        <CardHeader className="p-4 border-b">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-2 w-full md:w-auto">
              <TabsTrigger value="positions">
                <Briefcase className="mr-2 h-4 w-4" />
                Job Positions
              </TabsTrigger>
              <TabsTrigger value="candidates" disabled={!selectedJob}>
                <Users className="mr-2 h-4 w-4" />
                Candidates
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent className="p-0">
          <TabsContent value="positions" className="m-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[300px]">
                    <Button variant="ghost" size="sm" className="font-medium flex gap-1">
                      Position <ArrowUpDown className="h-4 w-4" />
                    </Button>
                  </TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Posted Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoadingJobs ? (
                  Array(5).fill(0).map((_, index) => (
                    <TableRow key={index}>
                      <TableCell><Skeleton className="h-5 w-48" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-6 w-16 rounded-full" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-8 rounded-full ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : filteredJobs && filteredJobs.length > 0 ? (
                  filteredJobs.map((job) => (
                    <TableRow key={job.id}>
                      <TableCell>
                        <div className="font-medium">{job.title}</div>
                        <div className="text-sm text-muted-foreground">{job.jobType}</div>
                      </TableCell>
                      <TableCell>{job.department}</TableCell>
                      <TableCell>{job.location}</TableCell>
                      <TableCell>{getStatusBadge(job.status)}</TableCell>
                      <TableCell>{new Date(job.postedDate).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => handleJobSelect(job.id)}
                          >
                            <Users className="h-4 w-4 mr-1" />
                            View Candidates
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>Edit Position</DropdownMenuItem>
                              <DropdownMenuItem>Close Position</DropdownMenuItem>
                              <DropdownMenuItem>Duplicate</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-10 text-muted-foreground">
                      No job positions found. Try adjusting your search or create a new position.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TabsContent>
          
          <TabsContent value="candidates" className="m-0">
            {selectedJob && (
              <div>
                <div className="p-4 bg-neutral-50 border-b">
                  <h3 className="text-lg font-medium">
                    {jobListings?.find(j => j.id === selectedJob)?.title} - Candidates
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Department: {jobListings?.find(j => j.id === selectedJob)?.department}
                  </p>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[250px]">
                        <Button variant="ghost" size="sm" className="font-medium flex gap-1">
                          Candidate <ArrowUpDown className="h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Applied Date</TableHead>
                      <TableHead className="w-[100px]">
                        <div className="flex items-center ai-badge">
                          AI Score
                        </div>
                      </TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoadingCandidates ? (
                      Array(3).fill(0).map((_, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="space-y-1">
                              <Skeleton className="h-5 w-36" />
                              <Skeleton className="h-4 w-48" />
                            </div>
                          </TableCell>
                          <TableCell><Skeleton className="h-6 w-16 rounded-full" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                          <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                          <TableCell><Skeleton className="h-8 w-20 rounded ml-auto" /></TableCell>
                        </TableRow>
                      ))
                    ) : candidates && candidates.length > 0 ? (
                      candidates.map((candidate) => (
                        <TableRow key={candidate.id}>
                          <TableCell>
                            <div className="font-medium">
                              {candidate.firstName} {candidate.lastName}
                            </div>
                            <div className="text-sm text-muted-foreground">{candidate.email}</div>
                          </TableCell>
                          <TableCell>{getStatusBadge(candidate.status)}</TableCell>
                          <TableCell>{new Date(candidate.appliedDate).toLocaleDateString()}</TableCell>
                          <TableCell>
                            {candidate.aiScore ? (
                              <div className="flex items-center gap-1">
                                <Progress 
                                  value={candidate.aiScore} 
                                  className="h-2 w-12" 
                                  indicatorClassName={
                                    candidate.aiScore >= 80 ? "bg-green-500" :
                                    candidate.aiScore >= 60 ? "bg-amber-500" :
                                    "bg-red-500"
                                  }
                                />
                                <span className="text-sm font-medium">
                                  {candidate.aiScore}%
                                </span>
                              </div>
                            ) : (
                              <Button variant="outline" size="sm" className="h-7 text-xs px-2">
                                Screen
                              </Button>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm" onClick={() => {
                                    setSelectedCandidate(candidate);
                                    setResumeText("");
                                    setParsedResume(null);
                                    setInterviewQuestions(null);
                                  }}>
                                    <FileText className="h-4 w-4 mr-1" />
                                    Review
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[700px]">
                                  <DialogHeader>
                                    <DialogTitle>
                                      {candidate.firstName} {candidate.lastName}'s Application
                                    </DialogTitle>
                                    <DialogDescription>
                                      Applied on {new Date(candidate.appliedDate).toLocaleDateString()}
                                    </DialogDescription>
                                  </DialogHeader>
                                  
                                  <div className="space-y-4 py-2 max-h-[70vh] overflow-y-auto">
                                    <SecondaryTabs defaultValue="profile" className="w-full">
                                      <SecondaryTabsList className="grid w-full grid-cols-3">
                                        <SecondaryTabsTrigger value="profile">Profile</SecondaryTabsTrigger>
                                        <SecondaryTabsTrigger value="ai-screening">AI Screening</SecondaryTabsTrigger>
                                        <SecondaryTabsTrigger value="interview-prep" disabled={!candidate.aiScore}>Interview Prep</SecondaryTabsTrigger>
                                      </SecondaryTabsList>
                                      
                                      <SecondaryTabsContent value="profile" className="space-y-4 pt-4">
                                        <div className="grid md:grid-cols-2 gap-4">
                                          <div className="space-y-3">
                                            <div>
                                              <h4 className="text-sm font-medium">Status</h4>
                                              <div className="mt-1">{getStatusBadge(candidate.status)}</div>
                                            </div>
                                            
                                            <div className="space-y-2">
                                              <h4 className="text-sm font-medium">Contact Information</h4>
                                              <div className="grid grid-cols-2 gap-2 text-sm">
                                                <div>
                                                  <div className="text-muted-foreground">Email</div>
                                                  <div>{candidate.email}</div>
                                                </div>
                                                <div>
                                                  <div className="text-muted-foreground">Phone</div>
                                                  <div>{candidate.phone || "Not provided"}</div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          
                                          <div className="space-y-3">
                                            <div className="space-y-2">
                                              <h4 className="text-sm font-medium">Resume</h4>
                                              <div className="border rounded p-3 bg-muted/20 text-sm">
                                                {candidate.resumeUrl ? (
                                                  <a 
                                                    href={candidate.resumeUrl} 
                                                    target="_blank" 
                                                    rel="noopener noreferrer"
                                                    className="text-blue-600 hover:underline flex items-center"
                                                  >
                                                    <FileText className="h-4 w-4 mr-1" />
                                                    View Resume
                                                  </a>
                                                ) : (
                                                  <span className="text-muted-foreground">No resume uploaded</span>
                                                )}
                                              </div>
                                            </div>
                                            
                                            <div className="space-y-2">
                                              <h4 className="text-sm font-medium">Notes</h4>
                                              <Textarea 
                                                placeholder="Add notes about this candidate..." 
                                                value={candidate.notes || ""}
                                                readOnly
                                                className="h-24"
                                              />
                                            </div>
                                          </div>
                                        </div>
                                        
                                        {/* Resume parser section */}
                                        {parsedResume && (
                                          <div className="border rounded-md p-4 bg-muted/20 mt-4">
                                            <h4 className="font-semibold flex items-center">
                                              <FileSearch className="text-blue-500 h-4 w-4 mr-1" />
                                              Resume Analysis
                                            </h4>
                                            <Accordion type="single" collapsible className="w-full mt-2">
                                              {parsedResume.skills && parsedResume.skills.length > 0 && (
                                                <AccordionItem value="skills">
                                                  <AccordionTrigger className="text-sm font-medium">Skills</AccordionTrigger>
                                                  <AccordionContent>
                                                    <div className="flex flex-wrap gap-1 pt-1">
                                                      {parsedResume.skills.map((skill: string, idx: number) => (
                                                        <Badge key={idx} variant="outline" className="bg-blue-50">{skill}</Badge>
                                                      ))}
                                                    </div>
                                                  </AccordionContent>
                                                </AccordionItem>
                                              )}
                                              {parsedResume.education && parsedResume.education.length > 0 && (
                                                <AccordionItem value="education">
                                                  <AccordionTrigger className="text-sm font-medium">Education</AccordionTrigger>
                                                  <AccordionContent>
                                                    <ul className="list-disc pl-5 space-y-1">
                                                      {parsedResume.education.map((edu: string, idx: number) => (
                                                        <li key={idx} className="text-sm">{edu}</li>
                                                      ))}
                                                    </ul>
                                                  </AccordionContent>
                                                </AccordionItem>
                                              )}
                                              {parsedResume.experience && parsedResume.experience.length > 0 && (
                                                <AccordionItem value="experience">
                                                  <AccordionTrigger className="text-sm font-medium">Experience</AccordionTrigger>
                                                  <AccordionContent>
                                                    <ul className="list-disc pl-5 space-y-1">
                                                      {parsedResume.experience.map((exp: string, idx: number) => (
                                                        <li key={idx} className="text-sm">{exp}</li>
                                                      ))}
                                                    </ul>
                                                  </AccordionContent>
                                                </AccordionItem>
                                              )}
                                              {parsedResume.certifications && parsedResume.certifications.length > 0 && (
                                                <AccordionItem value="certifications">
                                                  <AccordionTrigger className="text-sm font-medium">Certifications</AccordionTrigger>
                                                  <AccordionContent>
                                                    <ul className="list-disc pl-5 space-y-1">
                                                      {parsedResume.certifications.map((cert: string, idx: number) => (
                                                        <li key={idx} className="text-sm">{cert}</li>
                                                      ))}
                                                    </ul>
                                                  </AccordionContent>
                                                </AccordionItem>
                                              )}
                                            </Accordion>
                                          </div>
                                        )}
                                      </SecondaryTabsContent>
                                      
                                      <SecondaryTabsContent value="ai-screening" className="space-y-4 pt-4">
                                        {candidate.aiScore ? (
                                          <div className="space-y-4">
                                            <div className="space-y-2 border rounded-md p-4 bg-muted/20">
                                              <h4 className="font-semibold flex items-center">
                                                <Star className="text-amber-500 h-4 w-4 mr-1" />
                                                AI Screening Results
                                              </h4>
                                              <div className="space-y-1">
                                                <div className="text-sm text-muted-foreground">Match Score</div>
                                                <div className="flex items-center space-x-2">
                                                  <Progress 
                                                    value={candidate.aiScore} 
                                                    className={`h-2.5 ${
                                                      candidate.aiScore > 80 ? "bg-green-100" : 
                                                      candidate.aiScore > 60 ? "bg-amber-100" : "bg-red-100"
                                                    }`}
                                                  />
                                                  <span className="text-sm font-medium">{candidate.aiScore}%</span>
                                                </div>
                                              </div>
                                              
                                              {/* Parse aiNotes if available */}
                                              {candidate.aiNotes && (
                                                <div className="space-y-3 pt-2">
                                                  {(() => {
                                                    try {
                                                      const aiData = JSON.parse(candidate.aiNotes);
                                                      return (
                                                        <>
                                                          <div>
                                                            <div className="text-sm text-muted-foreground">Feedback</div>
                                                            <p className="text-sm mt-1">{aiData.feedback}</p>
                                                          </div>
                                                          
                                                          {aiData.recommendation && (
                                                            <div>
                                                              <div className="text-sm text-muted-foreground">Recommendation</div>
                                                              <p className="text-sm font-medium mt-1 flex items-center">
                                                                {aiData.recommendation.toLowerCase().includes('highly') ? (
                                                                  <CheckCircle2 className="h-4 w-4 text-green-500 mr-1" />
                                                                ) : aiData.recommendation.toLowerCase().includes('interview') ? (
                                                                  <AlertCircle className="h-4 w-4 text-amber-500 mr-1" />
                                                                ) : aiData.recommendation.toLowerCase().includes('reject') ? (
                                                                  <XCircle className="h-4 w-4 text-red-500 mr-1" />
                                                                ) : null}
                                                                {aiData.recommendation}
                                                              </p>
                                                            </div>
                                                          )}
                                                          
                                                          {aiData.skills_match && (
                                                            <div>
                                                              <div className="text-sm text-muted-foreground">Skills Analysis</div>
                                                              <div className="mt-2 space-y-2">
                                                                <div>
                                                                  <div className="text-xs font-medium text-green-700">Matched Skills</div>
                                                                  <div className="flex flex-wrap gap-1 mt-1">
                                                                    {aiData.skills_match.matched.map((skill: string, i: number) => (
                                                                      <Badge key={i} variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                                                        {skill}
                                                                      </Badge>
                                                                    ))}
                                                                  </div>
                                                                </div>
                                                                <div>
                                                                  <div className="text-xs font-medium text-red-700">Missing Skills</div>
                                                                  <div className="flex flex-wrap gap-1 mt-1">
                                                                    {aiData.skills_match.missing.map((skill: string, i: number) => (
                                                                      <Badge key={i} variant="outline" className="bg-red-50 text-red-700 border-red-200">
                                                                        {skill}
                                                                      </Badge>
                                                                    ))}
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          )}
                                                          
                                                          {aiData.experience_alignment && (
                                                            <div>
                                                              <div className="text-sm text-muted-foreground">Experience Alignment</div>
                                                              <p className="text-sm font-medium mt-1">
                                                                {aiData.experience_alignment}
                                                              </p>
                                                            </div>
                                                          )}
                                                        </>
                                                      );
                                                    } catch (e) {
                                                      return (
                                                        <div>
                                                          <div className="text-sm text-muted-foreground">Feedback</div>
                                                          <p className="text-sm mt-1">{candidate.aiNotes}</p>
                                                        </div>
                                                      );
                                                    }
                                                  })()}
                                                </div>
                                              )}
                                            </div>
                                            
                                            <div className="border rounded-md p-4 bg-blue-50/50">
                                              <h4 className="font-semibold">Re-run AI Screening</h4>
                                              <p className="text-sm text-muted-foreground">
                                                Update or paste a new resume to re-analyze this candidate.
                                              </p>
                                              <Textarea 
                                                placeholder="Paste resume text here..."
                                                className="mt-2 h-32 bg-white"
                                                value={resumeText}
                                                onChange={(e) => setResumeText(e.target.value)}
                                                ref={resumeTextareaRef}
                                              />
                                              <div className="flex gap-2 mt-3">
                                                <Button 
                                                  variant="outline" 
                                                  className="flex-1"
                                                  onClick={handleParseResume}
                                                  disabled={!resumeText || isParsingResume}
                                                >
                                                  <FileSearch className="h-4 w-4 mr-1" />
                                                  {isParsingResume ? "Parsing..." : "Parse Resume"}
                                                </Button>
                                                <Button 
                                                  className="flex-1"
                                                  onClick={() => handleScreenCandidate(candidate.id)}
                                                  disabled={!resumeText || screenCandidateMutation.isPending}
                                                >
                                                  <Star className="h-4 w-4 mr-1" />
                                                  {screenCandidateMutation.isPending ? "Analyzing..." : "Screen Candidate"}
                                                </Button>
                                              </div>
                                            </div>
                                          </div>
                                        ) : (
                                          <div className="space-y-4">
                                            <Alert variant="default" className="bg-amber-50 text-amber-800 border-amber-200">
                                              <AlertCircle className="h-4 w-4" />
                                              <AlertTitle>No AI screening results available</AlertTitle>
                                              <AlertDescription>
                                                Run an AI screening analysis to evaluate this candidate against the job requirements.
                                              </AlertDescription>
                                            </Alert>
                                            
                                            <div className="border rounded-md p-4 bg-muted/20">
                                              <h4 className="font-semibold">Run AI Screening</h4>
                                              <p className="text-sm text-muted-foreground">
                                                Upload or paste the candidate's resume to analyze their fit for this position.
                                              </p>
                                              <Textarea 
                                                placeholder="Paste resume text here..."
                                                className="mt-2 h-32"
                                                value={resumeText}
                                                onChange={(e) => setResumeText(e.target.value)}
                                                ref={resumeTextareaRef}
                                              />
                                              <div className="flex gap-2 mt-3">
                                                <Button 
                                                  variant="outline" 
                                                  className="flex-1"
                                                  onClick={handleParseResume}
                                                  disabled={!resumeText || isParsingResume}
                                                >
                                                  <FileSearch className="h-4 w-4 mr-1" />
                                                  {isParsingResume ? "Parsing..." : "Parse Resume"}
                                                </Button>
                                                <Button 
                                                  className="flex-1"
                                                  onClick={() => handleScreenCandidate(candidate.id)}
                                                  disabled={!resumeText || screenCandidateMutation.isPending}
                                                >
                                                  <Star className="h-4 w-4 mr-1" />
                                                  {screenCandidateMutation.isPending ? "Analyzing..." : "Screen Candidate"}
                                                </Button>
                                              </div>
                                            </div>
                                          </div>
                                        )}
                                      </SecondaryTabsContent>
                                      
                                      <SecondaryTabsContent value="interview-prep" className="space-y-4 pt-4">
                                        <div className="flex justify-between items-center">
                                          <h4 className="font-semibold flex items-center">
                                            <FileQuestion className="text-purple-500 h-4 w-4 mr-1" />
                                            AI-Generated Interview Questions
                                          </h4>
                                          <Button 
                                            variant="outline" 
                                            size="sm" 
                                            className="text-xs"
                                            onClick={handleGenerateInterviewQuestions}
                                            disabled={isGeneratingQuestions}
                                          >
                                            {isGeneratingQuestions ? "Generating..." : "Generate Questions"}
                                          </Button>
                                        </div>
                                        
                                        {interviewQuestions ? (
                                          <div className="space-y-4">
                                            {interviewQuestions.general && interviewQuestions.general.length > 0 && (
                                              <Card>
                                                <CardHeader className="py-3 px-4">
                                                  <CardTitle className="text-sm">General Questions</CardTitle>
                                                </CardHeader>
                                                <CardContent className="py-2 px-4">
                                                  <ul className="list-disc pl-5 space-y-2">
                                                    {interviewQuestions.general.map((question: string, idx: number) => (
                                                      <li key={idx} className="text-sm">{question}</li>
                                                    ))}
                                                  </ul>
                                                </CardContent>
                                              </Card>
                                            )}
                                            
                                            {interviewQuestions.technical && interviewQuestions.technical.length > 0 && (
                                              <Card>
                                                <CardHeader className="py-3 px-4">
                                                  <CardTitle className="text-sm">Technical Questions</CardTitle>
                                                </CardHeader>
                                                <CardContent className="py-2 px-4">
                                                  <ul className="list-disc pl-5 space-y-2">
                                                    {interviewQuestions.technical.map((question: string, idx: number) => (
                                                      <li key={idx} className="text-sm">{question}</li>
                                                    ))}
                                                  </ul>
                                                </CardContent>
                                              </Card>
                                            )}
                                            
                                            {interviewQuestions.behavioral && interviewQuestions.behavioral.length > 0 && (
                                              <Card>
                                                <CardHeader className="py-3 px-4">
                                                  <CardTitle className="text-sm">Behavioral Questions</CardTitle>
                                                </CardHeader>
                                                <CardContent className="py-2 px-4">
                                                  <ul className="list-disc pl-5 space-y-2">
                                                    {interviewQuestions.behavioral.map((question: string, idx: number) => (
                                                      <li key={idx} className="text-sm">{question}</li>
                                                    ))}
                                                  </ul>
                                                </CardContent>
                                              </Card>
                                            )}
                                            
                                            {interviewQuestions.custom && interviewQuestions.custom.length > 0 && (
                                              <Card>
                                                <CardHeader className="py-3 px-4">
                                                  <CardTitle className="text-sm">Custom Questions</CardTitle>
                                                  <CardDescription className="text-xs">
                                                    Tailored to candidate's specific experience and background
                                                  </CardDescription>
                                                </CardHeader>
                                                <CardContent className="py-2 px-4">
                                                  <ul className="list-disc pl-5 space-y-2">
                                                    {interviewQuestions.custom.map((question: string, idx: number) => (
                                                      <li key={idx} className="text-sm">{question}</li>
                                                    ))}
                                                  </ul>
                                                </CardContent>
                                              </Card>
                                            )}
                                          </div>
                                        ) : (
                                          <div className="border rounded-md p-6 bg-muted/20 text-center">
                                            <p className="text-muted-foreground">
                                              Click "Generate Questions" to create AI-powered interview questions based on the job requirements and candidate profile.
                                            </p>
                                          </div>
                                        )}
                                      </SecondaryTabsContent>
                                    </SecondaryTabs>
                                  </div>
                                </DialogContent>
                              </Dialog>
                              
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>Move to Screening</DropdownMenuItem>
                                  <DropdownMenuItem>Schedule Interview</DropdownMenuItem>
                                  <DropdownMenuItem>Send Email</DropdownMenuItem>
                                  <DropdownMenuItem>Reject Candidate</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                          No candidates found for this position.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </TabsContent>
        </CardContent>
      </Card>
    </div>
  );
}
