import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Users, 
  Briefcase, 
  BarChart3, 
  Calendar, 
  Clock, 
  FileText, 
  Files, 
  Settings 
} from "lucide-react";

interface SidebarItemProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  isAI?: boolean;
}

function SidebarItem({ href, icon, children, isAI = false }: SidebarItemProps) {
  const [location] = useLocation();
  const isActive = location === href || (href !== "/" && location.startsWith(href));
  
  return (
    <Link href={href}>
      <div 
        className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md cursor-pointer",
          isActive
            ? "bg-primary-50 text-primary-700"
            : "text-neutral-700 hover:bg-neutral-50 hover:text-primary-700",
          isAI && "ai-badge"
        )}
      >
        <span className="mr-3 h-5 w-5">{icon}</span>
        {children}
      </div>
    </Link>
  );
}

export default function Sidebar() {
  return (
    <aside className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64 border-r border-neutral-200 bg-white">
        <div className="flex items-center justify-center h-16 px-4 border-b border-neutral-200 bg-primary-700">
          <div className="flex items-center space-x-2">
            <svg className="h-8 w-8 text-white" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 4L4 8L12 12L20 8L12 4Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M4 12L12 16L20 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M4 16L12 20L20 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="text-white font-semibold text-lg">Synovatech One HR</span>
          </div>
        </div>
        
        <div className="flex flex-col flex-1 overflow-y-auto">
          <nav className="flex-1 px-2 py-4 space-y-1">
            <SidebarItem href="/" icon={<Home />}>Dashboard</SidebarItem>
            <SidebarItem href="/employees" icon={<Users />}>Employees</SidebarItem>
            <SidebarItem href="/recruitment" icon={<Briefcase />} isAI>Recruitment</SidebarItem>
            <SidebarItem href="/performance" icon={<BarChart3 />} isAI>Performance</SidebarItem>
            <SidebarItem href="/leave-management" icon={<Calendar />}>Leave Management</SidebarItem>
            <SidebarItem href="/attendance" icon={<Clock />}>Attendance</SidebarItem>
            <SidebarItem href="/reports" icon={<FileText />} isAI>Reports & Analytics</SidebarItem>
            <SidebarItem href="/documents" icon={<Files />}>Documents</SidebarItem>
            <SidebarItem href="/settings" icon={<Settings />}>Settings</SidebarItem>
          </nav>
        </div>
        
        <div className="flex-shrink-0 p-4 border-t border-neutral-200">
          <a href="#" className="flex items-center">
            <div className="relative">
              <img 
                className="h-10 w-10 rounded-full" 
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                alt="User avatar" 
              />
              <span className="absolute right-0 bottom-0 block h-2.5 w-2.5 rounded-full bg-green-500 ring-2 ring-white"></span>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-neutral-700">Sarah Johnson</p>
              <p className="text-xs font-medium text-neutral-500">HR Manager</p>
            </div>
          </a>
        </div>
      </div>
    </aside>
  );
}
