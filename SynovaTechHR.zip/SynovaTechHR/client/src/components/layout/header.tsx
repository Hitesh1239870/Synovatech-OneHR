import { useState } from "react";
import { UserNav } from "./user-nav";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { MessageSquare, BellRing } from "lucide-react";
import { useAIAssistant } from "@/hooks/use-ai-assistant";

interface HeaderProps {
  title: string;
}

export default function Header({ title }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { toggleAIAssistant } = useAIAssistant();
  
  return (
    <header className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-neutral-800">{title}</h1>
        <div className="ml-4 flex items-center space-x-4">
          <div className="relative md:block">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg className="h-5 w-5 text-neutral-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
              </svg>
            </div>
            <Input
              id="search"
              name="search"
              className="block w-full pl-10 pr-3 py-2 border border-neutral-300 rounded-md leading-5 bg-white placeholder-neutral-500 focus:outline-none focus:placeholder-neutral-400 focus:ring-1 focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
              placeholder="Search"
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="p-1 rounded-full text-neutral-400 hover:text-neutral-500 focus:outline-none"
          >
            <BellRing className="h-6 w-6" />
            <span className="sr-only">Notifications</span>
          </Button>

          <Button 
            variant="ghost"
            size="icon"
            className="p-1 rounded-full text-neutral-400 hover:text-neutral-500 focus:outline-none ai-active"
            onClick={toggleAIAssistant}
          >
            <MessageSquare className="h-6 w-6" />
            <span className="sr-only">ZenaI Chatbot</span>
          </Button>
          
          <div className="hidden md:block h-6 w-px bg-neutral-300"></div>
          
          <UserNav />
        </div>
      </div>
    </header>
  );
}
