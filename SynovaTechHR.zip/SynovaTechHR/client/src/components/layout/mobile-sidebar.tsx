import { useState } from "react";
import { Link } from "wouter";
import { 
  Menu, 
  X, 
  Home, 
  Users, 
  Briefcase, 
  BarChart3, 
  Calendar, 
  Clock, 
  FileText, 
  Files, 
  Settings,
  BellRing
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface MobileSidebarItemProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  isAI?: boolean;
  setOpen: (open: boolean) => void;
}

function MobileSidebarItem({ href, icon, children, isAI = false, setOpen }: MobileSidebarItemProps) {
  return (
    <Link href={href}>
      <div 
        className={cn(
          "flex items-center px-3 py-2 text-sm font-medium rounded-md text-neutral-700 hover:bg-neutral-50 hover:text-primary-700 cursor-pointer",
          isAI && "ai-badge"
        )}
        onClick={() => setOpen(false)}
      >
        <span className="mr-3 h-5 w-5">{icon}</span>
        {children}
      </div>
    </Link>
  );
}

export default function MobileSidebar() {
  const [open, setOpen] = useState(false);
  
  return (
    <div className="md:hidden bg-primary-700 fixed top-0 inset-x-0 z-50">
      <div className="flex items-center justify-between h-16 px-4">
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="text-white hover:bg-primary-600">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Open menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-64" overlayClassName="bg-black/50">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-center h-16 px-4 border-b border-neutral-200 bg-primary-700">
                <div className="flex items-center space-x-2">
                  <svg className="h-8 w-8 text-white" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 4L4 8L12 12L20 8L12 4Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M4 12L12 16L20 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M4 16L12 20L20 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  <span className="text-white font-semibold text-lg">Synovatech One HR</span>
                </div>
              </div>
              
              <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
                <MobileSidebarItem href="/" icon={<Home />} setOpen={setOpen}>Dashboard</MobileSidebarItem>
                <MobileSidebarItem href="/employees" icon={<Users />} setOpen={setOpen}>Employees</MobileSidebarItem>
                <MobileSidebarItem href="/recruitment" icon={<Briefcase />} isAI setOpen={setOpen}>Recruitment</MobileSidebarItem>
                <MobileSidebarItem href="/performance" icon={<BarChart3 />} isAI setOpen={setOpen}>Performance</MobileSidebarItem>
                <MobileSidebarItem href="/leave-management" icon={<Calendar />} setOpen={setOpen}>Leave Management</MobileSidebarItem>
                <MobileSidebarItem href="/attendance" icon={<Clock />} setOpen={setOpen}>Attendance</MobileSidebarItem>
                <MobileSidebarItem href="/reports" icon={<FileText />} isAI setOpen={setOpen}>Reports & Analytics</MobileSidebarItem>
                <MobileSidebarItem href="/documents" icon={<Files />} setOpen={setOpen}>Documents</MobileSidebarItem>
                <MobileSidebarItem href="/settings" icon={<Settings />} setOpen={setOpen}>Settings</MobileSidebarItem>
              </nav>
              
              <div className="flex-shrink-0 p-4 border-t border-neutral-200">
                <a href="#" className="flex items-center">
                  <div className="relative">
                    <img 
                      className="h-10 w-10 rounded-full" 
                      src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                      alt="User avatar" 
                    />
                    <span className="absolute right-0 bottom-0 block h-2.5 w-2.5 rounded-full bg-green-500 ring-2 ring-white"></span>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-neutral-700">Sarah Johnson</p>
                    <p className="text-xs font-medium text-neutral-500">HR Manager</p>
                  </div>
                </a>
              </div>
            </div>
          </SheetContent>
        </Sheet>

        <div className="flex items-center space-x-2">
          <svg className="h-8 w-8 text-white" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 4L4 8L12 12L20 8L12 4Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M4 12L12 16L20 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M4 16L12 20L20 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="text-white font-semibold text-lg">Synovatech One HR</span>
        </div>
        
        <Button variant="ghost" size="icon" className="text-white hover:bg-primary-600">
          <BellRing className="h-6 w-6" />
          <span className="sr-only">Notifications</span>
        </Button>
      </div>
    </div>
  );
}
