import { cn } from "@/lib/utils";

interface ChartContainerProps {
  children: React.ReactNode;
  className?: string;
}

export function ChartContainer({ children, className }: ChartContainerProps) {
  return (
    <div 
      className={cn(
        "w-full h-full flex items-center justify-center overflow-hidden", 
        className
      )}
    >
      {children}
    </div>
  );
}
