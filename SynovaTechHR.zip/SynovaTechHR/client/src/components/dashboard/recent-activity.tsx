import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

interface ActivityLog {
  id: number;
  userId: number;
  action: string;
  details: string;
  timestamp: string;
  user?: {
    fullName: string;
    profileImage?: string;
  };
}

export default function RecentActivity() {
  const { data: activityLogs, isLoading } = useQuery<ActivityLog[]>({
    queryKey: ['/api/activity-logs', { limit: 5 }],
  });
  
  return (
    <Card>
      <CardHeader className="px-4 py-5 sm:px-6 flex justify-between items-center border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-800">Recent Activity</CardTitle>
        <div>
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Live Updates
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6 overflow-y-auto" style={{ maxHeight: "240px" }}>
        <div className="flow-root">
          <ul className="-mb-8">
            {isLoading ? (
              Array(3).fill(0).map((_, index) => (
                <li key={index}>
                  <div className="relative pb-6">
                    <div className="relative flex items-start space-x-3">
                      <div className="relative">
                        <Skeleton className="h-10 w-10 rounded-full" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div>
                          <div className="text-sm">
                            <Skeleton className="h-5 w-32" />
                          </div>
                          <Skeleton className="h-4 w-48 mt-1" />
                        </div>
                        <div className="mt-2">
                          <Skeleton className="h-4 w-64" />
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              ))
            ) : (
              activityLogs?.map((log, idx) => (
                <li key={log.id}>
                  <div className="relative pb-6">
                    <div className="relative flex items-start space-x-3">
                      <div className="relative">
                        {log.action === "ai-insight" ? (
                          <div className="h-10 w-10 rounded-full bg-primary-700 flex items-center justify-center ring-8 ring-white">
                            <span className="text-xs font-medium text-white">ZAI</span>
                          </div>
                        ) : (
                          <Avatar className="h-10 w-10 ring-8 ring-white">
                            {log.user?.profileImage ? (
                              <AvatarImage 
                                src={log.user.profileImage} 
                                alt={log.user?.fullName || "User"} 
                              />
                            ) : null}
                            <AvatarFallback className="bg-neutral-300">
                              {log.user?.fullName?.split(' ').map(n => n[0]).join('') || 'U'}
                            </AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div>
                          <div className="text-sm">
                            <Link href={log.action === "ai-insight" ? "#" : `/users/${log.userId}`}>
                              <a className="font-medium text-neutral-900">
                                {log.action === "ai-insight" ? "ZenaI Assistant" : log.user?.fullName || `User ${log.userId}`}
                              </a>
                            </Link>
                          </div>
                          <p className="mt-0.5 text-sm text-neutral-500">
                            {log.action === "ai-insight" ? "AI-generated insight" : log.action}
                          </p>
                        </div>
                        <div className="mt-2 text-sm text-neutral-700">
                          <p>{log.details}</p>
                        </div>
                      </div>
                      <div className="flex-shrink-0 self-center">
                        <span className="text-xs text-neutral-500">
                          {new Date(log.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                    </div>
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>
      </CardContent>
      <CardFooter className="bg-neutral-50 px-4 py-4 sm:px-6 border-t border-neutral-200">
        <div className="text-sm">
          <Link href="/reports?view=activity">
            <a className="font-medium text-primary-600 hover:text-primary-500">View all activity</a>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
}
