import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

interface HRSummaryData {
  totalEmployees: number;
  openPositions: number;
  attendanceRate: number;
  pendingReviews: number;
}

export default function HRSummary() {
  const { data, isLoading, error } = useQuery<HRSummaryData>({
    queryKey: ['/api/analytics/summary'],
  });
  
  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>HR Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-destructive">Error loading HR summary data</div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="px-4 py-5 sm:px-6 flex justify-between items-center border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-800">HR Summary</CardTitle>
        <span className="text-sm text-neutral-500">Today</span>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6">
        <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-neutral-500">Total Employees</dt>
            {isLoading ? (
              <Skeleton className="h-8 w-16 mt-1" />
            ) : (
              <dd className="mt-1 text-xl font-semibold text-neutral-800">{data?.totalEmployees}</dd>
            )}
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-neutral-500">Open Positions</dt>
            {isLoading ? (
              <Skeleton className="h-8 w-16 mt-1" />
            ) : (
              <dd className="mt-1 text-xl font-semibold text-neutral-800">{data?.openPositions}</dd>
            )}
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-neutral-500">Attendance Rate</dt>
            {isLoading ? (
              <Skeleton className="h-8 w-16 mt-1" />
            ) : (
              <dd className="mt-1 text-xl font-semibold text-green-500">{data?.attendanceRate}%</dd>
            )}
          </div>
          <div className="sm:col-span-1">
            <dt className="text-sm font-medium text-neutral-500">Pending Reviews</dt>
            {isLoading ? (
              <Skeleton className="h-8 w-16 mt-1" />
            ) : (
              <dd className="mt-1 text-xl font-semibold text-amber-500">{data?.pendingReviews}</dd>
            )}
          </div>
        </dl>
      </CardContent>
      <CardFooter className="bg-neutral-50 px-4 py-4 sm:px-6 border-t border-neutral-200">
        <div className="text-sm flex justify-between w-full">
          <Link href="/reports">
            <div className="font-medium text-primary-600 hover:text-primary-500 cursor-pointer">View all details</div>
          </Link>
          <span className="text-neutral-500">Last updated: 2h ago</span>
        </div>
      </CardFooter>
    </Card>
  );
}
