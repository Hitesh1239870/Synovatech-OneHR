import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { MoreVertical, FileText, FileSpreadsheet, FilePlus } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Document {
  id: number;
  title: string;
  type: string;
  content: string;
  ownerId: number;
  createdAt: string;
  updatedAt: string;
  owner?: {
    fullName: string;
  };
}

export default function RecentDocuments() {
  const { data: documents, isLoading } = useQuery<Document[]>({
    queryKey: ['/api/documents'],
  });
  
  const getDocumentIcon = (type: string) => {
    switch (type) {
      case 'policy':
        return <FileText className="h-6 w-6 text-neutral-500" />;
      case 'spreadsheet':
        return <FileSpreadsheet className="h-6 w-6 text-neutral-500" />;
      default:
        return <FileText className="h-6 w-6 text-neutral-500" />;
    }
  };
  
  return (
    <Card>
      <CardHeader className="px-4 py-5 sm:px-6 flex justify-between items-center border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-800">Recent Documents</CardTitle>
        <Button variant="outline" size="sm" className="h-8 w-8 p-0">
          <FilePlus className="h-5 w-5" />
          <span className="sr-only">Add document</span>
        </Button>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6 overflow-y-auto" style={{ maxHeight: "240px" }}>
        <ul className="divide-y divide-neutral-200">
          {isLoading ? (
            Array(3).fill(0).map((_, index) => (
              <li key={index} className="py-3 flex items-center justify-between">
                <div className="flex items-center">
                  <Skeleton className="h-10 w-10 rounded-md" />
                  <div className="ml-4">
                    <Skeleton className="h-5 w-48" />
                    <Skeleton className="h-4 w-32 mt-1" />
                  </div>
                </div>
              </li>
            ))
          ) : (
            documents?.slice(0, 3).map((doc) => (
              <li key={doc.id} className="py-3 flex items-center justify-between">
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-10 w-10 bg-neutral-200 rounded-md flex items-center justify-center">
                    {getDocumentIcon(doc.type)}
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-neutral-900">{doc.title}</p>
                    <p className="text-xs text-neutral-500">
                      Updated {new Date(doc.updatedAt).toLocaleDateString()} by {doc.owner?.fullName || `User ${doc.ownerId}`}
                    </p>
                  </div>
                </div>
                <div className="ml-2 flex-shrink-0">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <MoreVertical className="h-5 w-5" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>View</DropdownMenuItem>
                      <DropdownMenuItem>Edit</DropdownMenuItem>
                      <DropdownMenuItem>Download</DropdownMenuItem>
                      <DropdownMenuItem>Share</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </li>
            ))
          )}
        </ul>
      </CardContent>
      <CardFooter className="bg-neutral-50 px-4 py-4 sm:px-6 border-t border-neutral-200">
        <div className="text-sm">
          <Link href="/documents">
            <a className="font-medium text-primary-600 hover:text-primary-500">View all documents</a>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
}
