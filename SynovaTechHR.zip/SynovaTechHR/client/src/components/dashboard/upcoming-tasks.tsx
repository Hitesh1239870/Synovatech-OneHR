import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format, isToday, isTomorrow, isAfter, addDays } from "date-fns";

interface Task {
  id: number;
  title: string;
  description: string;
  assignedTo: number;
  dueDate: string;
  priority: "low" | "medium" | "high";
  status: "pending" | "in-progress" | "completed";
  createdAt: string;
}

export default function UpcomingTasks() {
  const { data: tasks, isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });
  
  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
            Urgent
          </Badge>
        );
      case 'medium':
        return (
          <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-200">
            Priority
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
            Normal
          </Badge>
        );
    }
  };
  
  const getTaskDueText = (dueDate: string) => {
    const date = new Date(dueDate);
    if (isToday(date)) return "Due today";
    if (isTomorrow(date)) return "Due tomorrow";
    if (isAfter(date, addDays(new Date(), 5))) return `Due in ${format(date, 'MMM d')}`;
    return `Due in ${Math.ceil((date.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days`;
  };
  
  const getCategoryBadge = (task: Task) => {
    if (task.title.toLowerCase().includes("review")) {
      return (
        <Badge variant="outline" className="bg-primary-100 text-primary-800 border-primary-200 ml-2">
          Management
        </Badge>
      );
    } else if (task.title.toLowerCase().includes("recruitment") || task.title.toLowerCase().includes("application")) {
      return (
        <Badge variant="outline" className="bg-secondary-100 text-secondary-800 border-secondary-200 ml-2">
          Recruitment
        </Badge>
      );
    } else if (task.title.toLowerCase().includes("document") || task.title.toLowerCase().includes("handbook")) {
      return (
        <Badge variant="outline" className="bg-primary-100 text-primary-800 border-primary-200 ml-2">
          Documentation
        </Badge>
      );
    } else if (task.title.toLowerCase().includes("benefit") || task.title.toLowerCase().includes("enrollment")) {
      return (
        <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200 ml-2">
          Benefits
        </Badge>
      );
    }
    return null;
  };
  
  return (
    <Card>
      <CardHeader className="px-4 py-5 sm:px-6 flex justify-between items-center border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-800">Upcoming Tasks</CardTitle>
        <Button variant="outline" size="sm" className="h-8 w-8 p-0">
          <Plus className="h-5 w-5" />
          <span className="sr-only">Add task</span>
        </Button>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6 overflow-y-auto" style={{ maxHeight: "270px" }}>
        <ul className="divide-y divide-neutral-200">
          {isLoading ? (
            Array(4).fill(0).map((_, index) => (
              <li key={index} className="py-3">
                <div className="flex items-center">
                  <Skeleton className="h-4 w-4 mr-3" />
                  <div className="w-full">
                    <Skeleton className="h-5 w-3/4" />
                    <Skeleton className="h-4 w-1/3 mt-1" />
                    <div className="mt-2">
                      <Skeleton className="h-5 w-24 rounded-full" />
                    </div>
                  </div>
                </div>
              </li>
            ))
          ) : (
            tasks?.filter(task => task.status !== "completed")
                 .slice(0, 4)
                 .map((task) => (
              <li key={task.id} className="py-3">
                <div className="flex items-center">
                  <Checkbox id={`task-${task.id}`} className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-neutral-300 rounded" />
                  <label htmlFor={`task-${task.id}`} className="ml-3 block">
                    <span className="text-sm font-medium text-neutral-700">{task.title}</span>
                    <span className="block text-xs text-neutral-500">{getTaskDueText(task.dueDate)}</span>
                  </label>
                </div>
                <div className="mt-2 ml-7 flex flex-wrap gap-2">
                  {getPriorityBadge(task.priority)}
                  {getCategoryBadge(task)}
                </div>
              </li>
            ))
          )}
        </ul>
      </CardContent>
      <CardFooter className="bg-neutral-50 px-4 py-4 sm:px-6 border-t border-neutral-200">
        <div className="text-sm">
          <Link href="/tasks">
            <a className="font-medium text-primary-600 hover:text-primary-500">View all tasks</a>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
}
