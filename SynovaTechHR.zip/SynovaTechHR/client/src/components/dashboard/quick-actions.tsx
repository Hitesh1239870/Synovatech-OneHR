import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { UserPlus, CalendarClock, Briefcase, BarChart2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface QuickAction {
  title: string;
  icon: React.ReactNode;
  href: string;
  bgColor: string;
  iconColor: string;
  isAI?: boolean;
}

export default function QuickActions() {
  const actions: QuickAction[] = [
    {
      title: "Add Employee",
      icon: <UserPlus className="h-5 w-5" />,
      href: "/employees?action=add",
      bgColor: "bg-primary-100",
      iconColor: "text-primary-600"
    },
    {
      title: "Leave Requests",
      icon: <CalendarClock className="h-5 w-5" />,
      href: "/leave-management",
      bgColor: "bg-primary-100",
      iconColor: "text-primary-600"
    },
    {
      title: "Screen Candidates",
      icon: <Briefcase className="h-5 w-5" />,
      href: "/recruitment?action=screen",
      bgColor: "bg-secondary-100",
      iconColor: "text-secondary-600",
      isAI: true
    },
    {
      title: "Performance Analysis",
      icon: <BarChart2 className="h-5 w-5" />,
      href: "/performance",
      bgColor: "bg-secondary-100",
      iconColor: "text-secondary-600",
      isAI: true
    }
  ];
  
  return (
    <Card>
      <CardHeader className="px-4 py-5 sm:px-6 border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-800">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="grid grid-cols-2 gap-3">
          {actions.map((action, index) => (
            <Link key={index} href={action.href}>
              <Button
                variant="ghost"
                className={cn(
                  "px-4 py-3 bg-neutral-50 text-left justify-start h-auto rounded-md hover:bg-neutral-100 transition-colors duration-200 w-full",
                  action.isAI && "ai-badge"
                )}
              >
                <div className="flex items-center">
                  <div className={cn("flex-shrink-0 rounded-md p-2", action.bgColor)}>
                    <div className={action.iconColor}>
                      {action.icon}
                    </div>
                  </div>
                  <div className="ml-2">
                    <span className="text-sm font-medium text-neutral-700">{action.title}</span>
                  </div>
                </div>
              </Button>
            </Link>
          ))}
        </div>
      </CardContent>
      <CardFooter className="bg-neutral-50 px-4 py-4 sm:px-6 border-t border-neutral-200">
        <div className="text-sm">
          <Link href="/tasks">
            <a className="font-medium text-primary-600 hover:text-primary-500">View all tasks</a>
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
}
