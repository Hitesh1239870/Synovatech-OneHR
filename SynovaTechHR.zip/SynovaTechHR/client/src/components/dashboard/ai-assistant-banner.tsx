import { Button } from "@/components/ui/button";
import { useAIAssistant } from "@/hooks/use-ai-assistant";
import { Cpu } from "lucide-react";

export default function AIAssistantBanner() {
  const { openAIAssistant } = useAIAssistant();
  
  return (
    <div className="mb-6 bg-gradient-to-r from-secondary-600 to-secondary-500 rounded-lg shadow overflow-hidden">
      <div className="px-6 py-5 sm:flex sm:items-center sm:justify-between">
        <div className="flex items-center">
          <div className="flex-shrink-0 bg-white/20 rounded-full p-2">
            <Cpu className="h-8 w-8 text-white" />
          </div>
          <div className="ml-4">
            <h2 className="text-lg font-medium text-white">ZenaI Assistant</h2>
            <p className="text-sm text-white/80">AI-powered insights ready to help with your HR tasks</p>
          </div>
        </div>
        <div className="mt-4 sm:mt-0">
          <Button 
            onClick={openAIAssistant}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-secondary-600 bg-white hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary-500"
          >
            Ask ZenaI
          </Button>
        </div>
      </div>
    </div>
  );
}
