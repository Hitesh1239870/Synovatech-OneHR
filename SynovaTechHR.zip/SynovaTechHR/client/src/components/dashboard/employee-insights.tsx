import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { ChartContainer } from "@/components/ui/chart-container";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

type DepartmentDistribution = {
  department: string;
  count: number;
  percentage: number;
};

export default function EmployeeInsights() {
  const { data: departmentData, isLoading: isLoadingDepartments } = useQuery<DepartmentDistribution[]>({
    queryKey: ['/api/analytics/department-distribution'],
  });
  
  // Set up color scheme for the pie chart
  const COLORS = ['#0EA5E9', '#8B5CF6', '#F59E0B', '#10B981', '#EF4444'];
  
  // Retention analysis data (in a real app, this would come from an API)
  const retentionData = [
    { name: 'Jan', rate: 92 },
    { name: 'Feb', rate: 94 },
    { name: 'Mar', rate: 93 },
    { name: 'Apr', rate: 96 },
    { name: 'May', rate: 95 },
    { name: 'Jun', rate: 98 },
  ];
  
  return (
    <Card className="lg:col-span-2">
      <CardHeader className="px-4 py-5 sm:px-6 flex justify-between items-center border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-800">Employee Insights</CardTitle>
        <div className="flex space-x-3">
          <div>
            <select className="mt-1 block pl-3 pr-10 py-2 text-base border-neutral-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md">
              <option>This month</option>
              <option>Last month</option>
              <option>This quarter</option>
              <option>This year</option>
            </select>
          </div>
          <button
            type="button"
            className="inline-flex items-center px-3 py-2 border border-neutral-300 shadow-sm text-sm leading-4 font-medium rounded-md text-neutral-700 bg-white hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <svg className="-ml-0.5 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Export
          </button>
        </div>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h4 className="text-base font-medium text-neutral-700 mb-3">Department Distribution</h4>
            <div className="bg-neutral-50 p-4 rounded-lg h-64 flex items-center justify-center">
              {isLoadingDepartments ? (
                <Skeleton className="h-full w-full rounded-md" /> 
              ) : (
                <ChartContainer>
                  <PieChart width={270} height={230}>
                    <Pie
                      data={departmentData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                      nameKey="department"
                      label={({ department, percentage }) => `${department}: ${percentage}%`}
                    >
                      {departmentData?.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value, name) => [`${value} employees`, name]} />
                  </PieChart>
                </ChartContainer>
              )}
            </div>
            <div className="mt-3">
              <dl className="grid grid-cols-3 gap-3">
                {isLoadingDepartments ? (
                  Array(3).fill(0).map((_, index) => (
                    <div key={index} className="col-span-1">
                      <Skeleton className="h-4 w-20 mb-2" />
                      <Skeleton className="h-6 w-24" />
                    </div>
                  ))
                ) : (
                  departmentData?.slice(0, 3).map((dept, index) => (
                    <div key={index} className="col-span-1">
                      <dt className="text-xs text-neutral-500">{dept.department}</dt>
                      <dd className="text-sm font-medium text-neutral-700">
                        {dept.count} ({dept.percentage}%)
                      </dd>
                    </div>
                  ))
                )}
              </dl>
            </div>
          </div>
          
          <div>
            <h4 className="text-base font-medium text-neutral-700 mb-3 ai-badge">Talent Retention Analysis</h4>
            <div className="bg-neutral-50 p-4 rounded-lg h-64 flex items-center justify-center">
              <ChartContainer>
                <ResponsiveContainer width="100%" height={230}>
                  <BarChart data={retentionData}>
                    <XAxis dataKey="name" />
                    <YAxis domain={[85, 100]} />
                    <Tooltip formatter={(value) => [`${value}%`, 'Retention Rate']} />
                    <Bar dataKey="rate" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
            <div className="mt-3 bg-secondary-50 p-3 rounded-md border border-secondary-100">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-secondary-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <h5 className="text-sm font-medium text-secondary-800">AI Recommendation</h5>
                  <p className="text-xs text-secondary-700 mt-1">
                    Data suggests Engineering department has 15% higher turnover risk. Consider conducting stay interviews with team leads.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
