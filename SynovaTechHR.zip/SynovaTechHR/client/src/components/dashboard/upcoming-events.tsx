import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, ChevronRight, Clock } from "lucide-react";
import { format } from "date-fns";

interface Event {
  id: number;
  title: string;
  description: string;
  date: string;
  startTime: string;
  endTime: string;
  location: string;
  organizer: number;
  status: string;
  isAiFeature: boolean;
  createdAt: string;
}

export default function UpcomingEvents() {
  const { data: events, isLoading } = useQuery<Event[]>({
    queryKey: ['/api/events'],
  });
  
  const getEventStatusBadge = (status: string) => {
    switch (status) {
      case 'planned':
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
            Confirmed
          </Badge>
        );
      case 'cancelled':
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
            Cancelled
          </Badge>
        );
      case 'completed':
        return (
          <Badge variant="outline" className="bg-neutral-100 text-neutral-800 border-neutral-200">
            Completed
          </Badge>
        );
      default:
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
            Planning
          </Badge>
        );
    }
  };
  
  const getEventTypeBadge = (event: Event) => {
    if (event.title.toLowerCase().includes("onboarding")) {
      return "Onboarding";
    } else if (event.title.toLowerCase().includes("meeting")) {
      return "Meeting";
    } else if (event.title.toLowerCase().includes("training") || event.title.toLowerCase().includes("workshop")) {
      return "Training";
    } else if (event.title.toLowerCase().includes("screening") || event.title.toLowerCase().includes("interview")) {
      return "Recruitment";
    }
    return "Event";
  };
  
  // Format the date for display
  const formatEventDate = (dateString: string) => {
    const date = new Date(dateString);
    return {
      month: format(date, 'MMM').toUpperCase(),
      day: format(date, 'd')
    };
  };
  
  return (
    <Card>
      <CardHeader className="px-4 py-5 sm:px-6 flex justify-between items-center border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-800">Upcoming Events</CardTitle>
        <div className="flex space-x-1">
          <Button variant="outline" size="sm" className="h-8 w-8 p-0">
            <ChevronLeft className="h-5 w-5" />
            <span className="sr-only">Previous</span>
          </Button>
          <Button variant="outline" size="sm" className="h-8 w-8 p-0">
            <ChevronRight className="h-5 w-5" />
            <span className="sr-only">Next</span>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6 overflow-y-auto" style={{ maxHeight: "270px" }}>
        <div className="text-sm text-center text-neutral-500 font-medium py-1 mb-3 border-b border-neutral-200">
          {format(new Date(), 'MMMM yyyy')}
        </div>
        <div className="space-y-4">
          {isLoading ? (
            Array(3).fill(0).map((_, index) => (
              <div key={index} className="relative">
                <div className="flex items-center">
                  <Skeleton className="h-12 w-12 rounded" />
                  <div className="ml-4 flex-1">
                    <Skeleton className="h-5 w-48" />
                    <Skeleton className="h-4 w-32 mt-1" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            events?.slice(0, 3).map((event) => {
              const { month, day } = formatEventDate(event.date);
              return (
                <div key={event.id} className="relative">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-12 w-12 rounded overflow-hidden bg-primary-100 text-primary-800 flex flex-col items-center justify-center">
                      <span className="text-xs font-medium">{month}</span>
                      <span className="text-lg font-bold">{day}</span>
                    </div>
                    <div className="ml-4 flex-1">
                      <h4 className={`text-sm font-medium text-neutral-900 ${event.isAiFeature ? 'ai-badge' : ''}`}>
                        {event.title}
                      </h4>
                      <div className="mt-1 flex items-center text-xs text-neutral-500">
                        <Clock className="flex-shrink-0 mr-1.5 h-4 w-4" />
                        <span>{event.startTime} - {event.endTime}</span>
                      </div>
                    </div>
                    <div className="ml-2">
                      <Badge variant="outline" className={
                        event.isAiFeature 
                          ? "bg-secondary-100 text-secondary-800 border-secondary-200"
                          : "bg-blue-100 text-blue-800 border-blue-200"
                      }>
                        {getEventTypeBadge(event)}
                      </Badge>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
      <CardFooter className="bg-neutral-50 px-4 py-4 sm:px-6 border-t border-neutral-200">
        <div className="text-sm flex justify-between w-full">
          <Link href="/calendar">
            <a className="font-medium text-primary-600 hover:text-primary-500">View calendar</a>
          </Link>
          <button className="text-neutral-500 hover:text-neutral-700 font-medium">+ Add event</button>
        </div>
      </CardFooter>
    </Card>
  );
}
